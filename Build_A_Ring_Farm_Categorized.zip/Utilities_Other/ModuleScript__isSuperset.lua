-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.isSuperset
-- Class: ModuleScript

-- https://lua.expert/
local isSubset = require(script.Parent.isSubset)
return function(p1, p2) --[[ isSuperset | Line: 21 | Upvalues: isSubset (copy) ]]
	return isSubset(p2, p1)
end