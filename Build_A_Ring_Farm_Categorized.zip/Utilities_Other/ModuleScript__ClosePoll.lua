-- Path: ReplicatedStorage.CmdrClient.Commands.ClosePoll
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "ClosePoll",
	Description = "Closes an active poll early and broadcasts final results.",
	Group = "DefaultAdmin",
	Aliases = { "endpoll" },
	Args = {
		{
			Type = "activePollId",
			Name = "pollId",
			Description = "The active poll to close"
		}
	}
}