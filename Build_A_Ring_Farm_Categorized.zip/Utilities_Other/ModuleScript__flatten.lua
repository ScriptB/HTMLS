-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.flatten
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
local function v1(p1, p2) --[[ flatten | Line: 30 | Upvalues: v1 (copy) ]]
	if type(p2) ~= "number" then
		p2 = (1 / 0)
	end
	local tbl = {}
	for k, v in pairs(p1) do
		if type(v) == "table" and p2 > 0 then
			local v12 = v1(v, p2 - 1)
			for k2, v2 in pairs(tbl) do
				v12[k2] = v2
			end
			tbl = v12
			continue
		end
		tbl[k] = v
	end
	return tbl
end
return v1