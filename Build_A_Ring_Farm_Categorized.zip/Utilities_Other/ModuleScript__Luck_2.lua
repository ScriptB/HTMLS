-- Path: ReplicatedStorage.SparkMod.Types.Luck
-- Class: ModuleScript

-- https://lua.expert/
return {}