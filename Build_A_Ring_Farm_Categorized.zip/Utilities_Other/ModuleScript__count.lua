-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.count
-- Class: ModuleScript

-- https://lua.expert/
local Util = require(script.Parent.Parent.Util)
return function(p1, p2) --[[ count | Line: 25 | Upvalues: Util (copy) ]]
	local count = 0
	if type(p2) ~= "function" then
		p2 = Util.func.truthy
	end
	for i, v in ipairs(p1) do
		if p2(v, i, p1) then
			count = count + 1
		end
	end
	return count
end