-- Path: ReplicatedStorage.SharedSource.Utilities.ScriptsLoader.ComponentsInitializer
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ componentsInitializer | Line: 1 ]]
	local Components = p1:FindFirstChild("Components")
	if not Components then
		warn("No Components folder found in " .. p1:GetFullName())
		return
	end
	for k, v in pairs(Components:GetDescendants()) do
		if v:IsA("ModuleScript") then
			local v1, v2 = pcall(require, v)
			if v1 and (typeof(v2) == "table" and not v:GetAttribute("Initialized")) then
				local v3
				if v2.Init and typeof(v2.Init) == "function" then
					v:SetAttribute("Initialized", true)
					local v4, v5 = pcall(function() --[[ Line: 20 | Upvalues: v2 (copy) ]]
						v2.Init()
					end)
					if not v4 then
						warn("Error initializing component " .. v:GetFullName() .. ": " .. v5)
					end
					if v2.Start then
						v3 = v2.Start
						if typeof(v3) == "function" and not v:GetAttribute("Started") then
							v:SetAttribute("Started", true)
							task.spawn(function() --[[ Line: 36 | Upvalues: v2 (copy), v (copy) ]]
								local v1, v22 = pcall(function() --[[ Line: 37 | Upvalues: v2 (ref) ]]
									v2.Start()
								end)
								if v1 then
									return
								end
								warn("Error starting component " .. v:GetFullName() .. ": " .. v22)
							end)
						end
					end
				else
					if v2.Init then
						if v2.Start then
							v3 = v2.Start
							if typeof(v3) == "function" and not v:GetAttribute("Started") then
								v:SetAttribute("Started", true)
								task.spawn(function() --[[ Line: 36 | Upvalues: v2 (copy), v (copy) ]]
									local v1, v22 = pcall(function() --[[ Line: 37 | Upvalues: v2 (ref) ]]
										v2.Start()
									end)
									if v1 then
										return
									end
									warn("Error starting component " .. v:GetFullName() .. ": " .. v22)
								end)
							end
						end
						continue
					end
					warn("Component " .. v.Name .. " does not have an Init function")
				end
			end
		end
	end
end