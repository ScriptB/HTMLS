-- Path: ReplicatedStorage.Packages.Component
-- Class: ModuleScript

-- https://lua.expert/
return require(script.Parent._Index["sleitnick_component@2.4.8"].component)