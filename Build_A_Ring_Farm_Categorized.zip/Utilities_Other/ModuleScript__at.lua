-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.at
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ at | Line: 19 ]]
	if p2 < 1 then
		p2 = p2 + #p1
	end
	return p1[p2]
end