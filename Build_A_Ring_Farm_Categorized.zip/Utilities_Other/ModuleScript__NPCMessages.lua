-- Path: ReplicatedStorage.Shared.NPCMessages
-- Class: ModuleScript

-- https://lua.expert/
return {
	"Awesome!",
	"Yummy juice!",
	"I love this!",
	"Best juice ever!",
	"Will come back again!",
	"So tasty!",
	"This juice will change my life!",
	"Is this juice from heaven?",
	"I like this",
	"This juice is not bad",
	"It\'s decent"
}