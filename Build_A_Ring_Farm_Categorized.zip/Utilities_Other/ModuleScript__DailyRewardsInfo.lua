-- Path: ReplicatedStorage.Shared.DailyRewardsInfo
-- Class: ModuleScript

-- https://lua.expert/
return {
	Rewards = {
		{
			Cash = 500
		},
		{
			Skip = true
		},
		{
			Seed = "Spring Onion"
		},
		{
			Seed = "Mushroom"
		},
		{
			Skip = true
		},
		{
			Seed = "Strawberry"
		},
		{
			Seed = "Apple"
		}
	}
}