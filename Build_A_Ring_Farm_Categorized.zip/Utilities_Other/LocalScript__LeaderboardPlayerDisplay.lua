-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.LeaderboardPlayerDisplay
-- Class: LocalScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Sift = require(ReplicatedStorage.Packages.Sift)
local SharedUtils = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SharedUtils"))
local RingValueBonusConfig = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("RingValueBonusConfig"))
local DataAggregation = require(script.Parent.Parent.Modules.DataAggregation)
local Configuration = require(ReplicatedStorage.Shared.Configuration)
local v1 = Sift.Dictionary.count(Configuration.FloorConfig)
local Leaderboards = workspace:WaitForChild("Leaderboards")
local LocalPlayer = Players.LocalPlayer
local v2 = nil
task.wait(10)
local function FindPlayerPlot() --[[ FindPlayerPlot | Line: 20 | Upvalues: v2 (ref), ReplicatedStorage (copy) ]]
	if v2 and v2.Parent then
		return v2
	end
	local GetPlot = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("Plot"):WaitForChild("GetPlot")
	local v1, v22 = pcall(function() --[[ Line: 28 | Upvalues: GetPlot (copy) ]]
		return GetPlot:InvokeServer()
	end)
	if not (v1 and v22) then
		return nil
	end
	v2 = v22
	if v2:GetAttribute("DataLoaded") then
		return v2
	end
	task.spawn(function() --[[ Line: 35 | Upvalues: v2 (ref) ]]
		while v2 and (v2.Parent and not v2:GetAttribute("DataLoaded")) do
			v2:GetAttributeChangedSignal("DataLoaded"):Wait()
		end
	end)
	return v2
end
local function BuildFloorEntry(p1, p2) --[[ BuildFloorEntry | Line: 47 ]]
	if not p1 then
		return nil
	end
	local v1 = p1:GetAttribute("SawRange_" .. p2) or 1
	local v2 = p1:GetAttribute("SawYield_" .. p2) or 1
	local v3 = p1:GetAttribute("SprinklerRange_" .. p2) or 1
	local v4 = p1:GetAttribute("SprinklerPower_" .. p2) or 1
	local v5 = p1:GetAttribute("FarmPlotStage") or 1
	local t = {}
	for i, v in ipairs(p1:GetChildren()) do
		if v:IsA("Model") and v.Name:match("^Plot%d+$") then
			local v7 = tonumber(v.Name:match("(%d+)$"))
			if v7 and v7 <= v5 then
				local Dirt = v:FindFirstChild("Dirt")
				if Dirt and Dirt:IsA("BasePart") then
					local v8 = Dirt:GetAttribute("PlantName")
					if v8 then
						table.insert(t, {
							plantName = v8,
							mutation = Dirt:GetAttribute("PlantMutation") or "Normal",
							level = Dirt:GetAttribute("PlantLevel") or 1,
							ring = Dirt:GetAttribute("PlotRing") or v7
						})
					end
				end
			end
		end
	end
	if #t == 0 then
		return nil
	else
		return {
			floorKey = p2,
			farmPlot = p1,
			sawRange = v1,
			sawYield = v2,
			sprinklerRange = v3,
			sprinklerPower = v4,
			triangles = t
		}
	end
end
local function GetFloorIndexFromSlot(p1) --[[ GetFloorIndexFromSlot | Line: 90 ]]
	return (p1 - 1) % 3 + 1
end
local function GetFloorKeyFromIndex(p1) --[[ GetFloorKeyFromIndex | Line: 94 ]]
	return "Floor" .. tostring(p1)
end
local function GetEarningsMultiplier(p1, p2) --[[ GetEarningsMultiplier | Line: 98 ]]
	local EquippedPets = p1.Data.EquippedPets
	local PetInventory = p1.Data.PetInventory
	if not (EquippedPets and PetInventory) then
		return 1
	end
	local sum = 0
	local v1 = false
	for k, v in pairs(EquippedPets) do
		if v and v ~= "" and "Floor" .. tostring(((tonumber(k) or 1) - 1) % 3 + 1) == p2 then
			local v3 = PetInventory[v]
			if v3 then
				sum = sum + math.max(0, tonumber(v3.EarningsMultiplier) or 1)
				v1 = true
			end
		end
	end
	if v1 then
		return sum
	else
		return 1
	end
end
local function GetCashPerMinute(p1) --[[ GetCashPerMinute | Line: 121 | Upvalues: FindPlayerPlot (copy), BuildFloorEntry (copy), v1 (copy), SharedUtils (copy), RingValueBonusConfig (copy), GetEarningsMultiplier (copy) ]]
	local v12 = FindPlayerPlot()
	if not v12 then
		return 0
	end
	local list = {}
	local v2 = BuildFloorEntry(v12:FindFirstChild("FarmPlot"), "Floor1")
	if v2 then
		table.insert(list, v2)
	end
	for i = 2, v1 do
		local v3 = v12:FindFirstChild("Floor" .. i)
		if v3 then
			local v4 = BuildFloorEntry(v3:FindFirstChild("FarmPlot"), "Floor" .. i)
			if v4 then
				table.insert(list, v4)
			end
		end
	end
	if #list == 0 then
		return 0
	end
	local v5 = p1.Data.MoneyMultiplierTier or 0
	local v6 = SharedUtils.GetFarmSkinEarningsMultiplier(p1.Data.EquippedSkin)
	local sum = 0
	for i, v in ipairs(list) do
		local v7 = SharedUtils.CalculateCashPerMinute({ v }, v5)
		local v8 = RingValueBonusConfig.GetFloorMultiplier(v.farmPlot, v.floorKey)
		sum = sum + math.floor(v7 * GetEarningsMultiplier(p1, v.floorKey) * v8 * v6)
	end
	return sum
end
local list = {
	{
		leaderboardName = "CashLeaderboard",
		templateName = "CashTemplate",
		dataKey = "CashPerMinute",
		format = function(p1) --[[ format | Line: 159 | Upvalues: SharedUtils (copy) ]]
			return SharedUtils.NumberToCashAbbreviated(p1 or 0) .. "/min"
		end
	},
	{
		leaderboardName = "TimeLeaderboard",
		templateName = "TimeTemplate",
		dataKey = "Playtime",
		format = function(p1) --[[ format | Line: 167 | Upvalues: SharedUtils (copy) ]]
			return SharedUtils.FormatDuration(p1 or 0)
		end
	}
}
local v3 = DataAggregation.WaitForReplica()
local t = {}
for i, v in ipairs(list) do
	local v4 = Leaderboards:FindFirstChild(v.leaderboardName)
	if v4 then
		local PlayerPart = v4:FindFirstChild("PlayerPart")
		if PlayerPart then
			local SurfaceGui = PlayerPart:FindFirstChild("SurfaceGui")
			if SurfaceGui then
				local Frame = SurfaceGui:FindFirstChild("Frame")
				if Frame then
					local v5 = Frame:FindFirstChild(v.templateName)
					if v5 then
						v5.TextLabel1.Text = LocalPlayer.DisplayName
						v5.TextLabel2.Text = v.format(if v.dataKey == "CashPerMinute" then GetCashPerMinute(v3) else v3.Data[v.dataKey])
						v5.Visible = true
						t[v.dataKey] = {
							label = v5.TextLabel2,
							format = v.format
						}
					end
				end
			end
		end
	end
end
local function UpdateCashPerMinuteDisplay() --[[ UpdateCashPerMinuteDisplay | Line: 205 | Upvalues: t (copy), GetCashPerMinute (copy), v3 (copy) ]]
	local CashPerMinute = t.CashPerMinute
	if not CashPerMinute then
		return
	end
	CashPerMinute.label.Text = CashPerMinute.format((GetCashPerMinute(v3)))
end
v3:OnChange(function(p1, p2, p3, p4) --[[ Line: 213 | Upvalues: t (copy), GetCashPerMinute (copy), v3 (copy) ]]
	if p1 == "Set" then
		local v1 = p2[1]
		local v2 = t[v1]
		if v2 then
			v2.label.Text = v2.format(p3)
		end
		if v1 ~= "MoneyMultiplierTier" and (v1 ~= "FarmData" and (v1 ~= "EquippedPets" and (v1 ~= "PetInventory" and v1 ~= "EquippedSkin"))) then
			return
		end
		local CashPerMinute = t.CashPerMinute
		if CashPerMinute then
			CashPerMinute.label.Text = CashPerMinute.format((GetCashPerMinute(v3)))
		end
	else
		if p1 ~= "SetValues" or p2[1] ~= nil then
			return
		end
		for k, v in pairs(p3) do
			local v32 = t[k]
			if v32 then
				v32.label.Text = v32.format(v)
			end
		end
		if p3.MoneyMultiplierTier == nil and (p3.FarmData == nil and (p3.EquippedPets == nil and (p3.PetInventory == nil and p3.EquippedSkin == nil))) then
			return
		end
		local CashPerMinute = t.CashPerMinute
		if not CashPerMinute then
			return
		end
		CashPerMinute.label.Text = CashPerMinute.format((GetCashPerMinute(v3)))
	end
end)
task.spawn(function() --[[ Line: 238 | Upvalues: t (copy), GetCashPerMinute (copy), v3 (copy) ]]
	repeat
		local CashPerMinute = t.CashPerMinute
		if CashPerMinute then
			CashPerMinute.label.Text = CashPerMinute.format((GetCashPerMinute(v3)))
		end
		task.wait(10)
	until not CashPerMinute
end)