-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.intersection
-- Class: ModuleScript

-- https://lua.expert/
return function(...) --[[ intersection | Line: 20 ]]
	local v1 = select("#", ...)
	local t = {}
	for k, v in pairs((select(1, ...))) do
		local v3 = true
		for i = 2, v1 do
			if select(i, ...)[k] ~= true then
				v3 = false
				break
			end
		end
		if v3 then
			t[k] = true
		end
	end
	return t
end