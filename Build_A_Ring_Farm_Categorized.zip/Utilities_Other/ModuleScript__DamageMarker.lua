-- Path: ReplicatedStorage.Shared.DamageMarker
-- Class: ModuleScript

-- https://lua.expert/
game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")
local Spring = require(script.Parent.Tweener.Spring)
return function(p1, p2, p3) --[[ Line: 7 | Upvalues: Spring (copy), Debris (copy) ]]
	local Attachment = Instance.new("Attachment")
	Attachment.WorldPosition = p1
	Attachment.Parent = workspace.Terrain
	local v1 = script.BillboardGui:Clone()
	v1.Parent = Attachment
	local v2 = p2 or ""
	local DamageShadow = v1.Frame.DamageShadow
	local Damage = DamageShadow.Damage
	DamageShadow.Text = v2
	Damage.Text = v2
	Damage.TextColor3 = if p3 then p3 else Damage.TextColor3
	Spring.target(v1.Frame.UIScale, 0.9, 3, {
		Scale = 0.2 + math.random(-10, 50) / 100
	})
	local target = Spring.target
	local t = {}
	t.StudsOffset = Vector3.new(math.random(-5, 5), math.random(-3, 3), 0)
	target(v1, 1.5, 2, t)
	task.delay(0.65, function() --[[ Line: 36 | Upvalues: Spring (ref), DamageShadow (copy), Damage (copy) ]]
		local t = {
			TextTransparency = 1,
			TextStrokeTransparency = 1
		}
		Spring.target(DamageShadow, 0.9, 2.5, t)
		Spring.target(Damage, 0.9, 2.5, t)
	end)
	Debris:AddItem(Attachment, 3)
end