-- Path: ReplicatedStorage.Shared.QueenBeeConfig
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	EventName = "Queen Bee",
	HoneycombDropInterval = 5,
	HoneycombCollectTime = 0.25,
	HoneycombsPerToken = 5,
	HoneycombLifetime = 60,
	HoneycombBobAmplitude = 0.5,
	HoneycombBobPeriod = 2,
	HoneycombRotSpeed = 1,
	StingInterval = 15,
	StingChance = 0.7,
	StingRadius = 30,
	StingStunDuration = 1.5,
	StingKnockback = 80,
	StingUpKnockback = 35,
	StingDiveDuration = 0.45,
	StingHoverDuration = 0.25,
	StingReturnDuration = 0.7,
	StingHoverHeight = 8,
	QueenAggression = 1,
	BeeAltitude = 60,
	BeeOrbitRadius = 120,
	BeeWaypointSpeed = 40,
	BeeScale = 4,
	BeeBobAmplitude = 6,
	BeeBobPeriod = 4,
	HoneyTokenIcon = "rbxassetid://91733257075887",
	RollCycleDuration = 1.5,
	RollCycleStartInterval = 0.05,
	RollCycleEndInterval = 0.35,
	RollRevealScale = 1.3,
	RollHoldDuration = 3,
	RollConfettiCount = 40,
	RollGuiOffsetY = 10,
	RollGuiSize = Vector2.new(8, 10),
	AssetsPath = { "Events", "QueenBee" },
	WorldFolderPath = { "InteractiveEvents", "QueenBee" },
	HoneycombsPath = { "InteractiveEvents", "QueenBee", "Honeycombs" },
	HoneyTokensPath = { "InteractiveEvents", "QueenBee", "HoneyTokens" },
	RewardWeights = {
		{
			Name = "2MinTimeSkip",
			Weight = 58,
			Display = "2 Minute Time Skip",
			Icon = "rbxassetid://71048462380781",
			Model = "TimeskipBillboard"
		},
		{
			Name = "Honeysuckle",
			Weight = 35.25,
			Display = "Honeysuckle",
			Icon = "rbxassetid://133873295727596"
		},
		{
			Name = "QueenBeeFertilizer",
			Weight = 1,
			Display = "Queen Bee Fertilizer",
			Icon = "rbxassetid://77863557977881"
		},
		{
			Name = "15MinTimeSkip",
			Weight = 5,
			Display = "15 Minute Time Skip",
			Icon = "rbxassetid://71048462380781",
			Model = "TimeskipBillboard"
		},
		{
			Name = "QueensBlossom",
			Weight = 0.75,
			Display = "Queens Blossom",
			Icon = "rbxassetid://139834284110532"
		}
	}
}
function t.GetRewardEntry(p1) --[[ GetRewardEntry | Line: 69 | Upvalues: t (copy) ]]
	for i, v in ipairs(t.RewardWeights) do
		if v.Name == p1 then
			return v
		end
	end
	return nil
end
function t.GetHoneySpawnInterval(p1) --[[ GetHoneySpawnInterval | Line: 76 ]]
	local v1 = 5
	if p1 == 1 then
		return 5
	end
	if p1 == 2 or p1 == 3 then
		return 4
	end
	if p1 == 4 or p1 == 5 then
		return 3
	end
	if p1 == 6 then
		v1 = 2
	end
	return v1
end
function t.GetBeeBobOffset(p1) --[[ GetBeeBobOffset | Line: 91 | Upvalues: t (copy) ]]
	if t.BeeBobAmplitude <= 0 or t.BeeBobPeriod <= 0 then
		return 0
	else
		return math.sin(p1 / t.BeeBobPeriod * math.pi * 2) * t.BeeBobAmplitude
	end
end
return t