-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.TestsSuite.Specs.Definitions.spec
-- Class: ModuleScript

-- https://lua.expert/
return function() --[[ Line: 5 ]]
	local ReplicatedStorage = game:GetService("ReplicatedStorage")
	local Definitions = require(ReplicatedStorage.Shared.Contracts).Definitions
	local t = {
		Novice = {
			submit500MValue = {
				Target = 500000000,
				Category = "Flexible",
				Description = "Submit plants worth 500M total seed value"
			},
			submit2Frozen = {
				Target = 2,
				Category = "Specific",
				Description = "Submit 2 Frozen plants"
			},
			submit3PrismaticPlus = {
				Target = 3,
				Category = "Flexible",
				Description = "Submit 3 Prismatic+ plants"
			},
			submit1Worth250M = {
				Target = 1,
				Category = "Flexible",
				Description = "Submit 1 plant worth 250M+"
			}
		},
		Skilled = {
			submit5BValue = {
				Target = 5000000000,
				Category = "Flexible",
				Description = "Submit plants worth 5B total seed value"
			},
			submit1Void = {
				Target = 1,
				Category = "Specific",
				Description = "Submit 1 Void plant AND at least 5B submitted value"
			},
			submit3DivinePlus = {
				Target = 3,
				Category = "Flexible",
				Description = "Submit 3 Divine+ plants AND at least 5B submitted value"
			},
			submit1Worth1B = {
				Target = 1,
				Category = "Flexible",
				Description = "Submit 1 plant worth 1B+"
			}
		},
		Expert = {
			submit100BValue = {
				Target = 100000000000,
				Category = "Flexible",
				Description = "Submit plants worth 100B total seed value"
			},
			submit2Void = {
				Target = 2,
				Category = "Specific",
				Description = "Submit 2 Void plants AND at least 100B submitted value"
			},
			submit1Radioactive = {
				Target = 1,
				Category = "Specific",
				Description = "Submit 1 Radioactive plant AND at least 100B submitted value"
			},
			submit1ExoticPlus = {
				Target = 1,
				Category = "Flexible",
				Description = "Submit 1 Exotic+ plant AND at least 100B submitted value"
			}
		},
		Master = {
			submit5TValue = {
				Target = 5000000000000,
				Category = "Flexible",
				Description = "Submit plants worth 5T total seed value"
			},
			submit2Radioactive = {
				Target = 2,
				Category = "Specific",
				Description = "Submit 2 Radioactive plants AND at least 5T submitted value"
			},
			submit1Transcended = {
				Target = 1,
				Category = "Specific",
				Description = "Submit 1 Transcended plant AND at least 5T submitted value"
			},
			submit1Rainbow = {
				Target = 1,
				Category = "Chase",
				Description = "Submit 1 Rainbow plant AND at least 5T submitted value"
			}
		},
		Transcendent = {
			submit50TValue = {
				Target = 50000000000000,
				Category = "Flexible",
				Description = "Submit plants worth 50T total seed value"
			},
			submit2Radioactive = {
				Target = 2,
				Category = "Specific",
				Description = "Submit 2 Radioactive plants AND at least 50T submitted value"
			},
			submit1Transcended = {
				Target = 1,
				Category = "Specific",
				Description = "Submit 1 Transcended plant AND at least 50T submitted value"
			},
			submit1Rainbow = {
				Target = 1,
				Category = "Chase",
				Description = "Submit 1 Rainbow plant AND at least 50T submitted value"
			}
		}
	}
	local t2 = { "Novice", "Skilled", "Expert", "Master", "Transcendent" }
	describe("Definition tables", function() --[[ Line: 47 | Upvalues: t2 (copy), Definitions (copy), t (copy) ]]
		for v1, v2 in t2 do
			describe(v2, function() --[[ Line: 49 | Upvalues: Definitions (ref), v2 (copy), t (ref) ]]
				local v1 = Definitions[v2]
				it("exists as a table", function() --[[ Line: 52 | Upvalues: v1 (copy) ]]
					expect((type(v1))).to.equal("table")
				end)
				it("contains exactly 4 contracts", function() --[[ Line: 56 | Upvalues: v1 (copy) ]]
					local count = 0
					for v12 in v1 do
						count = count + 1
					end
					expect(count).to.equal(4)
				end)
				for v22, v3 in t[v2] do
					describe(v22, function() --[[ Line: 65 | Upvalues: v1 (copy), v22 (copy), v3 (copy) ]]
						local v12 = v1[v22]
						it("exists", function() --[[ Line: 68 | Upvalues: v12 (copy) ]]
							expect(v12).to.be.ok()
						end)
						it("has the planned Target", function() --[[ Line: 71 | Upvalues: v12 (copy), v3 (ref) ]]
							expect(v12.Target).to.equal(v3.Target)
						end)
						it("has the planned Category", function() --[[ Line: 74 | Upvalues: v12 (copy), v3 (ref) ]]
							expect(v12.Category).to.equal(v3.Category)
						end)
						it("has the planned Description", function() --[[ Line: 77 | Upvalues: v12 (copy), v3 (ref) ]]
							expect(v12.Description).to.equal(v3.Description)
						end)
					end)
				end
			end)
		end
	end)
	describe("GetById", function() --[[ Line: 86 | Upvalues: Definitions (copy) ]]
		it("resolves a valid id to its definition", function() --[[ Line: 87 | Upvalues: Definitions (ref) ]]
			local v1 = Definitions.GetById("Novice/submit2Frozen")
			expect(v1).to.be.ok()
			expect(v1.Description).to.equal("Submit 2 Frozen plants")
		end)
		it("returns nil for an unknown key within a known rank", function() --[[ Line: 92 | Upvalues: Definitions (ref) ]]
			expect(Definitions.GetById("Novice/doesNotExist")).never.to.be.ok()
		end)
		it("returns nil for an unknown rank", function() --[[ Line: 95 | Upvalues: Definitions (ref) ]]
			expect(Definitions.GetById("Bogus/whatever")).never.to.be.ok()
		end)
		it("returns nil for a malformed id without a slash", function() --[[ Line: 98 | Upvalues: Definitions (ref) ]]
			expect(Definitions.GetById("malformed")).never.to.be.ok()
		end)
	end)
	describe("GetRankForId", function() --[[ Line: 103 | Upvalues: Definitions (copy) ]]
		it("extracts the rank segment of an id", function() --[[ Line: 104 | Upvalues: Definitions (ref) ]]
			expect(Definitions.GetRankForId("Transcendent/submit50TValue")).to.equal("Transcendent")
			expect(Definitions.GetRankForId("Novice/submit500MValue")).to.equal("Novice")
		end)
		it("returns nil for a malformed id without a slash", function() --[[ Line: 108 | Upvalues: Definitions (ref) ]]
			expect(Definitions.GetRankForId("nope")).never.to.be.ok()
		end)
	end)
end