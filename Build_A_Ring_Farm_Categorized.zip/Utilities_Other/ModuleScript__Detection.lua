-- Path: ReplicatedStorage.Packages.Zone.Enum.Detection
-- Class: ModuleScript

-- https://lua.expert/
return {
	{ "WholeBody", 1 },
	{ "Centre", 2 }
}