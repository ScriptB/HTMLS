-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.ResetDisable
-- Class: LocalScript

-- https://lua.expert/
local StarterGui = game:GetService("StarterGui")
while true do
	local v1, v2 = pcall(StarterGui.SetCore, StarterGui, "ResetButtonCallback", false)
	_ = v2
	if v1 then
		break
	end
	task.wait()
end