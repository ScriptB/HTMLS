-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.FXInitializer.RainbowParts
-- Class: ModuleScript

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Timer = require(ReplicatedStorage.Shared.Timer)
local LowPerformanceMode = ReplicatedStorage:WaitForChild("LowPerformanceMode")
local LocalPlayer = Players.LocalPlayer
local CurrentCamera = workspace.CurrentCamera
local t = {}
local t2 = {}
local v1 = 1
local fromHSV = Color3.fromHSV
local clock = os.clock
local function RemovePart(p1) --[[ RemovePart | Line: 25 | Upvalues: t2 (copy), t (copy), v1 (ref) ]]
	if not t2[p1] then
		return
	end
	t2[p1] = nil
	local v12 = table.find(t, p1)
	if not v12 then
		return
	end
	table.remove(t, v12)
	if v12 < v1 then
		v1 = v1 - 1
	end
	if not (#t < v1) then
		return
	end
	v1 = 1
end
local function AddPart(p1) --[[ AddPart | Line: 47 | Upvalues: t2 (copy), t (copy) ]]
	if not t2[p1] then
		t2[p1] = math.random()
		table.insert(t, p1)
	end
end
local function GetCameraPosition() --[[ GetCameraPosition | Line: 56 | Upvalues: CurrentCamera (ref), LocalPlayer (copy) ]]
	if CurrentCamera then
		return CurrentCamera.CFrame.Position
	end
	local Character = LocalPlayer.Character
	if not Character then
		return nil
	end
	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
	if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
		return HumanoidRootPart.Position
	else
		return nil
	end
end
for v2, v3 in CollectionService:GetTagged("RainbowColorShift") do
	if v3:IsA("BasePart") and not t2[v3] then
		t2[v3] = math.random()
		table.insert(t, v3)
	end
end
CollectionService:GetInstanceAddedSignal("RainbowColorShift"):Connect(function(p1) --[[ Line: 80 | Upvalues: t2 (copy), t (copy) ]]
	if not p1:IsA("BasePart") then
		return
	end
	if t2[p1] then
		return
	end
	t2[p1] = math.random()
	table.insert(t, p1)
end)
CollectionService:GetInstanceRemovedSignal("RainbowColorShift"):Connect(function(p1) --[[ Line: 86 | Upvalues: t2 (copy), t (copy), v1 (ref) ]]
	if not p1:IsA("BasePart") then
		return
	end
	if not t2[p1] then
		return
	end
	t2[p1] = nil
	local v12 = table.find(t, p1)
	if not v12 then
		return
	end
	table.remove(t, v12)
	if v12 < v1 then
		v1 = v1 - 1
	end
	if not (#t < v1) then
		return
	end
	v1 = 1
end)
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function() --[[ Line: 92 | Upvalues: CurrentCamera (ref) ]]
	CurrentCamera = workspace.CurrentCamera
end)
Timer.Simple(0.05, function() --[[ Line: 96 | Upvalues: LowPerformanceMode (copy), t (copy), CurrentCamera (ref), LocalPlayer (copy), clock (copy), v1 (ref), fromHSV (copy), t2 (copy) ]]
	if LowPerformanceMode.Value then
		return
	end
	local v12 = #t
	if v12 == 0 then
		return
	end
	local v2
	if CurrentCamera then
		v2 = CurrentCamera.CFrame.Position
	else
		local Character = LocalPlayer.Character
		if Character then
			local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
			v2 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart.Position else nil
		else
			v2 = nil
		end
	end
	local v3 = clock() % 10 / 10
	local v5 = math.min(v1 + 200 - 1, v12)
	local v6 = false
	for i = v1, v5 do
		local v7 = t[i]
		if v7.Parent == nil then
			v6 = true
			continue
		end
		if not (v7.Transparency >= 1) then
			if v2 then
				local v8 = v7.Position - v2
				if not (v8:Dot(v8) > 62500) then
					v7.Color = fromHSV((v3 + t2[v7]) % 1, 1, 1)
				end
			else
				v7.Color = fromHSV((v3 + t2[v7]) % 1, 1, 1)
			end
		end
	end
	if v6 then
		for j = v12, 1, -1 do
			if t[j].Parent == nil then
				local v9 = t[j]
				if t2[v9] then
					t2[v9] = nil
					local v10 = table.find(t, v9)
					if v10 then
						table.remove(t, v10)
						if v10 < v1 then
							v1 = v1 - 1
						end
						if #t < v1 then
							v1 = 1
						end
					end
				end
			end
		end
	end
	v1 = if #t <= v5 then 1 else v5 + 1
end)
return 0