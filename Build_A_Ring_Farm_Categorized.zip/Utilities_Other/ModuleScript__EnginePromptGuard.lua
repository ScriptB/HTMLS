-- Path: ReplicatedStorage.Shared.EnginePromptGuard
-- Class: ModuleScript

-- https://lua.expert/
local GuiService = game:GetService("GuiService")
local MarketplaceService = game:GetService("MarketplaceService")
local LocalPlayer = game:GetService("Players").LocalPlayer
local v1 = 0
local v2 = 0
local v3 = 0
local function syncAttribute() --[[ syncAttribute | Line: 15 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end
local function Acquire() --[[ Acquire | Line: 23 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	v1 = v1 + 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end
local function Release() --[[ Release | Line: 28 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end
local function AcquireProductPurchase() --[[ AcquireProductPurchase | Line: 36 | Upvalues: v1 (ref), LocalPlayer (copy), v2 (ref) ]]
	v1 = v1 + 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") == v12 then
		v2 = v2 + 1
		return
	end
	LocalPlayer:SetAttribute("EnginePromptActive", v12)
	v2 = v2 + 1
end
local function ReleaseProductPurchase() --[[ ReleaseProductPurchase | Line: 41 | Upvalues: v2 (ref), v1 (ref), LocalPlayer (copy) ]]
	if v2 <= 0 then
		return
	end
	v2 = v2 - 1
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end
local function AcquireGamePassPurchase() --[[ AcquireGamePassPurchase | Line: 49 | Upvalues: v1 (ref), LocalPlayer (copy), v3 (ref) ]]
	v1 = v1 + 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") == v12 then
		v3 = v3 + 1
		return
	end
	LocalPlayer:SetAttribute("EnginePromptActive", v12)
	v3 = v3 + 1
end
local function ReleaseGamePassPurchase() --[[ ReleaseGamePassPurchase | Line: 54 | Upvalues: v3 (ref), v1 (ref), LocalPlayer (copy) ]]
	if v3 <= 0 then
		return
	end
	v3 = v3 - 1
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end
GuiService.MenuOpened:Connect(function() --[[ Line: 62 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	v1 = v1 + 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end)
GuiService.MenuClosed:Connect(function() --[[ Line: 66 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end)
MarketplaceService.PromptProductPurchaseFinished:Connect(function(p1) --[[ Line: 70 | Upvalues: LocalPlayer (copy), v2 (ref), v1 (ref) ]]
	if p1 ~= LocalPlayer.UserId then
		return
	end
	if v2 <= 0 then
		return
	end
	v2 = v2 - 1
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end)
MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(p1) --[[ Line: 77 | Upvalues: LocalPlayer (copy), v3 (ref), v1 (ref) ]]
	if p1 ~= LocalPlayer then
		return
	end
	if v3 <= 0 then
		return
	end
	v3 = v3 - 1
	if v1 <= 0 then
		return
	end
	v1 = v1 - 1
	local v12 = v1 > 0
	if LocalPlayer:GetAttribute("EnginePromptActive") ~= v12 then
		LocalPlayer:SetAttribute("EnginePromptActive", v12)
	end
end)
return table.freeze({
	AttributeName = "EnginePromptActive",
	Acquire = Acquire,
	Release = Release,
	AcquireProductPurchase = AcquireProductPurchase,
	AcquireGamePassPurchase = AcquireGamePassPurchase
})