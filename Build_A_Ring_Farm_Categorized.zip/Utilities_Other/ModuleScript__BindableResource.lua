-- Path: ReplicatedStorage.CmdrClient.Types.BindableResource
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ Line: 1 ]]
	p1:RegisterType("bindableResource", p1.Cmdr.Util.MakeEnumType("BindableResource", { "Chat" }))
end