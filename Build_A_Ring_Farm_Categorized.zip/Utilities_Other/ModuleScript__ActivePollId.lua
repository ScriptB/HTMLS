-- Path: ReplicatedStorage.CmdrClient.Types.ActivePollId
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
return function(p1) --[[ Line: 4 | Upvalues: RunService (copy), ReplicatedStorage (copy) ]]
	local Util = p1.Cmdr.Util
	local t = {}
	if not RunService:IsServer() then
		local Polls = require(ReplicatedStorage.SparkMod.Polls)
		local GetActive = ReplicatedStorage.Remotes.Polls:WaitForChild("GetActive")
		local function refreshFromServer() --[[ refreshFromServer | Line: 13 | Upvalues: GetActive (copy), t (ref) ]]
			local v1, v2 = pcall(function() --[[ Line: 14 | Upvalues: GetActive (ref) ]]
				return GetActive:InvokeServer()
			end)
			if not v1 or typeof(v2) ~= "table" then
				return
			end
			local t2 = {}
			for v3 in v2 do
				table.insert(t2, v3)
			end
			table.sort(t2)
			t = t2
		end
		task.spawn(refreshFromServer)
		Polls.PollStarted:Connect(function() --[[ Line: 25 | Upvalues: refreshFromServer (copy) ]]
			task.spawn(refreshFromServer)
		end)
		Polls.PollEnded:Connect(function() --[[ Line: 26 | Upvalues: refreshFromServer (copy) ]]
			task.spawn(refreshFromServer)
		end)
	end
	local function getIds() --[[ getIds | Line: 29 | Upvalues: RunService (ref), t (ref) ]]
		if not RunService:IsServer() then
			return t
		end
		local t2 = {}
		for v1 in require(game.ServerScriptService.SparkMod.Services.Polls):GetActive() do
			table.insert(t2, v1)
		end
		table.sort(t2)
		return t2
	end
	p1:RegisterType("activePollId", {
		Transform = function(p1) --[[ Transform | Line: 44 | Upvalues: Util (copy), getIds (copy) ]]
			return Util.MakeFuzzyFinder((getIds()))(p1)
		end,
		Validate = function(p1) --[[ Validate | Line: 49 ]]
			return #p1 > 0, "No active poll with that ID found."
		end,
		Autocomplete = function(p1) --[[ Autocomplete | Line: 53 ]]
			return p1
		end,
		Parse = function(p1) --[[ Parse | Line: 57 ]]
			return p1[1]
		end
	})
end