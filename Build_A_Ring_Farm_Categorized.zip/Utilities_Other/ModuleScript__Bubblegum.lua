-- Path: ReplicatedStorage.Shared.MutationAppliers.Bubblegum
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Registry = require(ReplicatedStorage.Shared.Registry)
local MutationApplierUtil = require(ReplicatedStorage.Shared.MutationApplierUtil)
local v1 = Registry.Mutations[script.Name]
return function(p1) --[[ Line: 6 | Upvalues: MutationApplierUtil (copy), v1 (copy) ]]
	MutationApplierUtil.ApplyMainColor(p1, v1.MainColor)
	MutationApplierUtil.ApplyFolderVFX(p1, function(p1, p2) --[[ Line: 8 ]]
		for v1, v2 in script:GetChildren() do
			if v2:IsA("ParticleEmitter") or v2:IsA("Attachment") then
				v2:Clone().Parent = p1
			end
		end
	end)
end