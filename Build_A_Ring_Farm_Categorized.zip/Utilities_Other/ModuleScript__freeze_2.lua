-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.freeze
-- Class: ModuleScript

-- https://lua.expert/
local copy = require(script.Parent.copy)
require(script.Parent.Parent.Types)
return function(p1) --[[ freeze | Line: 23 | Upvalues: copy (copy) ]]
	local v1 = copy(p1)
	table.freeze(v1)
	return v1
end