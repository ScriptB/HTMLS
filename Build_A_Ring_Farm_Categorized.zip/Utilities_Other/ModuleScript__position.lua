-- Path: ReplicatedStorage.CmdrClient.Commands.position
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "position",
	Description = "Returns Vector3 position of you or other players. Empty string is the player has no character.",
	Group = "DefaultDebug",
	Aliases = { "pos" },
	Args = {
		{
			Type = "player",
			Name = "Player",
			Description = "The player to report the position of. Omit for your own position.",
			Default = game:GetService("Players").LocalPlayer
		}
	},
	ClientRun = function(p1, p2) --[[ ClientRun | Line: 17 ]]
		local Character = p2.Character
		if Character and Character:FindFirstChild("HumanoidRootPart") then
			return tostring(Character.HumanoidRootPart.Position):gsub("%s", "")
		else
			return ""
		end
	end
}