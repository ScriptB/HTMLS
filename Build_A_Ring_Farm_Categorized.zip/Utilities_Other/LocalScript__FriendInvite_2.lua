-- Path: StarterGui.MainUI.MoneyCounter.FriendBoostText.Btn.FriendInvite
-- Class: LocalScript

-- https://lua.expert/
local SocialService = game:GetService("SocialService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local EnginePromptGuard = require(ReplicatedStorage.Shared.EnginePromptGuard)
local LocalPlayer = Players.LocalPlayer
local v1 = script.Parent
SocialService.GameInvitePromptClosed:Connect(function() --[[ Line: 10 | Upvalues: EnginePromptGuard (copy) ]]
	EnginePromptGuard.Release()
end)
v1.MouseButton1Click:Connect(function() --[[ Line: 14 | Upvalues: SocialService (copy), LocalPlayer (copy), EnginePromptGuard (copy) ]]
	if not SocialService:CanSendGameInviteAsync(LocalPlayer) then
		return
	end
	EnginePromptGuard.Acquire()
	SocialService:PromptGameInvite(LocalPlayer)
end)