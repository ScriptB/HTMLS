-- Path: ReplicatedStorage.UserGenerated.IO.Crypto.Hash
-- Class: ModuleScript

-- https://lua.expert/
return {}