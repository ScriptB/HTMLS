-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.filter
-- Class: ModuleScript

-- https://lua.expert/
local Util = require(script.Parent.Parent.Util)
return function(p1, p2) --[[ filter | Line: 26 | Upvalues: Util (copy) ]]
	local t = {}
	if type(p2) ~= "function" then
		p2 = Util.func.truthy
	end
	for i, v in ipairs(p1) do
		if p2(v, i, p1) then
			table.insert(t, v)
		end
	end
	return t
end