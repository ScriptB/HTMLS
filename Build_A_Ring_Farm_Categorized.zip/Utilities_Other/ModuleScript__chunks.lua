-- Path: ReplicatedStorage.UserGenerated.Lottie.PNG.chunks
-- Class: ModuleScript

-- https://lua.expert/
return {
	IHDR = require(script.IHDR),
	PLTE = require(script.PLTE),
	tRNS = require(script.tRNS)
}