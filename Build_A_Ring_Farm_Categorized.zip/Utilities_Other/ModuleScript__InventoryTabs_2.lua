-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Modules.CustomPack.InventoryTabs
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	BackgroundTransparencySelected = 0.1,
	BackgroundTransparencyUnselected = 0.6,
	TextTransparencySelected = 0,
	TextTransparencyUnselected = 0.35,
	TextSize = 14,
	BorderTransparency = 0.8,
	BorderThickness = 1,
	Padding = 4,
	ZIndex = 5,
	Orientation = "Horizontal",
	BackgroundColor = Color3.fromRGB(25, 27, 29),
	TextColor = Color3.new(255/255, 255/255, 255/255),
	Font = Font.new("rbxasset://fonts/families/FredokaOne.json", Enum.FontWeight.Medium, Enum.FontStyle.Normal),
	CornerRadius = UDim.new(0, 3),
	BorderColor = Color3.new(255/255, 255/255, 255/255)
}
local function mergeStyle(p1) --[[ mergeStyle | Line: 62 | Upvalues: t (copy) ]]
	local v1 = table.clone(t)
	if p1 then
		for k, v in pairs(p1) do
			v1[k] = v
		end
	end
	return v1
end
local t2 = {}
t2.__index = t2
function t2._applyVisuals(p1) --[[ _applyVisuals | Line: 75 ]]
	local _style = p1._style
	for k, v in pairs(p1._buttons) do
		local v1 = if k == p1._active then true else false
		v.BackgroundTransparency = v1 and _style.BackgroundTransparencySelected or _style.BackgroundTransparencyUnselected
		v.TextTransparency = v1 and _style.TextTransparencySelected or _style.TextTransparencyUnselected
	end
end
function t2.new(p1) --[[ new | Line: 88 | Upvalues: t (copy), t2 (copy) ]]
	assert(p1.Parent, "InventoryTabs.new: Parent is required")
	assert(p1.Categories and (if #p1.Categories > 0 then true else false), "InventoryTabs.new: Categories must be non-empty")
	local Style = p1.Style
	local v3 = table.clone(t)
	if Style then
		for k, v in pairs(Style) do
			v3[k] = v
		end
	end
	local Categories = p1.Categories
	local v4 = v3.ZIndex or 5
	local v5 = (v3.Orientation or "Horizontal") == "Vertical"
	local InventoryTabBar = Instance.new("Frame")
	InventoryTabBar.Name = "InventoryTabBar"
	InventoryTabBar.BackgroundTransparency = 1
	InventoryTabBar.BorderSizePixel = 0
	InventoryTabBar.Active = true
	InventoryTabBar.ZIndex = v4
	InventoryTabBar.Size = p1.Size or UDim2.fromScale(1, 0)
	InventoryTabBar.Position = p1.Position or UDim2.new()
	if p1.AnchorPoint then
		InventoryTabBar.AnchorPoint = p1.AnchorPoint
	end
	InventoryTabBar.Parent = p1.Parent
	local v8 = v3.Padding or 4
	local v9, v10, v11 = v3, 1 / #Categories, {}
	for i, v in ipairs(Categories) do
		local TextButton = Instance.new("TextButton")
		TextButton.Name = v
		TextButton.Text = v
		TextButton.AutoButtonColor = false
		TextButton.BackgroundColor3 = v9.BackgroundColor
		TextButton.BorderSizePixel = 0
		TextButton.Active = true
		TextButton.Selectable = true
		TextButton.ZIndex = v4 + 1
		TextButton.TextColor3 = v9.TextColor
		TextButton.FontFace = v9.Font
		TextButton.TextSize = v9.TextSize
		TextButton.TextScaled = false
		TextButton.TextTruncate = Enum.TextTruncate.AtEnd
		if v5 then
			TextButton.Size = UDim2.new(1, 0, v10, -v8)
			TextButton.Position = UDim2.new(0, 0, v10 * (i - 1), v8 / 2)
		else
			TextButton.Size = UDim2.new(v10, -v8, 1, 0)
			TextButton.Position = UDim2.new(v10 * (i - 1), v8 / 2, 0, 0)
		end
		TextButton.Parent = InventoryTabBar
		local UICorner = Instance.new("UICorner")
		UICorner.CornerRadius = v9.CornerRadius
		UICorner.Parent = TextButton
		local UIStroke = Instance.new("UIStroke")
		UIStroke.Color = v9.BorderColor
		UIStroke.Transparency = v9.BorderTransparency
		UIStroke.Thickness = v9.BorderThickness
		UIStroke.Parent = TextButton
		v11[v] = TextButton
	end
	local t3 = {
		Frame = InventoryTabBar
	}
	t3._active = p1.Initial or Categories[1]
	t3._buttons = v11
	t3._onChanged = p1.OnChanged
	t3._style = v9
	local v14 = setmetatable(t3, t2)
	v14:_applyVisuals()
	for k, v in pairs(v11) do
		local function onClick() --[[ onClick | Line: 165 | Upvalues: v14 (copy), k (copy) ]]
			if v14._active == k then
				return
			end
			v14._active = k
			v14:_applyVisuals()
			local _onChanged = v14._onChanged
			if not _onChanged then
				return
			end
			_onChanged(k)
		end
		v.MouseButton1Click:Connect(onClick)
		v.Activated:Connect(onClick)
	end
	return v14
end
function t2.SetActive(p1, p2) --[[ SetActive | Line: 179 ]]
	if p1._active == p2 then
		return
	end
	if not p1._buttons[p2] then
		return
	end
	p1._active = p2
	p1:_applyVisuals()
	local _onChanged = p1._onChanged
	if not _onChanged then
		return
	end
	_onChanged(p2)
end
function t2.GetActive(p1) --[[ GetActive | Line: 188 ]]
	return p1._active
end
function t2.Destroy(p1) --[[ Destroy | Line: 192 ]]
	if p1.Frame then
		p1.Frame:Destroy()
		p1.Frame = nil
	end
	p1._buttons = {}
	p1._onChanged = nil
end
return t2