-- Path: ReplicatedStorage.Shared.Contracts.Definitions.Master
-- Class: ModuleScript

-- https://lua.expert/
local CreateContract = require(script.Parent.Parent.CreateContract)
return table.freeze({
	submit5TValue = CreateContract.seedValue(5000000000000, {
		Description = "Submit plants worth 5T total seed value",
		Category = "Flexible"
	}),
	submit2Radioactive = CreateContract.byMutation("Radioactive", 2, {
		Description = "Submit 2 Radioactive plants AND at least 5T submitted value",
		Category = "Specific",
		MinSubmittedValue = 5000000000000
	}),
	submit1Transcended = CreateContract.byRarity("Transcended", 1, {
		Description = "Submit 1 Transcended plant AND at least 5T submitted value",
		Category = "Specific",
		MinSubmittedValue = 5000000000000
	}),
	submit1Rainbow = CreateContract.byMutation("Rainbow", 1, {
		Description = "Submit 1 Rainbow plant AND at least 5T submitted value",
		Category = "Chase",
		MinSubmittedValue = 5000000000000
	})
})