-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.freezeDeep
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
local function v1(p1) --[[ freezeDeep | Line: 22 | Upvalues: v1 (copy) ]]
	local t = {}
	for k, v in pairs(p1) do
		if type(v) == "table" then
			t[k] = v1(v)
			continue
		end
		t[k] = v
	end
	table.freeze(t)
	return t
end
return v1