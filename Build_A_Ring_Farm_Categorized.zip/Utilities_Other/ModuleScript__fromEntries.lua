-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.fromEntries
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ fromEntries | Line: 17 ]]
	local t = {}
	for i, v in ipairs(p1) do
		t[v[1]] = v[2]
	end
	return t
end