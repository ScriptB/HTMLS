-- Path: ReplicatedStorage.CmdrClient.Commands.ban
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "ban",
	Description = "Bans a user by Roblox user id",
	Group = "Moderator",
	Aliases = {},
	Args = {
		{
			Type = "positiveInteger",
			Name = "userId",
			Description = "The Roblox user id to ban"
		},
		{
			Type = "string",
			Name = "reason",
			Description = "The reason for the ban"
		}
	}
}