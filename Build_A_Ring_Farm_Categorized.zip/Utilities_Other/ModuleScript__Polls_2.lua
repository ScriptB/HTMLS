-- Path: ReplicatedStorage.SparkMod.Types.Polls
-- Class: ModuleScript

-- https://lua.expert/
return {}