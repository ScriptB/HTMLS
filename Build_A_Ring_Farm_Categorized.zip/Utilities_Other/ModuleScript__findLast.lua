-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.findLast
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2, p3) --[[ findLast | Line: 20 ]]
	local v1 = #p1
	if type(p3) == "number" then
		if p3 < 1 then
			p3 = v1 + p3
		end
	else
		p3 = v1
	end
	for i = p3, 1, -1 do
		if p1[i] == p2 then
			return i
		end
	end
end