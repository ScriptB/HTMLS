-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Util.isEmpty
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
return function(p1) --[[ isEmpty | Line: 22 ]]
	return next(p1) == nil
end