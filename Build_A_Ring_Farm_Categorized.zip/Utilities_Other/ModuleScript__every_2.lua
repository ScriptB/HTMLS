-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.every
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ every | Line: 24 ]]
	for k, v in pairs(p1) do
		if not p2(v, k, p1) then
			return false
		end
	end
	return true
end