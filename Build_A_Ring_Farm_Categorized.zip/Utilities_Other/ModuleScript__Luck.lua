-- Path: ReplicatedStorage.CmdrClient.Commands.luck
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "luck",
	Description = "Server-wide seed luck bonus.",
	Group = "DefaultAdmin",
	Aliases = { "seedluck" },
	Args = {
		{
			Type = "luckScope",
			Name = "scope",
			Description = "global or local"
		},
		{
			Type = "number",
			Name = "bonus",
			Description = "Added seed luck"
		},
		{
			Type = "number",
			Name = "duration",
			Description = "Seconds (default 60)",
			Optional = true
		}
	}
}