-- Path: ReplicatedStorage.UserGenerated.Lang
-- Class: ModuleScript

-- https://lua.expert/
return {}