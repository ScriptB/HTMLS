-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.has
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ has | Line: 18 ]]
	return p1[p2] == true
end