-- Path: StarterGui.MainUI.Menus.SeedFrame.Sunrays.LocalScript
-- Class: LocalScript

-- https://lua.expert/
local TweenService = game:GetService("TweenService")
local v1 = script.Parent
local v2 = v1.Parent
local v3 = TweenInfo.new(10, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, false, 0)
local v4 = nil
local function startSpin() --[[ startSpin | Line: 19 | Upvalues: v4 (ref), v1 (copy), TweenService (copy), v3 (copy) ]]
	if not v4 then
		v1.Rotation = 0
		v4 = TweenService:Create(v1, v3, {
			Rotation = 360
		})
		v4:Play()
	end
end
local function stopSpin() --[[ stopSpin | Line: 30 | Upvalues: v4 (ref), v1 (copy) ]]
	if v4 then
		v4:Cancel()
		v4 = nil
	end
	v1.Rotation = 0
end
v2:GetPropertyChangedSignal("Visible"):Connect(function() --[[ Line: 40 | Upvalues: v2 (copy), v4 (ref), v1 (copy), TweenService (copy), v3 (copy) ]]
	if v2.Visible then
		if not v4 then
			v1.Rotation = 0
			v4 = TweenService:Create(v1, v3, {
				Rotation = 360
			})
			v4:Play()
		end
	else
		if v4 then
			v4:Cancel()
			v4 = nil
		end
		v1.Rotation = 0
	end
end)
if not v2.Visible or v4 then
	return
end
v1.Rotation = 0
v4 = TweenService:Create(v1, v3, {
	Rotation = 360
})
v4:Play()