-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.copy
-- Class: ModuleScript

-- https://lua.expert/
return table.clone