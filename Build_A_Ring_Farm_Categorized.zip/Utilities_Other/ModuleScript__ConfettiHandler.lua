-- Path: ReplicatedStorage.Shared.VFX.ConfettiHandler
-- Class: ModuleScript

-- https://lua.expert/
game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local LocalPlayer = Players.LocalPlayer
local ConfettiUI = LocalPlayer.PlayerGui:WaitForChild("ConfettiUI")
local ScreenShake = require(script.Parent.ScreenShake)
local SFXModule = require(script.Parent.Parent.SFXModule)
return {
	SpawnConfetti = function(p1) --[[ SpawnConfetti | Line: 16 | Upvalues: SFXModule (copy), ScreenShake (copy), LocalPlayer (copy), ConfettiUI (copy), TweenService (copy) ]]
		SFXModule.PlaySFX("Confetti")
		task.spawn(function() --[[ Line: 18 | Upvalues: ScreenShake (ref), LocalPlayer (ref) ]]
			ScreenShake.BigShake(LocalPlayer.Character, 1)
		end)
		for i = 1, p1 do
			local v1 = script:GetChildren()
			local v2 = v1[math.random(1, #v1)]:Clone()
			local v3 = math.random(0, 1000) / 1000
			local v4 = math.random(340, 780)
			v2.Position = UDim2.new(v3, 0, -0.2, 0)
			v2.Parent = ConfettiUI
			local v5 = TweenService:Create(v2, TweenInfo.new(0.7, Enum.EasingStyle.Sine), {
				Rotation = v4,
				Position = UDim2.fromScale(v3, 1.1)
			})
			v5:Play()
			v5.Completed:Connect(function() --[[ Line: 35 | Upvalues: v2 (copy) ]]
				v2:Destroy()
			end)
			task.wait(math.random(1, 3) / 100)
		end
	end
}