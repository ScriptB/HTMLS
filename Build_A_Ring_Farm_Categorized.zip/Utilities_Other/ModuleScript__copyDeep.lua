-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.copyDeep
-- Class: ModuleScript

-- https://lua.expert/
local function v1(p1) --[[ copyDeep | Line: 20 | Upvalues: v1 (copy) ]]
	local v12 = table.clone(p1)
	for k, v in pairs(p1) do
		if type(v) == "table" then
			v12[k] = v1(v)
		end
	end
	return v12
end
return v1