-- Path: Players.Asuneteric.PlayerScripts.PlayerScriptsLoader
-- Class: LocalScript

-- https://lua.expert/
require(script.Parent:WaitForChild("PlayerModule"))