-- Path: ReplicatedStorage.CmdrClient.Types.ConditionFunction
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ Line: 1 ]]
	p1:RegisterType("conditionFunction", p1.Cmdr.Util.MakeEnumType("ConditionFunction", { "startsWith" }))
end