-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.GiftingClient
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Maid = require(ReplicatedStorage.Shared.Maid)
local LocalPlayer = Players.LocalPlayer
local v1 = Maid.new()
local v2 = false
local v3 = nil
local function CreateGiftingPrompt(p1, p2) --[[ CreateGiftingPrompt | Line: 14 | Upvalues: LocalPlayer (copy), v1 (copy), ReplicatedStorage (copy), v3 (ref) ]]
	if p1 ~= LocalPlayer then
		local Attachment = Instance.new("Attachment")
		Attachment.Position = Vector3.new(0, 0, 0)
		Attachment.Parent = p2
		local ProximityPrompt = Instance.new("ProximityPrompt")
		ProximityPrompt.ActionText = ("Gift to %*"):format(p1.DisplayName)
		ProximityPrompt.Parent = Attachment
		v1:GiveTask(ProximityPrompt)
		v1:GiveTask(ProximityPrompt.Triggered:Connect(function() --[[ Line: 26 | Upvalues: ReplicatedStorage (ref), p1 (copy), v3 (ref) ]]
			ReplicatedStorage.Remotes.Gift:FireServer("Gift", p1, v3)
		end))
		v1:GiveTask(Attachment)
	end
end
local function ToggleGiftingPrompts(p1) --[[ ToggleGiftingPrompts | Line: 32 | Upvalues: v2 (ref), Players (copy), CreateGiftingPrompt (copy), v1 (copy) ]]
	if p1 then
		if v2 then
			return
		end
		v2 = true
		for v12, v22 in Players:GetPlayers() do
			if v22.Character then
				CreateGiftingPrompt(v22, v22.Character)
			end
			v22.CharacterAdded:Connect(function(p1) --[[ Line: 44 | Upvalues: CreateGiftingPrompt (ref), v22 (copy) ]]
				CreateGiftingPrompt(v22, p1)
			end)
		end
		v1:GiveTask(Players.PlayerAdded:Connect(function(p1) --[[ Line: 49 | Upvalues: CreateGiftingPrompt (ref) ]]
			if p1.Character then
				CreateGiftingPrompt(p1, p1.Character)
			end
			p1.CharacterAdded:Connect(function(p12) --[[ Line: 54 | Upvalues: CreateGiftingPrompt (ref), p1 (copy) ]]
				CreateGiftingPrompt(p1, p12)
			end)
		end))
	elseif v2 then
		v2 = false
		v1:DoCleaning()
	end
end
local function ListenForClientToolMovement(p1) --[[ ListenForClientToolMovement | Line: 69 | Upvalues: v3 (ref), ToggleGiftingPrompts (copy), v2 (ref), v1 (copy) ]]
	p1.ChildAdded:Connect(function(p1) --[[ Line: 70 | Upvalues: v3 (ref), ToggleGiftingPrompts (ref) ]]
		if p1:IsA("Tool") == false then
			return
		end
		if not p1:GetAttribute("NPCGuid") then
			return
		end
		v3 = p1:GetAttribute("NPCGuid")
		ToggleGiftingPrompts(true)
	end)
	p1.ChildRemoved:Connect(function(p1) --[[ Line: 79 | Upvalues: v3 (ref), v2 (ref), v1 (ref) ]]
		if p1:IsA("Tool") == false then
			return
		end
		if not p1:GetAttribute("NPCGuid") then
			return
		end
		v3 = p1:GetAttribute("NPCGuid")
		if not v2 then
			return
		end
		v2 = false
		v1:DoCleaning()
	end)
end
if LocalPlayer.Character then
	ListenForClientToolMovement(LocalPlayer.Character)
end
LocalPlayer.CharacterAdded:Connect(ListenForClientToolMovement)
return 0