-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.includes
-- Class: ModuleScript

-- https://lua.expert/
local find = require(script.Parent.find)
return function(p1, p2, p3) --[[ includes | Line: 28 | Upvalues: find (copy) ]]
	return find(p1, p2, p3) ~= nil
end