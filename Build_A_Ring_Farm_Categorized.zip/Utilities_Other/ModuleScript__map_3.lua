-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.map
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ map | Line: 20 ]]
	local t = {}
	for k, v in pairs(p1) do
		local v1 = p2(k, p1)
		if v1 ~= nil then
			t[v1] = true
		end
	end
	return t
end