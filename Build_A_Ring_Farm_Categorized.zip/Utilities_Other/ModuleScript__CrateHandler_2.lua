-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.ClientPlotHandler.CrateHandler
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local LocalPlayer = Players.LocalPlayer
local SellCrates = ReplicatedStorage.Remotes.SellCrates
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local PopUpEffect = require(ReplicatedStorage.Shared.VFX.PopUpEffect)
local CratesPickupPrompt = ReplicatedStorage.Assets.UI.Prompts.CratesPickupPrompt
local v1 = false
local v2 = nil
local v3 = nil
local v4 = false
local v5 = nil
local v6 = CFrame.new(0, 0, -3) * CFrame.Angles(0, 0, 0)
local function PlayHoldAnimation() --[[ PlayHoldAnimation | Line: 41 | Upvalues: LocalPlayer (copy), v3 (ref) ]]
	local Character = LocalPlayer.Character
	if not Character then
		return
	end
	local Humanoid = Character:FindFirstChildOfClass("Humanoid")
	if not Humanoid then
		return
	end
	local Animator = Humanoid:FindFirstChildOfClass("Animator")
	if Animator then
		local Animation = Instance.new("Animation")
		Animation.AnimationId = "rbxassetid://91474375912022"
		v3 = Animator:LoadAnimation(Animation)
		v3.Looped = true
		v3.Priority = Enum.AnimationPriority.Action
		v3:Play()
		Animation:Destroy()
	end
end
local function StopHoldAnimation() --[[ StopHoldAnimation | Line: 64 | Upvalues: v3 (ref) ]]
	if not v3 then
		return
	end
	v3:Stop()
	v3:Destroy()
	v3 = nil
end
local function PickupCrates(p1) --[[ PickupCrates | Line: 76 | Upvalues: v1 (ref), LocalPlayer (copy), v2 (ref), v6 (copy), PlayHoldAnimation (copy) ]]
	if v1 then
		warn("ALREADY HOLDING")
		return
	end
	local Character = LocalPlayer.Character
	if not Character then
		warn("NO CHARACTER")
		return
	end
	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
	if not HumanoidRootPart then
		warn("NO HRP")
		return
	end
	local Crates = p1:FindFirstChild("Crates")
	if not Crates then
		warn("NO CRATE FOLDER")
		return
	end
	local v12 = Crates:GetChildren()
	if #v12 == 0 then
		warn("NO CRATES")
		return
	end
	v1 = true
	v2 = Instance.new("Model")
	v2.Name = "HeldCrates"
	local v22 = v12[1]
	v22:GetPivot()
	for i, v in ipairs(v12) do
		v.Parent = v2
	end
	local Center = v22:FindFirstChild("Center")
	if Center then
		v2.PrimaryPart = Center
	end
	v2.Parent = Character
	for i, v in ipairs(v2:GetDescendants()) do
		if v:IsA("BasePart") then
			v.CanCollide = false
			v.Massless = true
		end
	end
	if v2.PrimaryPart then
		for i, v in ipairs(v2:GetDescendants()) do
			if v:IsA("BasePart") and v ~= v2.PrimaryPart then
				local WeldConstraint = Instance.new("WeldConstraint")
				WeldConstraint.Part0 = v2.PrimaryPart
				WeldConstraint.Part1 = v
				WeldConstraint.Parent = v
			end
		end
		v2.PrimaryPart.CFrame = HumanoidRootPart.CFrame * v6
		local CrateHoldWeld = Instance.new("WeldConstraint")
		CrateHoldWeld.Name = "CrateHoldWeld"
		CrateHoldWeld.Part0 = HumanoidRootPart
		CrateHoldWeld.Part1 = v2.PrimaryPart
		CrateHoldWeld.Parent = v2.PrimaryPart
		for i, v in ipairs(v2:GetDescendants()) do
			if v:IsA("BasePart") then
				v.Anchored = false
			end
		end
	end
	local CratePosition = p1:FindFirstChild("CratePosition")
	if CratePosition then
		local CratesPickupPrompt = CratePosition:FindFirstChild("CratesPickupPrompt")
		if CratesPickupPrompt then
			CratesPickupPrompt.Enabled = false
		end
	end
	PlayHoldAnimation()
end
local function DropCrates() --[[ DropCrates | Line: 162 | Upvalues: v1 (ref), v3 (ref), v2 (ref), v4 (ref) ]]
	if not v1 then
		return
	end
	if v3 then
		v3:Stop()
		v3:Destroy()
		v3 = nil
	end
	if not v2 then
		v1 = false
		v4 = false
		return
	end
	v2:Destroy()
	v2 = nil
	v1 = false
	v4 = false
end
local function SellCratesAnimated() --[[ SellCratesAnimated | Line: 180 | Upvalues: v1 (ref), v2 (ref), v4 (ref), v3 (ref), v5 (ref), TweenService (copy), SFXModule (copy) ]]
	if not (v1 and v2) then
		return
	end
	if v4 then
		return
	end
	v4 = true
	if v3 then
		v3:Stop()
		v3:Destroy()
		v3 = nil
	end
	local v12 = v5 and v5:FindFirstChild("CratesSellPosition")
	if v12 then
		local WorldPosition = v12.WorldPosition
		local v22 = v12.WorldCFrame - v12.WorldCFrame.Position
		local v32 = WorldPosition
		if v5 then
			local Sell = v5:FindFirstChild("Sell")
			if Sell then
				local Desk = Sell:FindFirstChild("Desk")
				if Desk then
					local Food = Desk:FindFirstChild("Food")
					if Food then
						v32 = Food.WorldPosition
					end
				end
			end
		end
		local SellCratesAnim = Instance.new("Model")
		SellCratesAnim.Name = "SellCratesAnim"
		local list = {}
		local t = {}
		for i, v in ipairs(v2:GetChildren()) do
			if v:IsA("Model") then
				local v42 = v:Clone()
				table.insert(list, v42)
				t[v42] = v42:FindFirstChild("Center") or v42.PrimaryPart
				v42.Parent = SellCratesAnim
			end
		end
		if v2 then
			v2:Destroy()
			v2 = nil
		end
		table.sort(list, function(p1, p2) --[[ Line: 237 ]]
			return p1.Name < p2.Name
		end)
		for i, v in ipairs(list) do
			for i2, v6 in ipairs(v:GetDescendants()) do
				if v6:IsA("WeldConstraint") then
					v6:Destroy()
				end
				if v6:IsA("BasePart") then
					v6.Anchored = true
					v6.CanCollide = false
				end
			end
		end
		SellCratesAnim.Parent = workspace
		for i, v in ipairs(list) do
			local v6 = CFrame.new(WorldPosition + Vector3.new(0, (i - 1) * 2.826, 0)) * v22
			local v7 = t[v]
			if v7 and v7.Parent then
				v7.CFrame = v6
				for i2, v8 in ipairs(v:GetDescendants()) do
					if v8:IsA("BasePart") and v8 ~= v7 then
						v8.Anchored = false
						v8.Massless = true
						local WeldConstraint = Instance.new("WeldConstraint")
						WeldConstraint.Part0 = v7
						WeldConstraint.Part1 = v8
						WeldConstraint.Parent = v8
					end
				end
			end
		end
		local list2 = {}
		for i = #list, 1, -1 do
			table.insert(list2, list[i])
		end
		local v9 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		local sum = 1
		for i, v in ipairs(list2) do
			local v10 = t[v]
			if v10 and v10.Parent then
				local v11 = TweenService:Create(v10, v9, {
					CFrame = CFrame.new(v32)
				})
				local v122 = sum
				task.delay(0.1 * (i - 1), function() --[[ Line: 306 | Upvalues: v10 (copy), v11 (copy), v (copy), v122 (copy), SFXModule (ref), v32 (ref) ]]
					if not (v10 and v10.Parent) then
						return
					end
					v11:Play()
					v11.Completed:Wait()
					if not (v and v.Parent) then
						return
					end
					SFXModule.PlaySFX("Pop", false, v32, (math.clamp(v122, 1, 1.6)))
					v:Destroy()
				end)
				sum = sum + 0.1
				continue
			end
			if v.Parent then
				v:Destroy()
			end
		end
		task.delay((#list2 - 1) * 0.1 + 0.3 + 0.1, function() --[[ Line: 322 | Upvalues: SellCratesAnim (copy), v1 (ref), v4 (ref) ]]
			if not (SellCratesAnim and SellCratesAnim.Parent) then
				v1 = false
				v4 = false
				return
			end
			SellCratesAnim:Destroy()
			v1 = false
			v4 = false
		end)
	else
		if not v1 then
			return
		end
		if v3 then
			v3:Stop()
			v3:Destroy()
			v3 = nil
		end
		if v2 then
			v2:Destroy()
			v2 = nil
		end
		v1 = false
		v4 = false
	end
end
return function(p1) --[[ Line: 335 | Upvalues: v5 (ref), CratesPickupPrompt (copy), v1 (ref), LocalPlayer (copy), PickupCrates (copy), SellCrates (copy), PopUpEffect (copy), SellCratesAnimated (copy), v3 (ref), v2 (ref), v4 (ref), ReplicatedStorage (copy) ]]
	v5 = p1
	local CratePosition = p1:WaitForChild("CratePosition", 10)
	if not CratePosition then
		return
	end
	local CratesPickupPrompt_2 = CratePosition:FindFirstChild("CratesPickupPrompt")
	if CratesPickupPrompt_2 then
		CratesPickupPrompt_2:Destroy()
	end
	local v12 = CratesPickupPrompt:Clone()
	v12.Parent = CratePosition
	local function SyncPromptEnabled() --[[ SyncPromptEnabled | Line: 352 | Upvalues: CratePosition (copy), p1 (copy), v12 (copy), v1 (ref) ]]
		local v13 = CratePosition:GetAttribute("HasCrates")
		if v13 == nil then
			local Crates = p1:FindFirstChild("Crates")
			v13 = if Crates then #Crates:GetChildren() > 0 else Crates
		end
		v12.Enabled = if v13 then not v1 else v13
	end
	local v22 = CratePosition:GetAttribute("HasCrates")
	if v22 == nil then
		local Crates = p1:FindFirstChild("Crates")
		v22 = if Crates then #Crates:GetChildren() > 0 else Crates
	end
	v12.Enabled = if v22 then not v1 else v22
	CratePosition:GetAttributeChangedSignal("HasCrates"):Connect(SyncPromptEnabled)
	task.spawn(function() --[[ Line: 365 | Upvalues: CratePosition (copy), p1 (copy), v12 (copy), v1 (ref) ]]
		repeat
			local v13 = CratePosition:GetAttribute("HasCrates")
			if v13 == nil then
				local Crates = p1:FindFirstChild("Crates")
				v13 = if Crates then #Crates:GetChildren() > 0 else Crates
			end
			v12.Enabled = if v13 then not v1 else v13
			task.wait(5)
		until v13 == nil
	end)
	v12.Triggered:Connect(function(p12) --[[ Line: 373 | Upvalues: LocalPlayer (ref), PickupCrates (ref), p1 (copy) ]]
		if p12 == LocalPlayer then
			print("PICKING UP")
			PickupCrates(p1)
		else
			warn("WRONG PLAYER")
		end
	end)
	SellCrates.OnClientEvent:Connect(function(p1) --[[ Line: 380 | Upvalues: PopUpEffect (ref), SellCratesAnimated (ref) ]]
		PopUpEffect.SpawnPopUp(p1)
		SellCratesAnimated()
	end)
	LocalPlayer.CharacterRemoving:Connect(function() --[[ Line: 386 | Upvalues: v1 (ref), v3 (ref), v2 (ref), v4 (ref) ]]
		if not v1 then
			return
		end
		if v3 then
			v3:Stop()
			v3:Destroy()
			v3 = nil
		end
		if not v2 then
			v1 = false
			v4 = false
			return
		end
		v2:Destroy()
		v2 = nil
		v1 = false
		v4 = false
	end)
	ReplicatedStorage.Remotes.PopUp.OnClientEvent:Connect(function(p1) --[[ Line: 390 | Upvalues: PopUpEffect (ref) ]]
		PopUpEffect.SpawnPopUp(p1)
	end)
end