-- Path: ReplicatedStorage.CmdrClient.Types.AnnouncementType
-- Class: ModuleScript

-- https://lua.expert/
game:GetService("ReplicatedStorage")
local t = { "global", "server" }
return function(p1) --[[ Line: 4 | Upvalues: t (copy) ]]
	p1:RegisterType("announcementType", {
		Transform = function(p1) --[[ Transform | Line: 6 | Upvalues: t (ref) ]]
			local list = {}
			local t2 = {}
			for k, v in pairs(t) do
				table.insert(list, v)
			end
			local v1 = p1:lower()
			for i, v in ipairs(list) do
				if v:lower():find(v1, 1, true) then
					table.insert(t2, v)
				end
			end
			table.sort(t2, function(p1, p2) --[[ Line: 21 | Upvalues: v1 (copy) ]]
				local v12 = if p1:lower() == v1 then true else false
				local v2 = if p2:lower() == v1 then true else false
				if v12 and not v2 then
					return true
				end
				if v2 and not v12 then
					return false
				end
				return p1 < p2
			end)
			return t2
		end,
		Validate = function(p1) --[[ Validate | Line: 32 ]]
			return #p1 > 0, "No type with that name could be found."
		end,
		Autocomplete = function(p1) --[[ Autocomplete | Line: 36 ]]
			return p1
		end,
		Parse = function(p1) --[[ Parse | Line: 40 ]]
			return p1[1]
		end
	})
end