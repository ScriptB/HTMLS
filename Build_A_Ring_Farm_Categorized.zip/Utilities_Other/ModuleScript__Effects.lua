-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.ContractsClient.Effects
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PlayVFX = require(ReplicatedStorage.UserGenerated.VFX.PlayVFX)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local LocalPlayer = Players.LocalPlayer
local PlantContracts = ReplicatedStorage.Assets.VFX.PlantContracts
local t = {}
local function GetCharacterRoot() --[[ GetCharacterRoot | Line: 18 | Upvalues: LocalPlayer (copy) ]]
	local Character = LocalPlayer.Character
	if not Character then
		return nil
	end
	local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
	if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then
		return HumanoidRootPart
	else
		return nil
	end
end
local function PlayCharacterVfx(p1) --[[ PlayCharacterVfx | Line: 30 | Upvalues: PlantContracts (copy), LocalPlayer (copy), PlayVFX (copy) ]]
	local v1 = PlantContracts:FindFirstChild(p1)
	if not v1 then
		return
	end
	local Character = LocalPlayer.Character
	local v2
	if Character then
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		v2 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
	else
		v2 = nil
	end
	if v2 then
		PlayVFX(v2, v2.CFrame, v1:Clone())
	end
end
function t.PlayRankUp() --[[ PlayRankUp | Line: 44 | Upvalues: SFXModule (copy), PlantContracts (copy), LocalPlayer (copy), PlayVFX (copy) ]]
	SFXModule.PlaySFX("Contracts_RankUp")
	local contractupgrade = PlantContracts:FindFirstChild("contractupgrade")
	if not contractupgrade then
		return
	end
	local Character = LocalPlayer.Character
	local v1
	if Character then
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		v1 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
	else
		v1 = nil
	end
	if v1 then
		PlayVFX(v1, v1.CFrame, contractupgrade:Clone())
	end
end
function t.PlayComplete() --[[ PlayComplete | Line: 49 | Upvalues: SFXModule (copy), PlantContracts (copy), LocalPlayer (copy), PlayVFX (copy) ]]
	SFXModule.PlaySFX("Contracts_Completed")
	local contractcomplete = PlantContracts:FindFirstChild("contractcomplete")
	if not contractcomplete then
		return
	end
	local Character = LocalPlayer.Character
	local v1
	if Character then
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		v1 = if HumanoidRootPart and HumanoidRootPart:IsA("BasePart") then HumanoidRootPart else nil
	else
		v1 = nil
	end
	if v1 then
		PlayVFX(v1, v1.CFrame, contractcomplete:Clone())
	end
end
function t.PlayReroll() --[[ PlayReroll | Line: 54 | Upvalues: SFXModule (copy) ]]
	SFXModule.PlaySFX("Contracts_Reroll")
end
function t.PlayFeed() --[[ PlayFeed | Line: 58 | Upvalues: SFXModule (copy) ]]
	SFXModule.PlaySFX("Pop")
end
return table.freeze(t)