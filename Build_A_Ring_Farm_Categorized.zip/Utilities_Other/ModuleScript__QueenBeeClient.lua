-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.QueenBeeClient
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local QueenBeeConfig = require(ReplicatedStorage.Shared.QueenBeeConfig)
local DataAggregation = require(script.Parent.Parent.Modules.DataAggregation)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local SharedUtils = require(ReplicatedStorage.Shared.SharedUtils)
require(ReplicatedStorage.Shared.VFX.ConfettiHandler)
local Registry = require(ReplicatedStorage.Shared.Registry)
local RandomItemRoll = require(ReplicatedStorage.Shared.RandomItemRoll)
local QueenBee = ReplicatedStorage.Remotes:WaitForChild("QueenBee")
local HoneycombSpawned = QueenBee:WaitForChild("HoneycombSpawned")
local HoneycombClaimed = QueenBee:WaitForChild("HoneycombClaimed")
local BeeStingFx = QueenBee:WaitForChild("BeeStingFx")
local RollResult = QueenBee:WaitForChild("RollResult")
local Sync = QueenBee:WaitForChild("Sync")
local function isHoneyTokenTool(p1) --[[ isHoneyTokenTool | Line: 32 ]]
	if not (p1 and p1:IsA("Tool")) then
		return false
	end
	if p1:GetAttribute("HoneyTokenTool") == true then
		return true
	end
	return p1.Name == "Honey Token"
end
local LocalPlayer = Players.LocalPlayer
local function safePlaySfx(p1, p2) --[[ safePlaySfx | Line: 42 | Upvalues: SFXModule (copy) ]]
	pcall(function() --[[ Line: 43 | Upvalues: p2 (copy), SFXModule (ref), p1 (copy) ]]
		if p2 then
			SFXModule.PlaySFX(p1, false, p2, 1)
		else
			SFXModule.PlaySFX(p1)
		end
	end)
end
local function getQueenBeeAsset(p1) --[[ getQueenBeeAsset | Line: 52 | Upvalues: ReplicatedStorage (copy), QueenBeeConfig (copy) ]]
	local Assets = ReplicatedStorage:FindFirstChild("Assets")
	for i, v in ipairs(QueenBeeConfig.AssetsPath) do
		local v1 = if Assets then Assets:FindFirstChild(v) else Assets
		if not v1 then
			return nil
		end
		Assets = v1
	end
	return Assets:FindFirstChild(p1)
end
local function getAssetByName(p1) --[[ getAssetByName | Line: 61 | Upvalues: getQueenBeeAsset (copy), ReplicatedStorage (copy) ]]
	local v1 = getQueenBeeAsset(p1)
	if v1 then
		return v1
	end
	local Assets = ReplicatedStorage:FindFirstChild("Assets")
	return if Assets then Assets:FindFirstChild(p1) else Assets
end
local function getHudChip() --[[ getHudChip | Line: 68 | Upvalues: LocalPlayer (copy) ]]
	local MainUI = LocalPlayer:WaitForChild("PlayerGui"):FindFirstChild("MainUI")
	if not MainUI then
		return nil
	end
	local HoneyTokenHud = MainUI:FindFirstChild("HoneyTokenHud", true)
	if HoneyTokenHud and HoneyTokenHud:IsA("TextLabel") then
		return HoneyTokenHud
	else
		return nil
	end
end
local function setHudChip(p1) --[[ setHudChip | Line: 77 | Upvalues: LocalPlayer (copy) ]]
	local MainUI = LocalPlayer:WaitForChild("PlayerGui"):FindFirstChild("MainUI")
	local v1
	if MainUI then
		local HoneyTokenHud = MainUI:FindFirstChild("HoneyTokenHud", true)
		v1 = if HoneyTokenHud and HoneyTokenHud:IsA("TextLabel") then HoneyTokenHud else nil
	else
		v1 = nil
	end
	if v1 then
		v1.Text = "Insert The Honey Token into The Honey Pot!"
		v1.Visible = p1
	end
end
local function showHoneyTokenInfo() --[[ showHoneyTokenInfo | Line: 84 | Upvalues: LocalPlayer (copy), getQueenBeeAsset (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not PlayerGui then
		return
	end
	if PlayerGui:FindFirstChild("HoneyTokenInfo") then
		return
	end
	local v1 = getQueenBeeAsset("HoneyTokenInfo")
	if v1 and v1:IsA("ScreenGui") then
		v1:Clone().Parent = PlayerGui
	end
end
local function hideHoneyTokenInfo() --[[ hideHoneyTokenInfo | Line: 93 | Upvalues: LocalPlayer (copy) ]]
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not PlayerGui then
		return
	end
	local HoneyTokenInfo = PlayerGui:FindFirstChild("HoneyTokenInfo")
	if not HoneyTokenInfo then
		return
	end
	HoneyTokenInfo:Destroy()
end
local function characterHasHoneyToken(p1) --[[ characterHasHoneyToken | Line: 100 ]]
	if not p1 then
		return false
	end
	for i, v in ipairs(p1:GetChildren()) do
		if if v and v:IsA("Tool") then if v:GetAttribute("HoneyTokenTool") == true then true elseif v.Name == "Honey Token" then true else false else false then
			return true
		end
	end
	return false
end
local function bindCharacterTokenWatch(p1) --[[ bindCharacterTokenWatch | Line: 108 | Upvalues: characterHasHoneyToken (copy), showHoneyTokenInfo (copy), LocalPlayer (copy) ]]
	local v1, v2
	if not characterHasHoneyToken(p1) then
		v1 = p1.ChildAdded:Connect(function(p1_2) --[[ Line: 113 | Upvalues: showHoneyTokenInfo (ref) ]]
			if not (if p1_2 and p1_2:IsA("Tool") then if p1_2:GetAttribute("HoneyTokenTool") == true then true else p1_2.Name == "Honey Token" else false) then
				return
			end
			showHoneyTokenInfo()
		end)
		v2 = p1.ChildRemoved:Connect(function(p1_2) --[[ Line: 118 | Upvalues: LocalPlayer (ref) ]]
			if not (if p1_2 and p1_2:IsA("Tool") then if p1_2:GetAttribute("HoneyTokenTool") == true then true else p1_2.Name == "Honey Token" else false) then
				return
			end
			local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
			if not PlayerGui then
				return
			end
			local HoneyTokenInfo = PlayerGui:FindFirstChild("HoneyTokenInfo")
			if not HoneyTokenInfo then
				return
			end
			HoneyTokenInfo:Destroy()
		end)
		LocalPlayer.CharacterRemoving:Once(function(p12_2) --[[ Line: 124 | Upvalues: p1 (copy), v1 (copy), v2 (copy), LocalPlayer (ref) ]]
			if p12_2 ~= p1 then
				return
			end
			v1:Disconnect()
			v2:Disconnect()
			local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
			if not PlayerGui then
				return
			end
			local HoneyTokenInfo = PlayerGui:FindFirstChild("HoneyTokenInfo")
			if not HoneyTokenInfo then
				return
			end
			HoneyTokenInfo:Destroy()
		end)
		return
	end
	showHoneyTokenInfo()
	v1 = p1.ChildAdded:Connect(function(p1_2) --[[ Line: 113 | Upvalues: showHoneyTokenInfo (ref) ]]
		if not (if p1_2 and p1_2:IsA("Tool") then if p1_2:GetAttribute("HoneyTokenTool") == true then true else p1_2.Name == "Honey Token" else false) then
			return
		end
		showHoneyTokenInfo()
	end)
	v2 = p1.ChildRemoved:Connect(function(p1_2) --[[ Line: 118 | Upvalues: LocalPlayer (ref) ]]
		if not (if p1_2 and p1_2:IsA("Tool") then if p1_2:GetAttribute("HoneyTokenTool") == true then true else p1_2.Name == "Honey Token" else false) then
			return
		end
		local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
		if not PlayerGui then
			return
		end
		local HoneyTokenInfo = PlayerGui:FindFirstChild("HoneyTokenInfo")
		if not HoneyTokenInfo then
			return
		end
		HoneyTokenInfo:Destroy()
	end)
	LocalPlayer.CharacterRemoving:Once(function(p12_2) --[[ Line: 124 | Upvalues: p1 (copy), v1 (copy), v2 (copy), LocalPlayer (ref) ]]
		if p12_2 ~= p1 then
			return
		end
		v1:Disconnect()
		v2:Disconnect()
		local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
		if not PlayerGui then
			return
		end
		local HoneyTokenInfo = PlayerGui:FindFirstChild("HoneyTokenInfo")
		if not HoneyTokenInfo then
			return
		end
		HoneyTokenInfo:Destroy()
	end)
end
LocalPlayer.CharacterAdded:Connect(bindCharacterTokenWatch)
if LocalPlayer.Character then
	task.spawn(bindCharacterTokenWatch, LocalPlayer.Character)
end
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local function destroyBee() --[[ destroyBee | Line: 144 | Upvalues: v4 (ref), v5 (ref), v6 (ref), v1 (ref), v2 (ref), v3 (ref) ]]
	if v4 then
		v4:Disconnect()
		v4 = nil
	end
	if v5 then
		pcall(function() --[[ Line: 147 | Upvalues: v5 (ref) ]]
			v5:Stop()
		end)
		v5 = nil
	end
	v6 = nil
	if not v1 then
		v2 = nil
		v3 = nil
		return
	end
	v1:Destroy()
	v1 = nil
	v2 = nil
	v3 = nil
end
local function getBeeTemplate() --[[ getBeeTemplate | Line: 159 | Upvalues: getQueenBeeAsset (copy) ]]
	local v1 = getQueenBeeAsset("QueenBee")
	if v1 and v1:IsA("Model") then
		return v1
	else
		return nil
	end
end
local function setupBeeAnimationsAndSound(p1) --[[ setupBeeAnimationsAndSound | Line: 165 | Upvalues: v5 (ref), v6 (ref) ]]
	local AnimationController = p1:FindFirstChildOfClass("AnimationController")
	local v1
	if AnimationController then
		local Animator = AnimationController:FindFirstChildOfClass("Animator")
		if not Animator then
			Animator = Instance.new("Animator")
			Animator.Parent = AnimationController
		end
		local Animations = p1:FindFirstChild("Animations")
		if Animations then
			local Fly = Animations:FindFirstChild("Fly")
			if Fly and Fly:IsA("Animation") then
				local v2, v3 = pcall(function() --[[ Line: 178 | Upvalues: Animator (ref), Fly (copy) ]]
					return Animator:LoadAnimation(Fly)
				end)
				if v2 and v3 then
					v3.Looped = true
					v3.Priority = Enum.AnimationPriority.Idle
					v3:Play()
				end
			end
			local Sting = Animations:FindFirstChild("Sting")
			if Sting and Sting:IsA("Animation") then
				local v4, v52 = pcall(function() --[[ Line: 188 | Upvalues: Animator (ref), Sting (copy) ]]
					return Animator:LoadAnimation(Sting)
				end)
				if v4 and v52 then
					v52.Looped = false
					v52.Priority = Enum.AnimationPriority.Action
					v5 = v52
				else
					v1 = p1:FindFirstChild("StingSound")
					if not (v1 and (v1:IsA("Sound") and p1.PrimaryPart)) then
						return
					end
					v1.Parent = p1.PrimaryPart
					v6 = v1
					return
				end
			else
				v1 = p1:FindFirstChild("StingSound")
				if not (v1 and (v1:IsA("Sound") and p1.PrimaryPart)) then
					return
				end
				v1.Parent = p1.PrimaryPart
				v6 = v1
				return
			end
		end
	end
	v1 = p1:FindFirstChild("StingSound")
	if not (v1 and (v1:IsA("Sound") and p1.PrimaryPart)) then
		return
	end
	v1.Parent = p1.PrimaryPart
	v6 = v1
end
local function computeOrbitPos(p1, p2) --[[ computeOrbitPos | Line: 205 | Upvalues: QueenBeeConfig (copy) ]]
	local v1 = p2 - p1.StartServerTime
	local BeeOrbitRadius = QueenBeeConfig.BeeOrbitRadius
	local v2 = p1.StartAngle + QueenBeeConfig.BeeWaypointSpeed / BeeOrbitRadius * v1
	local v3 = math.cos(v2) * BeeOrbitRadius
	local v4 = math.sin(v2) * BeeOrbitRadius
	return p1.CenterPos + Vector3.new(v3, QueenBeeConfig.BeeAltitude + QueenBeeConfig.GetBeeBobOffset(v1), v4), v2
end
local function easeInOutQuad(p1) --[[ easeInOutQuad | Line: 215 ]]
	if p1 < 0.5 then
		return p1 * 2 * p1
	else
		return 1 - (p1 * -2 + 2) ^ 2 / 2
	end
end
local function lerpVec(p1, p2, p3) --[[ lerpVec | Line: 220 ]]
	return p1 + (p2 - p1) * p3
end
local function computeBeeCFrame(p1) --[[ computeBeeCFrame | Line: 224 | Upvalues: v2 (ref), QueenBeeConfig (copy), v3 (ref) ]]
	local v1 = v2
	local v22 = p1 - v1.StartServerTime
	local BeeOrbitRadius = QueenBeeConfig.BeeOrbitRadius
	local v32 = v1.StartAngle + QueenBeeConfig.BeeWaypointSpeed / BeeOrbitRadius * v22
	local v4 = math.cos(v32) * BeeOrbitRadius
	local v5 = math.sin(v32) * BeeOrbitRadius
	local v7 = v1.CenterPos + Vector3.new(v4, QueenBeeConfig.BeeAltitude + QueenBeeConfig.GetBeeBobOffset(v22), v5)
	local v10 = Vector3.new(-math.sin(v32), 0, (math.cos(v32))) * QueenBeeConfig.BeeOrbitRadius
	if not v3 then
		return CFrame.lookAt(v7, v7 + v10)
	end
	local v11 = p1 - v3.StartServerTime
	local DiveDuration = v3.DiveDuration
	local HoverDuration = v3.HoverDuration
	local ReturnDuration = v3.ReturnDuration
	local v12 = DiveDuration + HoverDuration + ReturnDuration
	if v11 < 0 then
		return CFrame.lookAt(v7, v7 + v10)
	end
	if v11 < DiveDuration then
		local v13 = v11 / DiveDuration
		local BeePos = v3.BeePos
		return CFrame.lookAt(BeePos + (v3.HoverPos - BeePos) * (if v13 < 0.5 then v13 * 2 * v13 else 1 - (v13 * -2 + 2) ^ 2 / 2), v3.HitPos)
	else
		if v11 < DiveDuration + HoverDuration then
			return CFrame.lookAt(v3.HoverPos, v3.HitPos)
		end
		if not (v11 < v12) then
			v3 = nil
			return CFrame.lookAt(v7, v7 + v10)
		end
		local v16 = (v11 - DiveDuration - HoverDuration) / ReturnDuration
		local HoverPos = v3.HoverPos
		local v18 = HoverPos + (v7 - HoverPos) * (if v16 < 0.5 then v16 * 2 * v16 else 1 - (v16 * -2 + 2) ^ 2 / 2)
		return CFrame.lookAt(v18, v18 + v10)
	end
end
local function spawnBee(p1) --[[ spawnBee | Line: 258 | Upvalues: getQueenBeeAsset (copy), QueenBeeConfig (copy), Workspace (copy), v1 (ref), setupBeeAnimationsAndSound (copy), v4 (ref), RunService (copy), v2 (ref), computeBeeCFrame (copy) ]]
	local v12 = getQueenBeeAsset("QueenBee")
	local v22 = if v12 and v12:IsA("Model") then v12 else nil
	if not v22 then
		return
	end
	local v3 = v22:Clone()
	if not v3.PrimaryPart then
		v3.PrimaryPart = v3:FindFirstChild("RootPart") or v3:FindFirstChildWhichIsA("BasePart")
	end
	if not v3.PrimaryPart then
		v3:Destroy()
		return
	end
	if QueenBeeConfig.BeeScale and QueenBeeConfig.BeeScale ~= 1 then
		v3:ScaleTo(QueenBeeConfig.BeeScale)
	end
	for i, v in ipairs(v3:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Anchored = true
			v.CanCollide = false
		end
	end
	local v5 = workspace:GetServerTimeNow() - p1.StartServerTime
	local BeeOrbitRadius = QueenBeeConfig.BeeOrbitRadius
	local v6 = p1.StartAngle + QueenBeeConfig.BeeWaypointSpeed / BeeOrbitRadius * v5
	local v7 = math.cos(v6) * BeeOrbitRadius
	local v8 = math.sin(v6) * BeeOrbitRadius
	local v10 = p1.CenterPos + Vector3.new(v7, QueenBeeConfig.BeeAltitude + QueenBeeConfig.GetBeeBobOffset(v5), v8)
	v3:PivotTo(CFrame.lookAt(v10, v10 + Vector3.new(-math.sin(v6), 0, (math.cos(v6))) * QueenBeeConfig.BeeOrbitRadius))
	v3.Parent = Workspace
	v1 = v3
	setupBeeAnimationsAndSound(v3)
	v4 = RunService.Heartbeat:Connect(function() --[[ Line: 290 | Upvalues: v2 (ref), v1 (ref), computeBeeCFrame (ref) ]]
		if v2 and (v1 and v1.Parent) then
			v1:PivotTo(computeBeeCFrame(workspace:GetServerTimeNow()))
		end
	end)
end
local function startHoneycombFloat(p1) --[[ startHoneycombFloat | Line: 296 | Upvalues: RunService (copy), QueenBeeConfig (copy) ]]
	if p1:IsA("Model") then
		local Position = p1:GetPivot().Position
		local v1 = math.random() * math.pi * 2
		local v2 = os.clock()
		local v3 = nil
		v3 = RunService.Heartbeat:Connect(function() --[[ Line: 303 | Upvalues: p1 (copy), v3 (ref), v2 (copy), v1 (copy), QueenBeeConfig (ref), Position (copy) ]]
			if p1.Parent then
				local v12 = os.clock() - v2
				local v32 = math.sin(v1 + v12 / QueenBeeConfig.HoneycombBobPeriod * math.pi * 2) * QueenBeeConfig.HoneycombBobAmplitude
				p1:PivotTo(CFrame.new(Position + Vector3.new(0, v32, 0)) * CFrame.Angles(0, v12 * QueenBeeConfig.HoneycombRotSpeed, 0))
			else
				v3:Disconnect()
			end
		end)
	end
end
local function playRollAnimation(p1) --[[ playRollAnimation | Line: 317 | Upvalues: Registry (copy), QueenBeeConfig (copy), RandomItemRoll (copy) ]]
	local function toEntry(p1) --[[ toEntry | Line: 318 | Upvalues: Registry (ref) ]]
		if not p1 then
			return nil
		end
		local v1 = Registry.Plants[p1.Display]
		local t = {
			Icon = p1.Icon
		}
		t.Label = p1.Display or p1.Name
		t.Rarity = if v1 then v1.Rarity or nil else nil
		return t
	end
	local t = {}
	for i, v in ipairs(QueenBeeConfig.RewardWeights) do
		local v1
		if v then
			local v3 = Registry.Plants[v.Display]
			v1 = {
				Icon = v.Icon
			}
			v1.Label = v.Display or v.Name
			v1.Rarity = v3 and v3.Rarity or nil
		else
			v1 = nil
		end
		t[#t + 1] = v1
	end
	local t2 = {
		CycleSound = "Pop",
		RevealSound = "PopReveal"
	}
	local t3 = {}
	local t4 = {
		Pool = t
	}
	local v6 = QueenBeeConfig.GetRewardEntry(p1)
	local v7
	if v6 then
		local v8 = Registry.Plants[v6.Display]
		v7 = {
			Icon = v6.Icon
		}
		v7.Label = v6.Display or v6.Name
		v7.Rarity = v8 and v8.Rarity or nil
	else
		v7 = nil
	end
	if not v7 then
		v7 = {
			Label = p1
		}
	end
	t4.Result = v7
	t3[1] = t4
	t2.Columns = t3
	t2.CycleDuration = QueenBeeConfig.RollCycleDuration
	t2.StartInterval = QueenBeeConfig.RollCycleStartInterval
	t2.EndInterval = QueenBeeConfig.RollCycleEndInterval
	t2.RevealScale = QueenBeeConfig.RollRevealScale
	t2.HoldDuration = QueenBeeConfig.RollHoldDuration
	t2.ConfettiCount = QueenBeeConfig.RollConfettiCount
	RandomItemRoll.Play(t2)
end
Sync.OnClientEvent:Connect(function(p1) --[[ Line: 340 | Upvalues: destroyBee (copy), v2 (ref), spawnBee (copy) ]]
	if p1 and p1.Active then
		destroyBee()
		v2 = p1
		spawnBee(p1)
	else
		destroyBee()
	end
end)
HoneycombSpawned.OnClientEvent:Connect(function(p1, p2) --[[ Line: 350 | Upvalues: startHoneycombFloat (copy) ]]
	if not p1 or typeof(p1) ~= "Instance" then
		return
	end
	startHoneycombFloat(p1)
end)
HoneycombClaimed.OnClientEvent:Connect(function(p1, p2) --[[ Line: 356 | Upvalues: LocalPlayer (copy), SFXModule (copy) ]]
	if p2 ~= LocalPlayer then
		return
	end
	local v1 = nil
	local v2 = "Collect"
	pcall(function() --[[ Line: 43 | Upvalues: v1 (copy), SFXModule (ref), v2 (copy) ]]
		if v1 then
			SFXModule.PlaySFX(v2, false, v1, 1)
		else
			SFXModule.PlaySFX(v2)
		end
	end)
end)
BeeStingFx.OnClientEvent:Connect(function(p1) --[[ Line: 362 | Upvalues: v3 (ref), v5 (ref), v6 (ref), LocalPlayer (copy), SFXModule (copy) ]]
	if typeof(p1) ~= "table" then
		return
	end
	v3 = p1
	if v5 then
		pcall(function() --[[ Line: 366 | Upvalues: v5 (ref) ]]
			v5:Stop()
			v5:Play()
		end)
	end
	if v6 then
		pcall(function() --[[ Line: 372 | Upvalues: v6 (ref) ]]
			v6.TimePosition = 0
			v6:Play()
		end)
	end
	if p1.Target ~= LocalPlayer then
		return
	end
	task.delay(p1.DiveDuration, function() --[[ Line: 378 | Upvalues: SFXModule (ref) ]]
		local v1 = nil
		local v2 = "Hit"
		pcall(function() --[[ Line: 43 | Upvalues: v1 (copy), SFXModule (ref), v2 (copy) ]]
			if v1 then
				SFXModule.PlaySFX(v2, false, v1, 1)
			else
				SFXModule.PlaySFX(v2)
			end
		end)
	end)
end)
RollResult.OnClientEvent:Connect(function(p1) --[[ Line: 384 | Upvalues: playRollAnimation (copy) ]]
	task.spawn(playRollAnimation, p1)
end)
task.spawn(function() --[[ Line: 388 | Upvalues: DataAggregation (copy), QueenBeeConfig (copy), SharedUtils (copy), LocalPlayer (copy) ]]
	local v1 = DataAggregation.WaitForReplica()
	if not v1 then
		return
	end
	local HoneyTokensPath = QueenBeeConfig.HoneyTokensPath
	local function update() --[[ update | Line: 394 | Upvalues: SharedUtils (ref), v1 (copy), HoneyTokensPath (copy), LocalPlayer (ref) ]]
		local v12 = (SharedUtils.ReadNested(v1.Data, HoneyTokensPath) or 0) > 0
		local MainUI = LocalPlayer:WaitForChild("PlayerGui"):FindFirstChild("MainUI")
		local v2
		if MainUI then
			local HoneyTokenHud = MainUI:FindFirstChild("HoneyTokenHud", true)
			v2 = if HoneyTokenHud and HoneyTokenHud:IsA("TextLabel") then HoneyTokenHud else nil
		else
			v2 = nil
		end
		if v2 then
			v2.Text = "Insert The Honey Token into The Honey Pot!"
			v2.Visible = v12
		end
	end
	local v2 = (SharedUtils.ReadNested(v1.Data, HoneyTokensPath) or 0) > 0
	local MainUI = LocalPlayer:WaitForChild("PlayerGui"):FindFirstChild("MainUI")
	local v3
	if MainUI then
		local HoneyTokenHud = MainUI:FindFirstChild("HoneyTokenHud", true)
		v3 = if HoneyTokenHud and HoneyTokenHud:IsA("TextLabel") then HoneyTokenHud else nil
	else
		v3 = nil
	end
	if v3 then
		v3.Text = "Insert The Honey Token into The Honey Pot!"
		v3.Visible = v2
	end
	v1:OnSet(HoneyTokensPath, update)
end)
return {}