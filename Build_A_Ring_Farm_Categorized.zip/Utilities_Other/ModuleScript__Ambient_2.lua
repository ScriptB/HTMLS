-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.BackgroundSounds.Ambient
-- Class: ModuleScript

-- https://lua.expert/
local Ambient = game:GetService("SoundService").Ambient
local function Main() --[[ Main | Line: 6 | Upvalues: Ambient (copy) ]]
	for i, v in ipairs(Ambient:GetChildren()) do
		if v:IsA("Sound") then
			v.Looped = true
			v:Play()
		end
	end
end
task.spawn(Main)
return {}