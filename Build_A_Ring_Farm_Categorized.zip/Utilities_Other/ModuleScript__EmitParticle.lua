-- Path: ReplicatedStorage.Shared.VFXModule.Handlers.EmitParticle
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")
return function(p1, p2) --[[ Line: 4 | Upvalues: ReplicatedStorage (copy), Debris (copy) ]]
	local v1 = ReplicatedStorage.Assets.Particles:FindFirstChild(p2)
	if v1 then
		local Attachment = Instance.new("Attachment")
		Attachment.Parent = workspace.VFX_CONTAINER
		Attachment.Position = p1
		local v2 = v1:Clone()
		v2.Parent = Attachment
		v2:Emit(50)
		Debris:AddItem(v2, v2.Lifetime.Max)
	end
end