-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.insert
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2, ...) --[[ insert | Line: 21 ]]
	local count = #p1
	if p2 < 1 then
		p2 = p2 + (count + 1)
	end
	if count < p2 then
		if count + 1 < p2 then
			return p1
		end
		count = count + 1
		p2 = count + 1
	end
	local t = {}
	for i = 1, count do
		if i == p2 then
			for i2, v in ipairs({ ... }) do
				table.insert(t, v)
			end
		end
		table.insert(t, p1[i])
	end
	return t
end