-- Path: ReplicatedStorage.CmdrClient.Commands.givegear
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "givegear",
	Description = "Gives a player gear",
	Group = "DefaultAdmin",
	Aliases = { "gear", "addgear" },
	Args = {
		{
			Type = "players",
			Name = "players",
			Description = "The players to give the gear to"
		},
		{
			Type = "gearName",
			Name = "gear",
			Description = "the gear to give"
		},
		{
			Type = "number",
			Name = "Amount",
			Description = "The amount to give",
			Optional = false
		}
	}
}