-- Path: StarterPlayer.StarterPlayerScripts.Components.InvisibleComponent
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local v1 = require(ReplicatedStorage.Packages.Component).new({
	Tag = "Invisible",
	Ancestors = { workspace }
})
local function hasTransparency(p1) --[[ hasTransparency | Line: 10 ]]
	return (p1:IsA("BasePart") or p1:IsA("Decal")) and true or false
end
function v1.Start(p1) --[[ Start | Line: 18 ]]
	local v1 = p1.Instance
	if if v1:IsA("BasePart") or v1:IsA("Decal") then true else false then
		p1.Instance.Transparency = 1
	end
	for v4, v5 in p1.Instance:GetDescendants() do
		local v3
		v3 = (v5:IsA("BasePart") or v5:IsA("Decal")) and true or false
		if v3 then
			v5.Transparency = 1
		end
	end
end
return v1