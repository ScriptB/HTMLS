-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.UIController.GeneralControllers.BossHealthbar
-- Class: ModuleScript

-- https://lua.expert/
local t = {}
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local UserInputService = game:GetService("UserInputService")
local PlantRush = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("PlantRush")
local Sync = PlantRush:WaitForChild("Sync")
local PlantHit = PlantRush:WaitForChild("PlantHit")
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local v7 = false
local v8 = nil
local v9 = UDim2.fromScale(1, 0, 1, 0)
local v10 = nil
local t2 = {}
local function formatNumber(p1) --[[ formatNumber | Line: 32 ]]
	local v4 = tostring((math.max(0, (math.ceil(p1)))))
	local v5
	while true do
		local v6
		v5, v6 = string.gsub(v4, "^(-?%d+)(%d%d%d)", "%1,%2")
		if v6 <= 0 then
			break
		end
		v4 = v5
	end
	return v5
end
local function setVisible(p1) --[[ setVisible | Line: 45 | Upvalues: v3 (ref), UserInputService (copy) ]]
	if not v3 then
		return
	end
	v3.Visible = p1
	if UserInputService.TouchEnabled and not (UserInputService.KeyboardEnabled or UserInputService.MouseEnabled) then
		v3.Position = UDim2.new(0.5, 0, 0.25, 0)
		return
	end
	v3.Position = UDim2.new(0.5, 0, 0.145, 0)
end
local function updateBossHealth(p1, p2, p3) --[[ updateBossHealth | Line: 56 | Upvalues: v6 (ref), setVisible (copy), v5 (ref), formatNumber (copy), v4 (ref), v8 (ref), TweenService (copy), v9 (ref) ]]
	if typeof(p1) ~= "number" or (typeof(p2) ~= "number" or p2 <= 0) then
		v6 = nil
		setVisible(false)
		return
	end
	v6 = if p3 then p3 else v6
	setVisible(true)
	local v2 = math.clamp(p1, 0, p2)
	if v5 then
		v5.Text = ("%* / %*"):format(formatNumber(v2), (formatNumber(p2)))
	end
	if not v4 then
		return
	end
	if v8 then
		v8:Cancel()
	end
	v8 = TweenService:Create(v4, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = UDim2.new(v9.X.Scale * (v2 / p2), 0, v9.Y.Scale, 0)
	})
	v8:Play()
end
local function handleSync(p1) --[[ handleSync | Line: 82 | Upvalues: v6 (ref), setVisible (copy), updateBossHealth (copy) ]]
	if type(p1) == "table" and (p1.Active == true and p1.Boss) then
		updateBossHealth(p1.Boss.HP, p1.Boss.MaxHP, p1.Boss.Id)
	else
		v6 = nil
		setVisible(false)
	end
end
local function handlePlantHit(p1) --[[ handlePlantHit | Line: 92 | Upvalues: v6 (ref), updateBossHealth (copy) ]]
	if type(p1) ~= "table" or p1.IsBoss ~= true then
		return
	end
	if v6 and p1.Id ~= v6 then
		return
	end
	updateBossHealth(p1.HP, p1.MaxHP, p1.Id)
end
local function clearBossModel() --[[ clearBossModel | Line: 98 | Upvalues: t2 (copy), v10 (ref) ]]
	for i, v in ipairs(t2) do
		v:Disconnect()
	end
	table.clear(t2)
	v10 = nil
end
local function updateFromBossModel(p1) --[[ updateFromBossModel | Line: 106 | Upvalues: updateBossHealth (copy) ]]
	local v1 = p1:GetAttribute("HP")
	local v2 = p1:GetAttribute("MaxHP")
	local v3 = p1:GetAttribute("PlantRushId")
	updateBossHealth(v1, v2, if typeof(v3) == "string" then v3 else nil)
end
local function watchBossModel(p1) --[[ watchBossModel | Line: 113 | Upvalues: v10 (ref), updateBossHealth (copy), t2 (copy), v6 (ref), setVisible (copy) ]]
	if v10 == p1 then
		local v1 = p1:GetAttribute("HP")
		local v2 = p1:GetAttribute("MaxHP")
		local v3 = p1:GetAttribute("PlantRushId")
		updateBossHealth(v1, v2, if typeof(v3) == "string" then v3 else nil)
	else
		for i, v in ipairs(t2) do
			v:Disconnect()
		end
		table.clear(t2)
		v10 = nil
		v10 = p1
		local v62 = p1:GetAttribute("HP")
		local v7 = p1:GetAttribute("MaxHP")
		local v8 = p1:GetAttribute("PlantRushId")
		local v9 = updateBossHealth
		v9(v62, v7, if typeof(v8) == "string" then v8 else nil)
		local v11 = t2
		local function f13() --[[ Line: 123 | Upvalues: p1 (copy), updateBossHealth (ref) ]]
			local v1 = p1
			local v2 = v1:GetAttribute("HP")
			local v3 = v1:GetAttribute("MaxHP")
			local v4 = v1:GetAttribute("PlantRushId")
			updateBossHealth(v2, v3, if typeof(v4) == "string" then v4 else nil)
		end
		table.insert(v11, p1:GetAttributeChangedSignal("HP"):Connect(f13))
		local v14 = t2
		local function f16() --[[ Line: 126 | Upvalues: p1 (copy), updateBossHealth (ref) ]]
			local v1 = p1
			local v2 = v1:GetAttribute("HP")
			local v3 = v1:GetAttribute("MaxHP")
			local v4 = v1:GetAttribute("PlantRushId")
			updateBossHealth(v2, v3, if typeof(v4) == "string" then v4 else nil)
		end
		table.insert(v14, p1:GetAttributeChangedSignal("MaxHP"):Connect(f16))
		local v17 = t2
		local function f18(p1, p2) --[[ Line: 129 | Upvalues: t2 (ref), v10 (ref), v6 (ref), setVisible (ref) ]]
			if p2 then
				return
			end
			for i, v in ipairs(t2) do
				v:Disconnect()
			end
			table.clear(t2)
			v10 = nil
			v6 = nil
			setVisible(false)
		end
		table.insert(v17, p1.AncestryChanged:Connect(f18))
	end
end
local function tryWatchExistingBoss() --[[ tryWatchExistingBoss | Line: 137 | Upvalues: Workspace (copy), watchBossModel (copy) ]]
	local v1 = Workspace:FindFirstChild("InteractiveEvents") and Workspace.InteractiveEvents:FindFirstChild("PlantRush")
	local v2 = if v1 then v1:FindFirstChild("Runtime") else v1
	if not v2 then
		return
	end
	for i, v in ipairs(v2:GetDescendants()) do
		if v:IsA("Model") and v:GetAttribute("PlantRushType") == "Boss" then
			watchBossModel(v)
			return
		end
	end
end
local function findFirstDescendant(p1, p2, p3) --[[ findFirstDescendant | Line: 151 ]]
	for i, v in ipairs(p1:GetDescendants()) do
		if v.Name == p2 and v.ClassName == p3 then
			return v
		end
	end
	return nil
end
local function resolveUiParts() --[[ resolveUiParts | Line: 160 | Upvalues: v3 (ref), v4 (ref), v5 (ref), findFirstDescendant (copy) ]]
	if not v3 then
		return
	end
	local Bar = v3:FindFirstChild("Bar")
	local HPLabel = v3:FindFirstChild("HPLabel")
	if Bar and Bar:IsA("Frame") then
		v4 = Bar
	end
	if HPLabel and HPLabel:IsA("TextLabel") then
		v5 = HPLabel
	end
	if not (v4 and v5) then
		local ProgressFrame = v3:FindFirstChild("ProgressFrame", true)
		if ProgressFrame then
			local Frame = ProgressFrame:FindFirstChild("Frame")
			local v1 = ProgressFrame:FindFirstChild("Health") or ProgressFrame:FindFirstChild("Progress")
			if not v4 and (Frame and Frame:IsA("Frame")) then
				v4 = Frame
			end
			if not v5 and (v1 and v1:IsA("TextLabel")) then
				v5 = v1
			end
		end
	end
	if not v4 then
		local v2 = findFirstDescendant(v3, "Bar", "Frame")
		if v2 and v2:IsA("Frame") then
			v4 = v2
		end
	end
	if v5 then
		return
	end
	local v32 = findFirstDescendant(v3, "HPLabel", "TextLabel")
	if not (v32 and v32:IsA("TextLabel")) then
		return
	end
	v5 = v32
end
function t.Init(p1, p2) --[[ Init | Line: 200 | Upvalues: v1 (ref), v2 (ref), v3 (ref), v4 (ref), v5 (ref), resolveUiParts (copy), setVisible (copy), v9 (ref), tryWatchExistingBoss (copy), v7 (ref), Sync (copy), handleSync (copy), PlantHit (copy), handlePlantHit (copy), Workspace (copy), watchBossModel (copy) ]]
	v1 = p2
	v2 = p1
	v3 = p1:WaitForChild("PlantRushBossFrame")
	v4 = nil
	v5 = nil
	resolveUiParts()
	setVisible(false)
	if v4 then
		v9 = v4.Size
		v4.Size = UDim2.new(0, 0, v9.Y.Scale, v9.Y.Offset)
	end
	if v5 then
		v5.Text = "0 / 0"
	end
	tryWatchExistingBoss()
	if not v7 then
		v7 = true
		Sync.OnClientEvent:Connect(handleSync)
		PlantHit.OnClientEvent:Connect(handlePlantHit)
		Workspace.DescendantAdded:Connect(function(p1) --[[ Line: 224 | Upvalues: watchBossModel (ref) ]]
			if not p1:IsA("Model") or p1:GetAttribute("PlantRushType") ~= "Boss" then
				return
			end
			watchBossModel(p1)
		end)
	end
end
return t