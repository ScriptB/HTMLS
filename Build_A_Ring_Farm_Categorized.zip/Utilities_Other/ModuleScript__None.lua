-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.None
-- Class: ModuleScript

-- https://lua.expert/
local v1 = newproxy(true)
getmetatable(v1).__tostring = function() --[[ Line: 12 ]]
	return "Sift.None"
end
return v1