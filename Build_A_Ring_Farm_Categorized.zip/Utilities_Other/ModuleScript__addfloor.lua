-- Path: ReplicatedStorage.CmdrClient.Commands.addfloor
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "addfloor",
	Description = "Adds a floor for the specified player",
	Group = "DefaultAdmin",
	Aliases = { "addfloor" },
	Args = {
		{
			Type = "player",
			Name = "Player",
			Description = "The player to add a floor for"
		}
	}
}