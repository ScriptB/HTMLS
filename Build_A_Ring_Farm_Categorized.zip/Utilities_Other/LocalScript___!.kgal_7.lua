-- Path: StarterGui.MainUI.RightSide.LimitedSeed.LimitedSeed.RobuxPrice.UIStroke._!.kgal
-- Class: LocalScript

-- https://lua.expert/
while true do
	task.wait(1000000000)
end