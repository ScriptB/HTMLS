-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.copyDeep
-- Class: ModuleScript

-- https://lua.expert/
local function v1(p1) --[[ copyDeep | Line: 20 | Upvalues: v1 (copy) ]]
	local v12 = table.clone(p1)
	for v2, v3 in p1 do
		if type(v3) == "table" then
			v12[v2] = v1(v3)
		end
	end
	return v12
end
return v1