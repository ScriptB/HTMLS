-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.includes
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ includes | Line: 19 ]]
	for k, v in pairs(p1) do
		if v == p2 then
			return true
		end
	end
	return false
end