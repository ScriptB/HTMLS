-- Path: ReplicatedStorage.Shared.Fireworks
-- Class: ModuleScript

-- https://lua.expert/
local t = {}
game:GetService("Players")
local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Debris = game:GetService("Debris")
local Fireworks = ReplicatedStorage:WaitForChild("Assets"):WaitForChild("VFX"):WaitForChild("Fireworks")
local v1 = Random.new()
local t2 = {
	Color3.fromRGB(255, 49, 49),
	Color3.fromRGB(255, 179, 55),
	Color3.fromRGB(255, 255, 53),
	Color3.fromRGB(105, 255, 79),
	Color3.fromRGB(90, 112, 255),
	Color3.fromRGB(70, 252, 255),
	Color3.fromRGB(193, 85, 255),
	Color3.fromRGB(255, 169, 225),
	Color3.fromRGB(255, 105, 180),
	Color3.fromRGB(255, 215, 0),
	Color3.fromRGB(135, 206, 235),
	Color3.fromRGB(186, 85, 211),
	Color3.fromRGB(240, 128, 128),
	Color3.fromRGB(173, 216, 230),
	Color3.fromRGB(0, 255, 127),
	Color3.fromRGB(255, 140, 0),
	Color3.fromRGB(30, 144, 255),
	Color3.fromRGB(238, 130, 238),
	Color3.fromRGB(255, 250, 205),
	Color3.fromRGB(152, 251, 152)
}
local function shuffle(p1) --[[ shuffle | Line: 26 | Upvalues: v1 (copy) ]]
	local v12 = table.clone(p1)
	for i = #v12, 2, -1 do
		local v2 = v1:NextInteger(1, i)
		local v4 = v12[i]
		v12[i] = v12[v2]
		v12[v2] = v4
	end
	return v12
end
local function cloneParticle(p1, p2) --[[ cloneParticle | Line: 37 ]]
	if not p1 then
		return nil
	end
	local v1 = p1:Clone()
	if v1:IsA("ParticleEmitter") then
		v1.Color = ColorSequence.new(p2)
	end
	return v1
end
local function glowFlash(p1, p2) --[[ glowFlash | Line: 46 | Upvalues: TweenService (copy) ]]
	local PointLight = Instance.new("PointLight")
	PointLight.Color = p2
	PointLight.Range = 20
	PointLight.Brightness = 8
	local Part = Instance.new("Part")
	Part.Anchored = true
	Part.CanCollide = false
	Part.Transparency = 1
	Part.Position = p1
	PointLight.Parent = Part
	Part.Parent = workspace
	TweenService:Create(PointLight, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Brightness = 0
	}):Play()
	task.delay(1, function() --[[ Line: 62 | Upvalues: Part (copy) ]]
		Part:Destroy()
	end)
end
local function fire(p1, p2, p3) --[[ fire | Line: 65 | Upvalues: Fireworks (copy), v1 (copy), RunService (copy), TweenService (copy), glowFlash (copy) ]]
	local Part = Instance.new("Part")
	Part.Size = Vector3.new(0.5, 0.5, 0.5)
	Part.Anchored = true
	Part.CanCollide = false
	Part.Transparency = 1
	Part.CFrame = p1
	Part.Parent = workspace
	local Trail = Fireworks:FindFirstChild("Trail")
	local v12
	if Trail then
		local v2 = Trail:Clone()
		if v2:IsA("ParticleEmitter") then
			v2.Color = ColorSequence.new(p2)
		end
		v12 = v2
	else
		v12 = nil
	end
	if v12 and v12:IsA("ParticleEmitter") then
		v12.Parent = Part
		v12.Enabled = true
	end
	local Spec = Fireworks:FindFirstChild("Spec")
	local v3 = Color3.new(255/255, 255/255, 255/255)
	local v4
	if Spec then
		local v5 = Spec:Clone()
		if v5:IsA("ParticleEmitter") then
			v5.Color = ColorSequence.new(v3)
		end
		v4 = v5
	else
		v4 = nil
	end
	if v4 and v4:IsA("ParticleEmitter") then
		v4.Parent = Part
		v4.Enabled = true
		v4.Size = NumberSequence.new(0.1)
		v4.Speed = NumberRange.new(0.5, 1)
		v4.Acceleration = Vector3.new(0, -29.4, 0)
		v4.Rate = 30
		v4.EmissionDirection = Enum.NormalId.Top
		v4.Lifetime = NumberRange.new(0.5, 1)
		v4.LightInfluence = 0
		v4.LockedToPart = true
	end
	local v6 = v1:NextNumber(10, 16)
	local v9 = p1 + Vector3.new(v1:NextNumber(-7, 7), v6, v1:NextNumber(-7, 7))
	local v10 = nil
	v10 = RunService.Heartbeat:Connect(function() --[[ Line: 99 | Upvalues: p3 (copy), Part (copy), v10 (ref) ]]
		if p3 and (Part and Part.Parent) then
			Part.CFrame = CFrame.new((Vector3.new(p3.Position.X, Part.Position.Y, p3.Position.Z)))
		else
			v10:Disconnect()
		end
	end)
	local v11 = TweenService:Create(Part, TweenInfo.new(v6 / 10, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		CFrame = v9
	})
	v11:Play()
	v11.Completed:Wait()
	v10:Disconnect()
	local Explosion = Fireworks:FindFirstChild("Explosion")
	local v122
	if Explosion then
		local v13 = Explosion:Clone()
		if v13:IsA("ParticleEmitter") then
			v13.Color = ColorSequence.new(p2)
		end
		v122 = v13
	else
		v122 = nil
	end
	if v122 and v122:IsA("ParticleEmitter") then
		v122.Parent = Part
		v122:Emit(v1:NextInteger(60, 100))
	end
	local Sparks = Fireworks:FindFirstChild("Sparks")
	local v14
	if Sparks then
		local v15 = Sparks:Clone()
		if v15:IsA("ParticleEmitter") then
			v15.Color = ColorSequence.new(p2)
		end
		v14 = v15
	else
		v14 = nil
	end
	if v14 and v14:IsA("ParticleEmitter") then
		v14.Parent = Part
		v14:Emit(v1:NextInteger(40, 80))
		task.delay(0.3, function() --[[ Line: 122 | Upvalues: v14 (copy) ]]
			v14.Enabled = false
		end)
	end
	local Sparkle = Fireworks:FindFirstChild("Sparkle")
	local v16
	if Sparkle then
		local v17 = Sparkle:Clone()
		if v17:IsA("ParticleEmitter") then
			v17.Color = ColorSequence.new(p2)
		end
		v16 = v17
	else
		v16 = nil
	end
	if v16 and v16:IsA("ParticleEmitter") then
		v16.Parent = Part
		v16:Emit(v1:NextInteger(20, 40))
	end
	local Flare = Fireworks:FindFirstChild("Flare")
	local v18
	if Flare then
		local v19 = Flare:Clone()
		if v19:IsA("ParticleEmitter") then
			v19.Color = ColorSequence.new(p2)
		end
		v18 = v19
	else
		v18 = nil
	end
	if v18 and v18:IsA("ParticleEmitter") then
		v18.Parent = Part
		v18:Emit(v1:NextInteger(10, 30))
	end
	glowFlash(v9.Position, p2)
	local v20 = tick()
	while tick() - v20 < 0.3 do
		local v23 = NumberSequence.new((tick() - v20) / 0.3)
		if v12 then
			v12.Transparency = v23
		end
		if v4 then
			v4.Transparency = v23
		end
		task.wait()
	end
	if v12 then
		v12.Enabled = false
	end
	if not v4 then
		task.delay(4, function() --[[ Line: 150 | Upvalues: Part (copy) ]]
			Part:Destroy()
		end)
		return
	end
	v4.Enabled = false
	task.delay(4, function() --[[ Line: 150 | Upvalues: Part (copy) ]]
		Part:Destroy()
	end)
end
local function launch(p1, p2) --[[ launch | Line: 153 | Upvalues: v1 (copy), shuffle (copy), t2 (copy), fire (copy), Debris (copy) ]]
	local v12 = v1:NextInteger(6, 9)
	local v2 = shuffle(t2)
	for i = 1, v12 do
		local v3 = v2[i] or t2[v1:NextInteger(1, #t2)]
		task.delay((i - 1) * 0.07, function() --[[ Line: 158 | Upvalues: fire (ref), p1 (copy), v3 (copy), p2 (copy) ]]
			fire(p1, v3, p2)
		end)
	end
	task.delay(0.5, function() --[[ Line: 161 | Upvalues: p1 (copy), Debris (ref) ]]
		local Part = Instance.new("Part")
		Part.Anchored = true
		Part.CanCollide = false
		Part.Transparency = 1
		Part.Position = p1.Position
		Part.Parent = workspace
		local v1 = script.Fireworks:Clone()
		v1.Parent = Part
		v1:Play()
		Debris:AddItem(v1, v1.TimeLength)
		task.delay(2, function() --[[ Line: 174 | Upvalues: Part (copy) ]]
			Part:Destroy()
		end)
	end)
end
function t.LaunchAtCharacter(p1) --[[ LaunchAtCharacter | Line: 178 | Upvalues: launch (copy) ]]
	local Character = p1.Character
	local v1 = if Character then Character:FindFirstChild("HumanoidRootPart") else Character
	if not v1 then
		return
	end
	launch(v1.CFrame, v1)
end
function t.LaunchAt(p1, p2) --[[ LaunchAt | Line: 186 | Upvalues: launch (copy) ]]
	launch(p1, if p2 then p2 else workspace.Terrain)
end
return t