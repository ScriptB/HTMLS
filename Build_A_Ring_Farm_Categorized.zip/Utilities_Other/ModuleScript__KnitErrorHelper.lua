-- Path: ReplicatedStorage.Packages._Index.superbullet_knit@0.0.1.knit.KnitErrorHelper
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	GetCallerInfo = function(p1) --[[ GetCallerInfo | Line: 18 ]]
		local list = {}
		for v1 in debug.traceback("", 2):gmatch("[^\r\n]+") do
			local v2 = v1:match("^%s*([^%s]+):%d+")
			if v2 and not (v2:find("Knit") or v2:find("Error")) then
				table.insert(list, v2)
			end
		end
		for i, v in ipairs(list) do
			local t = {}
			for v3 in v:gmatch("[^%.]+") do
				table.insert(t, v3)
			end
			local v4, v5 = pcall(function() --[[ Line: 46 | Upvalues: t (copy) ]]
				local v1 = game
				for i, v in ipairs(t) do
					local v2 = v1:FindFirstChild(v)
					if not v2 then
						return nil
					end
					v1 = v2
				end
				return v1
			end)
			if v4 and (v5 and v5:IsA("LuaSourceContainer")) then
				if v5:IsA("Script") or v5:IsA("LocalScript") then
					return v5, false
				elseif v5:IsA("ModuleScript") then
					return v5, "module"
				else
					return v5, false
				end
			end
		end
		return nil, false
	end
}
function t.GetStartErrorMessage(p1, p2, p3, p4) --[[ GetStartErrorMessage | Line: 85 | Upvalues: t (copy) ]]
	if p1 then
		return ""
	end
	local v1, v2 = t.GetCallerInfo(p3)
	local v3 = p4 or false
	local v4 = "\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\n" .. "\226\157\140 Cannot call " .. p2 .. " until Knit has been started\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\n"
	local v5
	if v1 and (v1:IsA("Script") or v1:IsA("LocalScript")) then
		v5 = v4 .. "You are calling this from a " .. v1.ClassName .. ".\nSolution: Use Knit.OnStart():await() to wait for Knit to start\n\nExample:\n  Knit.OnStart():await()\n  local MyService = Knit.GetService(\"MyService\")\n"
		if v3 then
			v5 = v5 .. "  local MyController = Knit.GetController(\"MyController\")\n"
		end
	elseif v2 == "module" then
		local v6 = v4 .. "You are calling this from a ModuleScript.\n\n"
		v5 = if v3 then v6 .. "If this is a Knit Service:\n  Move Knit.GetService() calls to KnitInit()\n\n  Example:\n    function MyService:KnitInit()\n        local OtherService = Knit.GetService(\"OtherService\")\n        -- Use OtherService here\n    end\n\nIf this is a Knit Controller:\n  Move Knit.GetController() calls to KnitInit()\n\n  Example:\n    function MyController:KnitInit()\n        local OtherController = Knit.GetController(\"OtherController\")\n        -- Use OtherController here\n    end\n\nIf this is a regular ModuleScript:\n  Use Knit.OnStart():await() before calling\n\n  Example:\n    Knit.OnStart():await()\n    local MyService = Knit.GetService(\"MyService\")\n    local MyController = Knit.GetController(\"MyController\")\n" else v6 .. "If this is a Knit Service:\n  Move Knit.GetService() calls to KnitInit()\n\n  Example:\n    function MyService:KnitInit()\n        local OtherService = Knit.GetService(\"OtherService\")\n        -- Use OtherService here\n    end\n\nIf this is a regular ModuleScript:\n  Use Knit.OnStart():await() before calling\n\n  Example:\n    Knit.OnStart():await()\n    local MyService = Knit.GetService(\"MyService\")\n"
	else
		local v7 = v4 .. "Solution: Ensure Knit has started before calling this method\n\n"
		v5 = if v3 then v7 .. "For Scripts/LocalScripts/ModuleScripts:\n  Knit.OnStart():await()\n  local MyService = Knit.GetService(\"MyService\")\n  local MyController = Knit.GetController(\"MyController\")\n\nFor Knit Services:\n  function MyService:KnitInit()\n      local OtherService = Knit.GetService(\"OtherService\")\n  end\n\nFor Knit Controllers:\n  function MyController:KnitInit()\n      local OtherController = Knit.GetController(\"OtherController\")\n  end\n" else v7 .. "For Scripts/LocalScripts/ModuleScripts:\n  Knit.OnStart():await()\n  local MyService = Knit.GetService(\"MyService\")\n\nFor Knit Services:\n  function MyService:KnitInit()\n      local OtherService = Knit.GetService(\"OtherService\")\n  end\n"
	end
	warn(v5 .. "\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129")
	return "Cannot call " .. p2 .. " until Knit has been started. See output above for details."
end
return t