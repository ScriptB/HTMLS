-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.is
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ is | Line: 21 ]]
	return if typeof(p1) == "table" and #p1 > 0 then next(p1, #p1) == nil else false
end