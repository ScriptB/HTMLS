-- Path: ReplicatedStorage.SharedSource.Datas.ProfileTemplate
-- Class: ModuleScript

-- https://lua.expert/
return {}