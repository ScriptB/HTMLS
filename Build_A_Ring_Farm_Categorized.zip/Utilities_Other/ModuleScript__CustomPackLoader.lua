-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.CustomPackLoader
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Modules.CustomPack)
return 0