-- Path: ReplicatedStorage.Shared.RandomItemRoll
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local Registry = require(ReplicatedStorage.Shared.Registry)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local ConfettiHandler = require(ReplicatedStorage.Shared.VFX.ConfettiHandler)
local HoneyRollScreenGui = ReplicatedStorage.Assets.Events.QueenBee.HoneyRollScreenGui
local LocalPlayer = Players.LocalPlayer
local t = {}
local t2 = {
	CycleDuration = 1.5,
	StartInterval = 0.05,
	EndInterval = 0.35,
	RevealScale = 1.3,
	HoldDuration = 3,
	ConfettiCount = 40,
	CycleSound = "Pop",
	RevealSound = "PopReveal",
	ColumnStagger = 0.35
}
local function setEntry(p1, p2) --[[ setEntry | Line: 33 | Upvalues: Registry (copy) ]]
	local Icon = p1:FindFirstChild("Icon")
	local Label = p1:FindFirstChild("Label")
	local RarityLabel = p1:FindFirstChild("RarityLabel")
	if Icon then
		Icon.Image = p2 and p2.Icon or ""
		Icon.Visible = if Icon.Image == "" then false else true
	end
	if Label then
		Label.Text = p2 and p2.Label or ""
	end
	if not RarityLabel then
		return
	end
	local UIGradient = RarityLabel:FindFirstChildOfClass("UIGradient")
	if UIGradient then
		UIGradient:Destroy()
	end
	local v4 = if p2 then p2.Rarity else p2
	if v4 and Registry.Rarities[v4] then
		RarityLabel.Text = v4
		Registry.Rarities[v4].Gradient:Clone().Parent = RarityLabel
		RarityLabel.Visible = true
		return
	end
	RarityLabel.Visible = false
end
local function pop(p1, p2, p3, p4, p5) --[[ pop | Line: 57 | Upvalues: TweenService (copy) ]]
	if not p1 then
		return
	end
	p1.Scale = p2
	local v2 = TweenInfo.new
	TweenService:Create(p1, v2(p4, if p5 then p5 else Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Scale = p3
	}):Play()
end
local function runColumn(p1, p2, p3) --[[ runColumn | Line: 64 | Upvalues: pop (copy), setEntry (copy), SFXModule (copy) ]]
	local UIScale = p1:FindFirstChildOfClass("UIScale")
	local v1 = p3.Pool or {}
	local sum = 0
	if UIScale then
		pop(UIScale, 0.01, 1, 0.25)
	end
	task.wait(0.05)
	while sum < p2.CycleDuration + (p3.ExtraCycle or 0) do
		local v3
		v3 = p2.CycleDuration > 0 and math.clamp(sum / p2.CycleDuration, 0, 1) or 1
		local v5 = p2.StartInterval + (p2.EndInterval - p2.StartInterval) * v3 ^ 2
		if #v1 > 0 then
			setEntry(p1, v1[math.random(1, #v1)])
		end
		pop(UIScale, 0.85, 1, 0.08)
		if p2.CycleSound then
			SFXModule.PlaySFX(p2.CycleSound)
		end
		task.wait(v5)
		sum = sum + v5
	end
	setEntry(p1, p3.Result)
	pop(UIScale, 0.5, p2.RevealScale, 0.35)
	if not p3.LandSound then
		return
	end
	SFXModule.PlaySFX(p3.LandSound)
end
local function buildColumns(p1, p2) --[[ buildColumns | Line: 90 ]]
	local Frame = p1:FindFirstChild("Frame")
	if not Frame then
		return {}
	end
	if p2 <= 1 then
		return { Frame }
	end
	local v2 = math.clamp(0.92 / p2 / math.max(Frame.Size.X.Scale, 0.01), 0.1, 1)
	local Size = Frame.Size
	local t = {}
	for i = 1, p2 do
		local v3
		v3 = if i == 1 and Frame then Frame else Frame:Clone()
		v3.Size = UDim2.new(Size.X.Scale * v2, Size.X.Offset * v2, Size.Y.Scale * v2, Size.Y.Offset * v2)
		v3.AnchorPoint = Vector2.new(0.5, 0.5)
		v3.Position = UDim2.new(i / (p2 + 1), 0, 0.5, 0)
		if v3 ~= Frame then
			v3.Parent = p1
		end
		t[i] = v3
	end
	return t
end
function t.Play(p1) --[[ Play | Line: 113 | Upvalues: t2 (copy), LocalPlayer (copy), HoneyRollScreenGui (copy), buildColumns (copy), runColumn (copy), SFXModule (copy), ConfettiHandler (copy), TweenService (copy) ]]
	local v1 = if p1 then p1 else {}
	local v2 = v1.Columns or {
		{
			Pool = v1.Pool,
			Result = v1.Result
		}
	}
	local v3 = v1
	local v4 = #v2
	if v4 == 0 then
		return
	end
	local t = {}
	for k, v in pairs(t2) do
		local v5
		local v6 = v3[k]
		v5 = if v6 == nil or not v6 then v else v6
		t[k] = v5
	end
	local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not PlayerGui then
		return
	end
	local v7 = PlayerGui:FindFirstChild(HoneyRollScreenGui.Name)
	if v7 then
		v7:Destroy()
	end
	local v8 = HoneyRollScreenGui:Clone()
	v8.Parent = PlayerGui
	local v9 = buildColumns(v8, v4)
	local v10 = Instance.new("BindableEvent")
	local v11 = v4
	for i, v in ipairs(v2) do
		local v12 = v9[i]
		v.ExtraCycle = (i - 1) * t.ColumnStagger
		task.spawn(function() --[[ Line: 139 | Upvalues: v12 (copy), runColumn (ref), t (copy), v (copy), v11 (ref), v10 (copy) ]]
			if v12 then
				local v1, v2 = pcall(runColumn, v12, t, v)
				if not v1 then
					warn("[RandomItemRoll] column error: " .. tostring(v2))
				end
			end
			v11 = v11 - 1
			if not (v11 <= 0) then
				return
			end
			v10:Fire()
		end)
	end
	v10.Event:Wait()
	v10:Destroy()
	if t.RevealSound then
		SFXModule.PlaySFX(t.RevealSound)
	end
	if t.ConfettiCount and t.ConfettiCount > 0 then
		pcall(function() --[[ Line: 153 | Upvalues: ConfettiHandler (ref), t (copy) ]]
			task.spawn(function() --[[ Line: 153 | Upvalues: ConfettiHandler (ref), t (ref) ]]
				ConfettiHandler.SpawnConfetti(t.ConfettiCount)
			end)
		end)
	end
	task.wait(t.HoldDuration)
	for i, v in ipairs(v9) do
		local UIScale = v:FindFirstChildOfClass("UIScale")
		if UIScale then
			TweenService:Create(UIScale, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				Scale = 0
			}):Play()
		end
	end
	task.wait(0.32)
	if v8 and v8.Parent then
		v8:Destroy()
	end
end
return t