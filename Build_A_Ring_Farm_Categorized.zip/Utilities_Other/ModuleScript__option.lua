-- Path: ReplicatedStorage.Packages._Index.sleitnick_comm@1.0.1.Option
-- Class: ModuleScript

-- https://lua.expert/
return require(script.Parent.Parent["sleitnick_option@1.0.5"].option)