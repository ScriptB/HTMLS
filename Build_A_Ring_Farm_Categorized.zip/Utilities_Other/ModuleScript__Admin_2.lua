-- Path: ReplicatedStorage.Shared.MutationAppliers.Admin
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Registry = require(ReplicatedStorage.Shared.Registry)
local MutationApplierUtil = require(ReplicatedStorage.Shared.MutationApplierUtil)
local v1 = Registry.Mutations[script.Name]
return function(p1) --[[ Line: 6 | Upvalues: MutationApplierUtil (copy), v1 (copy) ]]
	MutationApplierUtil.ApplyMainColor(p1, v1.MainColor)
	MutationApplierUtil.ApplyFolderVFX(p1, function(p1, p2) --[[ Line: 8 ]]
		for i, v in ipairs(script:GetChildren()) do
			if v:IsA("ParticleEmitter") then
				v:Clone().Parent = p1
			end
		end
	end)
end