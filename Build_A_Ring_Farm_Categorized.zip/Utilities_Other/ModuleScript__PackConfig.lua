-- Path: ReplicatedStorage.Shared.PackConfig
-- Class: ModuleScript

-- https://lua.expert/
local CollectionService = game:GetService("CollectionService")
local EggConfig = require(script.Parent.EggConfig)
local PlantRushConfig = require(script.Parent.PlantRushConfig)
local t = {}
local v1, v2 = (function() --[[ BuildPlantRushBossBox | Line: 8 | Upvalues: PlantRushConfig (copy) ]]
	local t = {}
	local t2 = {}
	for i, v in ipairs(PlantRushConfig.Rewards.BossBox) do
		local v1 = v.Display or v.Name
		t[v1] = v.Weight
		t2[v1] = {
			Kind = v.Kind,
			Name = v.Name,
			Display = v1,
			Icon = v.Icon
		}
	end
	return t, t2
end)()
t.Packs = {
	TropicalSeedPack = {
		DisplayName = "Tropical Seed Pack",
		ToolName = "Tropical Seed Pack",
		ToolTag = "Seed Pack",
		RewardType = "Seed",
		RewardSuffix = "Seed",
		Drops = {
			Starfruit = 50,
			Pineapple = 25,
			Pomegranate = 15,
			Kiwi = 9,
			Dragonfruit = 1
		}
	},
	CorruptedSeedPack = {
		DisplayName = "Corrupted Seed Pack",
		ToolName = "Corrupted Seed Pack",
		ToolTag = "Corrupted Seed Pack",
		RewardType = "Seed",
		RewardSuffix = "Seed",
		Drops = {
			["Hex Sprout"] = 52,
			Dreadcap = 30,
			Muckthorn = 15,
			Witherfang = 2.5,
			["Heart of Corruption"] = 0.5
		}
	},
	DinosaurEgg = {
		DisplayName = "Dinosaur Egg",
		ToolName = "Dinosaur Egg",
		ToolTag = "Dino Egg",
		RewardType = "Pet",
		RewardSuffix = "Pet",
		Drops = EggConfig.DinosaurEgg,
		SizeDrops = EggConfig.Size
	},
	PlantRushBossBox = {
		DisplayName = "Plant Rush Boss Box",
		ToolName = "Plant Rush Boss Box",
		ToolTag = "Plant Rush Boss Box",
		RewardType = "Mixed",
		RewardSuffix = "",
		Drops = v1,
		Rewards = v2
	}
}
t.Products = {
	SeedPackX1 = {
		PackId = "TropicalSeedPack",
		Rolls = 1
	},
	SeedPackX3 = {
		PackId = "TropicalSeedPack",
		Rolls = 3
	},
	SeedPackX10 = {
		PackId = "TropicalSeedPack",
		Rolls = 10
	},
	CorruptedPackX1 = {
		PackId = "CorruptedSeedPack",
		Rolls = 1
	},
	CorruptedPackX3 = {
		PackId = "CorruptedSeedPack",
		Rolls = 3
	},
	CorruptedPackX10 = {
		PackId = "CorruptedSeedPack",
		Rolls = 10
	},
	DinoEggX1 = {
		PackId = "DinosaurEgg",
		Rolls = 1
	},
	DinoEggX3 = {
		PackId = "DinosaurEgg",
		Rolls = 3
	},
	DinoEggX10 = {
		PackId = "DinosaurEgg",
		Rolls = 10
	}
}
local function CopyDictionary(p1) --[[ CopyDictionary | Line: 93 ]]
	local t = {}
	if type(p1) ~= "table" then
		return t
	end
	for k, v in pairs(p1) do
		t[k] = v
	end
	return t
end
function t.GetPack(p1) --[[ GetPack | Line: 102 | Upvalues: t (copy) ]]
	if type(p1) == "string" then
		return t.Packs[p1]
	else
		return nil
	end
end
function t.GetProduct(p1) --[[ GetProduct | Line: 107 | Upvalues: t (copy) ]]
	if type(p1) == "string" then
		return t.Products[p1]
	else
		return nil
	end
end
function t.GetPackForProduct(p1) --[[ GetPackForProduct | Line: 112 | Upvalues: t (copy) ]]
	local v1 = t.GetProduct(p1)
	if v1 then
		return t.GetPack(v1.PackId), v1
	else
		return nil, nil
	end
end
function t.GetPackIdForTool(p1) --[[ GetPackIdForTool | Line: 118 | Upvalues: t (copy), CollectionService (copy) ]]
	if not p1 then
		return nil
	end
	local v1 = p1:GetAttribute("PackId")
	if t.Packs[v1] then
		return v1
	end
	local v2 = p1:GetAttribute("gearKey")
	local v3 = p1.Name
	for k, v in pairs(t.Packs) do
		local ToolName = v.ToolName
		local ToolTag = v.ToolTag
		if ToolTag and CollectionService:HasTag(p1, ToolTag) then
			return k
		end
		if v2 == ToolName or (v3 == ToolName or v3:sub(1, #ToolName + 2) == ToolName .. " (") then
			return k
		end
	end
	return nil
end
function t.GetPackForTool(p1) --[[ GetPackForTool | Line: 142 | Upvalues: t (copy) ]]
	local v1 = t.GetPackIdForTool(p1)
	return t.GetPack(v1), v1
end
function t.GetDrops(p1) --[[ GetDrops | Line: 147 | Upvalues: t (copy) ]]
	local v1 = t.GetPack(p1)
	local v2
	if v1 then
		local Drops = v1.Drops
		local t2 = {}
		if type(Drops) == "table" then
			for k, v in pairs(Drops) do
				t2[k] = v
			end
		end
		v2 = t2 or {}
	else
		v2 = {}
	end
	return v2
end
function t.GetProductIds(p1) --[[ GetProductIds | Line: 152 | Upvalues: t (copy) ]]
	local t2 = {}
	for k in pairs(t.Products) do
		local v1 = p1[k]
		if v1 and typeof(v1.Id) == "number" then
			t2[v1.Id] = true
		end
	end
	return t2
end
function t.GetClientInfo(p1) --[[ GetClientInfo | Line: 163 | Upvalues: t (copy) ]]
	local v1 = t.GetPack(p1)
	if v1 then
		return {
			PackId = p1,
			DisplayName = v1.DisplayName,
			RewardType = v1.RewardType,
			RewardSuffix = v1.RewardSuffix,
			Rewards = v1.Rewards
		}
	else
		return nil
	end
end
return t