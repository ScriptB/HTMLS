-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.ClientPlotHandler.LeverPrompt
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
require(script.Parent.Parent.UIController)
local LocalPlayer = Players.LocalPlayer
return function(p1) --[[ Line: 7 | Upvalues: ReplicatedStorage (copy), LocalPlayer (copy) ]]
	local v1 = ReplicatedStorage.Assets.UI.Prompts.RollSeeds:Clone()
	v1.Triggered:Connect(function() --[[ Line: 11 | Upvalues: LocalPlayer (ref), ReplicatedStorage (ref) ]]
		if LocalPlayer.Character then
			ReplicatedStorage.Remotes.RollSeeds:FireServer()
		end
	end)
	v1.Parent = p1.RollPlatform.Lever.LevelPrompt
end