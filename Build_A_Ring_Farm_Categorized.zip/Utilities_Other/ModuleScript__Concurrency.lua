-- Path: ReplicatedStorage.UserGenerated.Concurrency
-- Class: ModuleScript

-- https://lua.expert/
return {}