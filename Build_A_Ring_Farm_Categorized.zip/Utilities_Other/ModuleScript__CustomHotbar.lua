-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.CustomHotbar
-- Class: ModuleScript

-- https://lua.expert/
local StarterGui = game:GetService("StarterGui")
local UserInputService = game:GetService("UserInputService")
local Players = game:GetService("Players")
StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
local LocalPlayer = Players.LocalPlayer
local v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Humanoid = v1:WaitForChild("Humanoid")
local Backpack = LocalPlayer:WaitForChild("Backpack")
local ToolBar = LocalPlayer.PlayerGui:WaitForChild("MainUI"):WaitForChild("ToolBar")
local TemplateSlot = script:WaitForChild("TemplateSlot")
local t = {
	[Enum.KeyCode.One] = 1,
	[Enum.KeyCode.Two] = 2,
	[Enum.KeyCode.Three] = 3,
	[Enum.KeyCode.Four] = 4,
	[Enum.KeyCode.Five] = 5,
	[Enum.KeyCode.Six] = 6,
	[Enum.KeyCode.Seven] = 7,
	[Enum.KeyCode.Eight] = 8,
	[Enum.KeyCode.Nine] = 9,
	[Enum.KeyCode.Zero] = 10
}
local t2 = {}
local v2 = nil
local function updateSlotVisual(p1, p2) --[[ updateSlotVisual | Line: 44 ]]
	local Icon = p1:FindFirstChild("Icon")
	if not Icon then
		return
	end
	if p2 and p2.TextureId ~= "" then
		Icon.Image = p2.TextureId
		Icon.Visible = true
	else
		Icon.Image = ""
		Icon.Visible = false
	end
end
local function selectSlot(p1) --[[ selectSlot | Line: 58 | Upvalues: v2 (ref), ToolBar (copy), t2 (ref), Humanoid (copy), v1 (copy), Backpack (copy) ]]
	if v2 and ToolBar:FindFirstChild((tostring(v2))) then
		ToolBar[tostring(v2)].BorderColor3 = Color3.fromRGB(80, 80, 80)
	end
	v2 = p1
	if p1 then
		local v4 = ToolBar:FindFirstChild((tostring(p1)))
		if v4 then
			v4.BorderColor3 = Color3.fromRGB(255, 255, 0)
		end
		local v5 = t2[p1]
		if v5 then
			Humanoid:EquipTool(v5)
			return
		end
		local Tool = v1:FindFirstChildOfClass("Tool")
		if Tool then
			Tool.Parent = Backpack
		end
	else
		local Tool = v1:FindFirstChildOfClass("Tool")
		if not Tool then
			return
		end
		Tool.Parent = Backpack
	end
end
local function updateHotbar() --[[ updateHotbar | Line: 89 | Upvalues: Backpack (copy), t2 (ref), ToolBar (copy), v2 (ref), Humanoid (copy), v1 (copy), selectSlot (copy) ]]
	local v12 = Backpack:GetChildren()
	table.sort(v12, function(p1, p2) --[[ Line: 91 ]]
		return p1.Name < p2.Name
	end)
	t2 = {}
	for i = 1, 10 do
		local v22 = ToolBar:FindFirstChild((tostring(i)))
		if v22 then
			v22.Visible = false
			local Icon = v22:FindFirstChild("Icon")
			if Icon then
				Icon.Image = ""
				Icon.Visible = false
			end
		end
	end
	for i, v in ipairs(v12) do
		if i > 10 then
			break
		end
		local v3 = ToolBar:FindFirstChild((tostring(i)))
		if v3 then
			t2[i] = v
			local Icon = v3:FindFirstChild("Icon")
			if Icon and (v and v.TextureId ~= "") then
				Icon.Image = v.TextureId
				Icon.Visible = true
			elseif Icon then
				Icon.Image = ""
				Icon.Visible = false
			end
			v3.Visible = true
		end
	end
	if v2 and t2[v2] then
		Humanoid:EquipTool(t2[v2])
		return
	end
	if not v1:FindFirstChildOfClass("Tool") or v2 and t2[v2] then
		return
	end
	selectSlot(nil)
end
UserInputService.InputBegan:Connect(function(p1, p2) --[[ Line: 129 | Upvalues: t (copy), t2 (ref), selectSlot (copy), Backpack (copy), v2 (ref) ]]
	if p2 then
		return
	end
	if t[p1.KeyCode] then
		local v1 = t[p1.KeyCode]
		if t2[v1] then
			selectSlot(v1)
		end
	else
		if p1.KeyCode == Enum.KeyCode.ButtonR1 then
			local v22 = #Backpack:GetChildren()
			if v22 ~= 0 then
				selectSlot((v2 or 0) % v22 + 1)
			end
			return
		end
		if p1.KeyCode ~= Enum.KeyCode.ButtonL1 then
			return
		end
		local v3 = #Backpack:GetChildren()
		if v3 == 0 then
			return
		end
		local v4 = (v2 or 2) - 1
		if v4 < 1 then
			v4 = v3
		end
		selectSlot(v4)
	end
end)
for i = 1, 10 do
	local v3 = TemplateSlot:Clone()
	v3.Name = tostring(i)
	v3.Parent = ToolBar
	v3.Visible = false
	local KeybindLabel = v3:FindFirstChild("KeybindLabel")
	if KeybindLabel then
		KeybindLabel.Text = tostring(i % 10)
	end
	v3.Activated:Connect(function() --[[ Line: 170 | Upvalues: selectSlot (copy), i (copy) ]]
		selectSlot(i)
	end)
end
TemplateSlot.Parent = nil
updateHotbar()
Backpack.ChildAdded:Connect(updateHotbar)
Backpack.ChildRemoved:Connect(updateHotbar)
Humanoid.ChildRemoved:Connect(function(p1) --[[ Line: 182 | Upvalues: v2 (ref), t2 (ref), selectSlot (copy) ]]
	if not p1:IsA("Tool") or (not v2 or p1 ~= t2[v2]) then
		return
	end
	selectSlot(nil)
end)
print("Custom Hotbar Module Initialized.")
return 0