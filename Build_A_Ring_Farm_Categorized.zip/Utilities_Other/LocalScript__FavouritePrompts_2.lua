-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.FavouritePrompts
-- Class: LocalScript

-- https://lua.expert/
local AvatarEditorService = game:GetService("AvatarEditorService")
local SocialService = game:GetService("SocialService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local EnginePromptGuard = require(ReplicatedStorage.Shared.EnginePromptGuard)
local DataAggregation = require(script.Parent.Modules.DataAggregation)
local MarkFavoriteGamePromptShown = ReplicatedStorage.Remotes:WaitForChild("MarkFavoriteGamePromptShown")
local v1 = nil
local v2 = false
local function HasShownFavoritePrompt() --[[ HasShownFavoritePrompt | Line: 12 | Upvalues: DataAggregation (copy) ]]
	local isFavoriteGamePromptShown = DataAggregation.WaitForReplica().Data.FavoriteGamePromptShown == true
	return isFavoriteGamePromptShown
end
local function MarkShownFavoritePrompt() --[[ MarkShownFavoritePrompt | Line: 17 | Upvalues: v2 (ref), MarkFavoriteGamePromptShown (copy) ]]
	if not v2 then
		v2 = true
		MarkFavoriteGamePromptShown:FireServer()
	end
end
AvatarEditorService.PromptSetFavoriteCompleted:Connect(function() --[[ Line: 23 | Upvalues: EnginePromptGuard (copy), v2 (ref), MarkFavoriteGamePromptShown (copy) ]]
	EnginePromptGuard.Release()
	if not v2 then
		v2 = true
		MarkFavoriteGamePromptShown:FireServer()
	end
end)
task.defer(function() --[[ Line: 28 | Upvalues: DataAggregation (copy), v2 (ref), MarkFavoriteGamePromptShown (copy), EnginePromptGuard (copy), AvatarEditorService (copy) ]]
	task.wait(300)
	local isFavoriteGamePromptShown = DataAggregation.WaitForReplica().Data.FavoriteGamePromptShown == true
	if isFavoriteGamePromptShown then
		return
	end
	if v2 then
		EnginePromptGuard.Acquire()
		AvatarEditorService:PromptSetFavorite(game.PlaceId, Enum.AvatarItemType.Asset, true)
		return
	end
	v2 = true
	MarkFavoriteGamePromptShown:FireServer()
	EnginePromptGuard.Acquire()
	AvatarEditorService:PromptSetFavorite(game.PlaceId, Enum.AvatarItemType.Asset, true)
end)
task.defer(function() --[[ Line: 37 | Upvalues: SocialService (copy), v1 (ref), EnginePromptGuard (copy) ]]
	task.wait(180)
	local v12, v2 = pcall(function() --[[ Line: 40 | Upvalues: SocialService (ref) ]]
		return SocialService:GetUpcomingExperienceEventsAsync()
	end)
	if not v12 or (not v2 or #v2 == 0) then
		v1 = nil
		return
	end
	local v3 = v2[1]
	if not v3 then
		v1 = nil
		return
	end
	v1 = v3.Id
	if not v1 then
		return
	end
	local v4, v5 = pcall(function() --[[ Line: 58 | Upvalues: SocialService (ref), v1 (ref) ]]
		return SocialService:GetEventRsvpStatusAsync(v1)
	end)
	if v4 and v5 == Enum.RsvpStatus.Going then
		return
	end
	EnginePromptGuard.Acquire()
	pcall(function() --[[ Line: 66 | Upvalues: SocialService (ref), v1 (ref) ]]
		SocialService:PromptRsvpToEventAsync(v1)
	end)
	EnginePromptGuard.Release()
end)