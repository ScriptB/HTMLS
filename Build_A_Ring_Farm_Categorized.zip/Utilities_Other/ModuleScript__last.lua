-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.last
-- Class: ModuleScript

-- https://lua.expert/
local at = require(script.Parent.at)
return function(p1) --[[ last | Line: 19 | Upvalues: at (copy) ]]
	return at(p1, 0)
end