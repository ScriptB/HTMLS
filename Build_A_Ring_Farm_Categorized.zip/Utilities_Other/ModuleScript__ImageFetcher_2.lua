-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.ContractsClient.ImageFetcher
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Registry = require(ReplicatedStorage.Shared.Registry)
local v1 = ReplicatedStorage:FindFirstChild("Assets") and ReplicatedStorage.Assets:FindFirstChild("Gear")
local t = {
	CASH_ICON = "rbxassetid://84793024154560",
	XP_ICON = "rbxassetid://107932933341610",
	GEAR_ICON = "rbxassetid://84793024154560",
	GetPlantIcon = function(p1) --[[ GetPlantIcon | Line: 21 | Upvalues: Registry (copy) ]]
		local v1 = Registry.Plants[p1]
		if not v1 then
			return nil
		end
		if type(v1.Icon) == "string" and v1.Icon ~= "" then
			return v1.Icon
		else
			return nil
		end
	end,
	GetGearIcon = function(p1) --[[ GetGearIcon | Line: 29 | Upvalues: v1 (copy) ]]
		if not v1 then
			return nil
		end
		local v12 = v1:FindFirstChild(p1)
		if v12 and (v12:IsA("Tool") and v12.TextureId ~= "") then
			return v12.TextureId
		else
			return nil
		end
	end
}
function t.GetItemIcon(p1) --[[ GetItemIcon | Line: 40 | Upvalues: t (copy) ]]
	return t.GetPlantIcon(p1) or (t.GetGearIcon(p1) or t.GEAR_ICON)
end
return table.freeze(t)