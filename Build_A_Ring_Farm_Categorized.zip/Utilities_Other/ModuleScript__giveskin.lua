-- Path: ReplicatedStorage.CmdrClient.Commands.giveskin
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "GiveSkin",
	Description = "Gives a player a specified farm skin",
	Group = "DefaultAdmin",
	Aliases = { "GiveSkin" },
	Args = {
		{
			Type = "player",
			Name = "Player",
			Description = "The player to give a farm skin"
		},
		{
			Type = "skinType",
			Name = "Skin"
		}
	}
}