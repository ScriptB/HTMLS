-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.TestsSuite.Helpers
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MutationStack = require(ReplicatedStorage.Shared.MutationStack)
local Registry = require(ReplicatedStorage.Shared.Registry)
return table.freeze({
	CommonPlant = "Carrot",
	PrismaticPlant = "Apple",
	DivinePlant = "Compost Hydra",
	ExoticPlant = "Crowned Pear",
	TranscendedPlant = "Ghost Pepper",
	PlantCost = function(p1) --[[ PlantCost | Line: 22 | Upvalues: Registry (copy) ]]
		local v1 = Registry.Plants[p1]
		if v1 then
			return v1.Cost
		else
			return 0
		end
	end,
	PlantRarity = function(p1) --[[ PlantRarity | Line: 27 | Upvalues: Registry (copy) ]]
		local v1 = Registry.Plants[p1]
		if v1 then
			return v1.Rarity
		else
			return nil
		end
	end,
	Mutation = function(...) --[[ Mutation | Line: 33 | Upvalues: MutationStack (copy) ]]
		return MutationStack.Encode({ ... })
	end,
	MockProfile = function(p1) --[[ MockProfile | Line: 44 ]]
		local v1 = if p1 then p1 else {}
		local t = {}
		for v3, v4 in v1.Seeds or {} do
			t[v4] = true
		end
		local t2 = {}
		for v6, v7 in v1.Mutations or {} do
			t2[v7] = true
		end
		return {
			Data = {
				SeedIndex = t,
				MutationIndex = t2,
				FarmLevel = v1.FarmLevel or 1
			}
		}
	end
})