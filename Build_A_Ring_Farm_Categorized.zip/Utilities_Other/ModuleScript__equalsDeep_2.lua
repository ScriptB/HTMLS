-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.equalsDeep
-- Class: ModuleScript

-- https://lua.expert/
local v1 = script.Parent.Parent
local Util = require(v1.Util)
require(v1.Types)
local function v2(p1, p2) --[[ compareDeep | Line: 7 | Upvalues: v2 (copy) ]]
	if type(p1) == "table" and type(p2) == "table" then
		for k, v in pairs(p1) do
			if not v2(v, p2[k]) then
				return false
			end
		end
		for k, v in pairs(p2) do
			if not v2(v, p1[k]) then
				return false
			end
		end
		return true
	else
		return p1 == p2
	end
end
return function(...) --[[ equalsDeep | Line: 45 | Upvalues: Util (copy), v2 (copy) ]]
	if Util.equalObjects(...) then
		return true
	end
	local v1 = select("#", ...)
	local v22 = select(1, ...)
	for i = 2, v1 do
		if not v2(v22, (select(i, ...))) then
			return false
		end
	end
	return true
end