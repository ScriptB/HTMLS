-- Path: ReplicatedStorage.Shared.Configuration
-- Class: ModuleScript

-- https://lua.expert/
return {
	PlotCount = 6,
	GroupID = 989438225,
	MAX_FARM_UPGRADES = 12,
	MAX_ROLLS = 6,
	MAX_RANGE = 3,
	MAX_OFFLINE_TIME = 480,
	MAX_PET_EQUIPS = 4,
	AMOUNT_TO_ABBREVIATE = 1000000000000,
	BaseSeedLuckUpgradeCost = 60,
	ExtraPowerGrowth = 1.35,
	FarmExpandCosts = {
		[2] = 8000,
		[3] = 150000,
		[4] = 25000000,
		[5] = 500000000,
		[6] = 1000000000,
		[7] = 100000000000,
		[8] = 200000000000,
		[9] = 400000000000,
		[10] = 500000000000000,
		[11] = 2500000000000000,
		[12] = 1e16
	},
	ExtraSeedRollsCosts = {
		[2] = 2000,
		[3] = 15000,
		[4] = 100000,
		[5] = 1000000,
		[6] = 10000000
	},
	FloorConfig = {
		{
			UnlockLevel = 1,
			PlotUnlockGrowth = 1.4,
			BaseExtraYieldUpgradeCost = 80,
			BaseExtraPowerUpgradeCost = 80,
			PlotUnlockBase = { 25, 150, 400 },
			ExtraSawRangeCosts = {
				[2] = 10000,
				[3] = 200000
			},
			ExtraSprinklerRangeCosts = {
				[2] = 10000,
				[3] = 200000
			}
		},
		{
			UnlockLevel = 4,
			PlotUnlockGrowth = 1.4,
			BaseExtraYieldUpgradeCost = 1000000,
			BaseExtraPowerUpgradeCost = 1000000,
			PlotUnlockBase = { 12000, 32000, 95000 },
			ExtraSawRangeCosts = {
				[2] = 500000000,
				[3] = 1500000000
			},
			ExtraSprinklerRangeCosts = {
				[2] = 500000000,
				[3] = 1500000000
			},
			RingValueBonus = {
				{
					RequiredValue = 500000000000,
					BonusPercent = 0.08
				},
				{
					RequiredValue = 1500000000000,
					BonusPercent = 0.12
				},
				{
					RequiredValue = 5000000000000,
					BonusPercent = 0.15
				}
			}
		},
		{
			UnlockLevel = 7,
			PlotUnlockGrowth = 1.4,
			BaseExtraYieldUpgradeCost = 100000000,
			BaseExtraPowerUpgradeCost = 100000000,
			UnlockRewards = {
				{
					Type = "Skin",
					RewardId = "Greenhouse"
				}
			},
			PlotUnlockBase = { 1200000, 3200000, 9500000 },
			ExtraSawRangeCosts = {
				[2] = 10000000000000,
				[3] = 50000000000000
			},
			ExtraSprinklerRangeCosts = {
				[2] = 10000000000000,
				[3] = 50000000000000
			},
			SoilQuality = {
				MaxLevel = 15,
				BaseCost = 25000000000000,
				CostGrowth = 2,
				IncomePerLevel = 0.03571428571428571
			},
			RingValueBonus = {
				{
					RequiredValue = 100000000000000,
					BonusPercent = 0.1
				},
				{
					RequiredValue = 500000000000000,
					BonusPercent = 0.15
				},
				{
					RequiredValue = 2000000000000000,
					BonusPercent = 0.2
				}
			}
		},
		{
			UnlockLevel = 10,
			PlotUnlockGrowth = 1.4,
			BaseExtraYieldUpgradeCost = 10000000000000,
			BaseExtraPowerUpgradeCost = 10000000000000,
			UnlockRewards = {
				{
					Type = "Skin",
					RewardId = "Royal"
				}
			},
			PlotUnlockBase = { 120000000, 320000000, 950000000 },
			ExtraSawRangeCosts = {
				[2] = 2500000000000000,
				[3] = 1e16
			},
			ExtraSprinklerRangeCosts = {
				[2] = 2500000000000000,
				[3] = 1e16
			},
			SoilQuality = {
				MaxLevel = 15,
				BaseCost = 2500000000000000,
				CostGrowth = 1.85,
				IncomePerLevel = 0.03571428571428571
			},
			RingValueBonus = {
				{
					RequiredValue = 2.05e16,
					BonusPercent = 0.12
				},
				{
					RequiredValue = 5000000000000000,
					BonusPercent = 0.18
				},
				{
					RequiredValue = 1e16,
					BonusPercent = 0.25
				}
			}
		}
	}
}