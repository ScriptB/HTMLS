-- Path: StarterGui.MainUI.Menus.ShopFrame.ScrollingFrame.DinosaurEgg.PolicyDissbler
-- Class: LocalScript

-- https://lua.expert/
local PolicyService = game:GetService("PolicyService")
local LocalPlayer = game:GetService("Players").LocalPlayer
local v1 = script.Parent
local v2, v3 = pcall(function() --[[ Line: 7 | Upvalues: PolicyService (copy), LocalPlayer (copy) ]]
	return PolicyService:GetPolicyInfoForPlayerAsync(LocalPlayer)
end)
if v2 and v3 then
	if v3.ArePaidRandomItemsRestricted then
		v1.Visible = false
	end
else
	warn("Failed to get policy info for player")
end