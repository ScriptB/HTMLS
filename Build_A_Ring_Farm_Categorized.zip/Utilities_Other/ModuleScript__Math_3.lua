-- Path: ReplicatedStorage.UserGenerated.Math
-- Class: ModuleScript

-- https://lua.expert/
return {}