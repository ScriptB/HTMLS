-- Path: ReplicatedStorage.SparkMod.Pools
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Types.Pools)
return {}