-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.Onboarding
-- Class: ModuleScript

-- https://lua.expert/
game:GetService("CollectionService")
game:GetService("GuiService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
game:GetService("TweenService")
local ConfettiHandler = require(ReplicatedStorage.Shared.VFX.ConfettiHandler)
local DataAggregation = require(script.Parent.Parent.Modules.DataAggregation)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
require(script.Parent.Parent.Binding.SignalBank)
local UIController = require(script.Parent.UIController)
local SellCrates = ReplicatedStorage.Remotes.SellCrates
local RollSeeds = ReplicatedStorage.Remotes.RollSeeds
local BuySeed = ReplicatedStorage.Remotes.BuySeed
local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
local Tutorial = PlayerGui:WaitForChild("Tutorial")
local Header = Tutorial:WaitForChild("Header")
local Header_2 = Header:WaitForChild("Header")
local ScreenHighlight = Tutorial:WaitForChild("ScreenHighlight")
local SH1 = Tutorial:WaitForChild("SH1")
local SH2 = Tutorial:WaitForChild("SH2")
local SH3 = Tutorial:WaitForChild("SH3")
local SH4 = Tutorial:WaitForChild("SH4")
local Beam = script:WaitForChild("Beam")
local Pointer = script:WaitForChild("Pointer")
local v1 = nil
local v2 = nil
local v3 = nil
local v4 = nil
local v5 = nil
local v6 = nil
local v7 = nil
local t = {}
local function CleanupConnections() --[[ CleanupConnections | Line: 47 | Upvalues: t (copy) ]]
	for v1, v2 in t do
		v2:Disconnect()
	end
	table.clear(t)
end
local function SetHeaderVisible(p1) --[[ SetHeaderVisible | Line: 54 | Upvalues: Header (copy) ]]
	Header.Visible = p1
end
local function SetHeaderText(p1) --[[ SetHeaderText | Line: 56 | Upvalues: Header (copy), Header_2 (copy), SFXModule (copy) ]]
	Header.Text = p1
	Header_2.Text = "[TUTORIAL]"
	Header.Visible = true
	SFXModule.PlaySFX("NotificationInfo")
end
local function HideScreenHighlights() --[[ HideScreenHighlights | Line: 63 | Upvalues: ScreenHighlight (copy), SH1 (copy), SH2 (copy), SH3 (copy), SH4 (copy) ]]
	ScreenHighlight.Visible = false
	SH1.Visible = false
	SH2.Visible = false
	SH3.Visible = false
	SH4.Visible = false
end
local function FindTutorialAttachment(p1) --[[ FindTutorialAttachment | Line: 72 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("Attachment") and v2.Name == "TutorialAttachment1" then
			return v2
		end
	end
	return nil
end
local function MoveTutorialAttachment(p1, p2) --[[ MoveTutorialAttachment | Line: 81 ]]
	local Dirt = p2:FindFirstChild("Dirt")
	if not (Dirt and Dirt:IsA("BasePart")) then
		return
	end
	p1.Parent = p2
	p1.WorldPosition = Dirt.Position
end
local function SetSelectedPlot1Model(p1, p2) --[[ SetSelectedPlot1Model | Line: 89 | Upvalues: v3 (ref), FindTutorialAttachment (copy) ]]
	v3 = p2
	local v1 = FindTutorialAttachment(p1)
	local v2 = if v1 then v1.Parent else v1
	if v1 then
		local Dirt = p2:FindFirstChild("Dirt")
		if Dirt and Dirt:IsA("BasePart") then
			v1.Parent = p2
			v1.WorldPosition = Dirt.Position
		end
	end
	local FarmPlot = p1:FindFirstChild("FarmPlot")
	local v32 = if FarmPlot then FarmPlot:FindFirstChild("TutorialAttachment2", true) else FarmPlot
	if not v32 or (not v32:IsA("Attachment") or (v32.Parent ~= p2 or not (v2 and v2:IsA("Model")))) then
		return
	end
	local Dirt = v2:FindFirstChild("Dirt")
	if not (Dirt and Dirt:IsA("BasePart")) then
		return
	end
	v32.Parent = v2
	v32.WorldPosition = Dirt.Position
end
local function FindPlot1Model(p1) --[[ FindPlot1Model | Line: 112 | Upvalues: v3 (ref) ]]
	if v3 and v3.Parent then
		return v3
	end
	local FarmPlot = p1:FindFirstChild("FarmPlot")
	if not FarmPlot then
		return nil
	end
	local v1 = FarmPlot:FindFirstChild("TutorialAttachment1", true).Parent
	if v1 then
		return v1
	else
		return nil
	end
end
local function CreateBeamToTarget(p1) --[[ CreateBeamToTarget | Line: 129 | Upvalues: v6 (ref), v4 (ref), v5 (ref), v7 (ref), v1 (ref), LocalPlayer (copy), Beam (copy), Pointer (copy) ]]
	if v6 then
		v6:Destroy()
		v6 = nil
	end
	if v4 then
		v4:Destroy()
		v4 = nil
	end
	if v5 then
		v5:Destroy()
		v5 = nil
	end
	if v7 then
		v7:Destroy()
		v7 = nil
	end
	v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
	local HumanoidRootPart = v1:WaitForChild("HumanoidRootPart")
	v4 = Instance.new("Attachment")
	v4.Parent = HumanoidRootPart
	v5 = Instance.new("Attachment")
	v5.Parent = workspace.Terrain
	v5.WorldPosition = p1.WorldPosition
	v6 = Beam:Clone()
	v6.Attachment0 = v4
	v6.Attachment1 = v5
	v6.Enabled = true
	v6.Parent = workspace
	v7 = Pointer:Clone()
	v7.Adornee = nil
	v7.StudsOffset = Vector3.new(0, 3, 0)
	v7.Enabled = true
	v7.Parent = v5
end
local function CreateBeamOnly(p1) --[[ CreateBeamOnly | Line: 173 | Upvalues: v6 (ref), v4 (ref), v5 (ref), v7 (ref), v1 (ref), LocalPlayer (copy), Beam (copy) ]]
	if v6 then
		v6:Destroy()
		v6 = nil
	end
	if v4 then
		v4:Destroy()
		v4 = nil
	end
	if v5 then
		v5:Destroy()
		v5 = nil
	end
	if v7 then
		v7:Destroy()
		v7 = nil
	end
	v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
	local HumanoidRootPart = v1:WaitForChild("HumanoidRootPart")
	v4 = Instance.new("Attachment")
	v4.Parent = HumanoidRootPart
	v5 = Instance.new("Attachment")
	v5.Parent = workspace.Terrain
	v5.WorldPosition = p1.WorldPosition
	v6 = Beam:Clone()
	v6.Attachment0 = v4
	v6.Attachment1 = v5
	v6.Enabled = true
	v6.Parent = workspace
end
local function HideBeamAndPointer() --[[ HideBeamAndPointer | Line: 210 | Upvalues: v6 (ref), v7 (ref) ]]
	if v6 then
		v6.Enabled = false
	end
	if not v7 then
		return
	end
	v7.Enabled = false
end
local function ShowBeamAndPointer() --[[ ShowBeamAndPointer | Line: 220 | Upvalues: v6 (ref), v7 (ref) ]]
	if v6 then
		v6.Enabled = true
	end
	if not v7 then
		return
	end
	v7.Enabled = true
end
local function DestroyBeamAndPointer() --[[ DestroyBeamAndPointer | Line: 230 | Upvalues: v6 (ref), v4 (ref), v5 (ref), v7 (ref) ]]
	if v6 then
		v6:Destroy()
		v6 = nil
	end
	if v4 then
		v4:Destroy()
		v4 = nil
	end
	if v5 then
		v5:Destroy()
		v5 = nil
	end
	if not v7 then
		return
	end
	v7:Destroy()
	v7 = nil
end
local function GetEquippedPlantTool() --[[ GetEquippedPlantTool | Line: 250 | Upvalues: v1 (ref), LocalPlayer (copy) ]]
	v1 = LocalPlayer.Character
	if not v1 then
		return nil
	end
	local v12 = v1:FindFirstChildWhichIsA("Tool")
	if not v12 then
		return nil
	end
	local v2 = v12:GetAttribute("Plant")
	if v2 and (typeof(v2) == "string" and v2 ~= "") then
		return v12
	else
		return nil
	end
end
local function FindPlot2Model(p1) --[[ FindPlot2Model | Line: 267 ]]
	local FarmPlot = p1:FindFirstChild("FarmPlot")
	if not FarmPlot then
		return nil
	end
	local TutorialAttachment2 = FarmPlot:FindFirstChild("TutorialAttachment2", true)
	if TutorialAttachment2 then
		return TutorialAttachment2.Parent
	else
		return nil
	end
end
local function FindTutorialAttachment2(p1) --[[ FindTutorialAttachment2 | Line: 280 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("Attachment") and v2.Name == "TutorialAttachment2" then
			return v2
		end
	end
	return nil
end
local function PositionHighlightFrames(p1) --[[ PositionHighlightFrames | Line: 290 | Upvalues: Tutorial (copy), SH1 (copy), SH2 (copy), SH3 (copy), SH4 (copy) ]]
	local AbsolutePosition = p1.AbsolutePosition
	local AbsoluteSize = p1.AbsoluteSize
	local AbsolutePosition_2 = Tutorial.AbsolutePosition
	local v1 = AbsolutePosition.X - AbsolutePosition_2.X
	local v2 = AbsolutePosition.Y - AbsolutePosition_2.Y
	local v3 = v2 - 6
	local v4 = v1 + AbsoluteSize.X + 6
	local v5 = v2 + AbsoluteSize.Y + 6
	SH1.Position = UDim2.fromOffset(0, 0)
	SH1.Size = UDim2.new(1, 0, 0, v3)
	SH1.Visible = true
	SH2.Position = UDim2.fromOffset(0, v5)
	SH2.Size = UDim2.new(1, 0, 0, Tutorial.AbsoluteSize.Y - v5)
	SH2.Visible = true
	SH3.Position = UDim2.fromOffset(0, v3)
	SH3.Size = UDim2.fromOffset(v1 - 6, v5 - v3)
	SH3.Visible = true
	SH4.Position = UDim2.fromOffset(v4, v3)
	SH4.Size = UDim2.new(1, -v4, 0, v5 - v3)
	SH4.Visible = true
end
local function v8(p1, p2) --[[ SetStage | Line: 334 | Upvalues: v2 (ref), t (copy), ScreenHighlight (copy), SH1 (copy), SH2 (copy), SH3 (copy), SH4 (copy), Header (copy), Header_2 (copy), SFXModule (copy), FindTutorialAttachment (copy), CreateBeamToTarget (copy), PlayerGui (copy), v6 (ref), v7 (ref), SetSelectedPlot1Model (copy), v8 (copy), v4 (ref), v5 (ref), v1 (ref), LocalPlayer (copy), ReplicatedStorage (copy), PositionHighlightFrames (copy), RunService (copy), v3 (ref), CreateBeamOnly (copy), SellCrates (copy), RollSeeds (copy), BuySeed (copy), FindTutorialAttachment2 (copy), ConfettiHandler (copy), UIController (copy) ]]
	if p1 == v2 then
		return
	end
	v2 = p1
	for v12, v22 in t do
		v22:Disconnect()
	end
	table.clear(t)
	ScreenHighlight.Visible = false
	SH1.Visible = false
	SH2.Visible = false
	SH3.Visible = false
	SH4.Visible = false
	local v32 = 1
	if p1 == "WALK_TO_PLOT" then
		v32 = 1
		Header.Text = "Go to your Farm and Unlock a plot"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		local v42 = FindTutorialAttachment(p2)
		if v42 then
			CreateBeamToTarget(v42)
		end
		local v62 = PlayerGui.ChildAdded:Connect(function(p1) --[[ Line: 360 | Upvalues: v6 (ref), v7 (ref), v2 (ref) ]]
			if p1.Name ~= "PlotUnlockGui" or not p1:IsA("BillboardGui") then
				return
			end
			if v6 then
				v6.Enabled = false
			end
			if v7 then
				v7.Enabled = false
			end
			local v1 = nil
			v1 = p1.Destroying:Connect(function() --[[ Line: 364 | Upvalues: v2 (ref), v6 (ref), v7 (ref), v1 (ref) ]]
				if v2 == "WALK_TO_PLOT" then
					if v6 then
						v6.Enabled = true
					end
					if v7 then
						v7.Enabled = true
					end
				end
				v1:Disconnect()
			end)
		end)
		table.insert(t, v62)
		local function AdvanceFromPlot(p1) --[[ AdvanceFromPlot | Line: 374 | Upvalues: v2 (ref), SetSelectedPlot1Model (ref), p2 (copy), v8 (ref) ]]
			if v2 == "WALK_TO_PLOT" then
				SetSelectedPlot1Model(p2, p1)
				v8("EQUIP_SEED", p2)
			end
		end
		local FarmPlot = p2:FindFirstChild("FarmPlot")
		if FarmPlot then
			for v72, v82 in FarmPlot:GetChildren() do
				if v82:IsA("Model") and v82.Name:match("^Plot%d+$") then
					if v82:GetAttribute("Unlocked") == true then
						if v2 == "WALK_TO_PLOT" then
							SetSelectedPlot1Model(p2, v82)
							v8("EQUIP_SEED", p2)
						end
						return
					end
					local v9 = v82:GetAttributeChangedSignal("Unlocked"):Connect(function() --[[ Line: 395 | Upvalues: v82 (copy), v2 (ref), SetSelectedPlot1Model (ref), p2 (copy), v8 (ref) ]]
						if v82:GetAttribute("Unlocked") ~= true then
							return
						end
						if v2 ~= "WALK_TO_PLOT" then
							return
						end
						SetSelectedPlot1Model(p2, v82)
						v8("EQUIP_SEED", p2)
					end)
					table.insert(t, v9)
				end
			end
		end
	elseif p1 == "EQUIP_SEED" then
		v32 = 2
		Header.Text = "Equip a Seed from your inventory"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		v1 = LocalPlayer.Character
		local v11
		if v1 then
			local v12 = v1:FindFirstChildWhichIsA("Tool")
			if v12 then
				local v13 = v12:GetAttribute("Plant")
				v11 = if v13 and (typeof(v13) == "string" and v13 ~= "") then v12 else nil
			else
				v11 = nil
			end
		else
			v11 = nil
		end
		if v11 then
			v8("PLANT_SEED", p2)
			return
		end
		local function TryHighlightSlot() --[[ TryHighlightSlot | Line: 417 | Upvalues: PlayerGui (ref), ReplicatedStorage (ref), PositionHighlightFrames (ref) ]]
			local BackpackGui = PlayerGui:FindFirstChild("BackpackGui")
			if not BackpackGui then
				return false
			end
			local Backpack = BackpackGui:FindFirstChild("Backpack")
			if not Backpack then
				return false
			end
			local Hotbar = Backpack:FindFirstChild("Hotbar")
			if not Hotbar then
				return false
			end
			local CustomPackAPI = ReplicatedStorage:FindFirstChild("CustomPackAPI")
			if not (CustomPackAPI and CustomPackAPI:IsA("BindableFunction")) then
				return false
			end
			local v1, v2 = pcall(function() --[[ Line: 436 | Upvalues: CustomPackAPI (copy) ]]
				return CustomPackAPI:Invoke("GetAllSlots", {})
			end)
			if not v1 or type(v2) ~= "table" then
				return false
			end
			local v3 = nil
			for v4, v5 in v2 do
				if type(v5) == "table" then
					local Tool = v5.Tool
					if Tool and Tool:IsA("Tool") then
						local v6 = Tool:GetAttribute("Plant")
						if v6 and (typeof(v6) == "string" and v6 ~= "") then
							local SlotNumber = v5.SlotNumber
							if type(SlotNumber) == "number" and (v3 == nil or SlotNumber < v3) then
								v3 = SlotNumber
							end
						end
					end
				end
			end
			if not v3 then
				return false
			end
			local v7 = Hotbar:FindFirstChild((tostring(v3)))
			if v7 and v7:IsA("GuiObject") then
				PositionHighlightFrames(v7)
				return true
			else
				return false
			end
		end
		table.insert(t, (RunService.Heartbeat:Connect(function() --[[ Line: 478 | Upvalues: TryHighlightSlot (copy) ]]
			TryHighlightSlot()
		end)))
		v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
		local function CheckForPlantTool(p1) --[[ CheckForPlantTool | Line: 483 | Upvalues: v8 (ref), p2 (copy) ]]
			if not p1:IsA("Tool") then
				return
			end
			local v1 = p1:GetAttribute("Plant")
			if not v1 or (typeof(v1) ~= "string" or v1 == "") then
				return
			end
			v8("PLANT_SEED", p2)
		end
		table.insert(t, (v1.ChildAdded:Connect(CheckForPlantTool)))
		for v19, v20 in v1:GetChildren() do
			if v20:IsA("Tool") then
				local v21 = v20:GetAttribute("Plant")
				if v21 and (typeof(v21) == "string" and v21 ~= "") then
					v8("PLANT_SEED", p2)
				end
			end
		end
	elseif p1 == "PLANT_SEED" then
		v32 = 3
		Header.Text = "Plant the Seed on your plot"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		ScreenHighlight.Visible = false
		SH1.Visible = false
		SH2.Visible = false
		SH3.Visible = false
		SH4.Visible = false
		local v22 = FindTutorialAttachment(p2)
		if v22 then
			CreateBeamToTarget(v22)
		end
		v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
		local v25 = v1.ChildRemoved:Connect(function(p1) --[[ Line: 516 | Upvalues: v2 (ref), v1 (ref), LocalPlayer (ref), v8 (ref), p2 (copy) ]]
			if p1:IsA("Tool") then
				task.defer(function() --[[ Line: 521 | Upvalues: v2 (ref), v1 (ref), LocalPlayer (ref), v8 (ref), p2 (ref) ]]
					if v2 ~= "PLANT_SEED" then
						return
					end
					v1 = LocalPlayer.Character
					local v12
					if v1 then
						local v22 = v1:FindFirstChildWhichIsA("Tool")
						if v22 then
							local v3 = v22:GetAttribute("Plant")
							v12 = if v3 and (typeof(v3) == "string" and v3 ~= "") then v22 else nil
						else
							v12 = nil
						end
					else
						v12 = nil
					end
					if v12 then
						return
					end
					v8("EQUIP_SEED", p2)
				end)
			end
		end)
		table.insert(t, v25)
		v1 = LocalPlayer.Character
		local v26
		if v1 then
			local v27 = v1:FindFirstChildWhichIsA("Tool")
			if v27 then
				local v28 = v27:GetAttribute("Plant")
				v26 = if v28 and (typeof(v28) == "string" and v28 ~= "") then v27 else nil
			else
				v26 = nil
			end
		else
			v26 = nil
		end
		if not v26 then
			v8("EQUIP_SEED", p2)
			return
		end
		local v29
		if v3 and v3.Parent then
			v29 = v3
		else
			local FarmPlot = p2:FindFirstChild("FarmPlot")
			if FarmPlot then
				local v30 = FarmPlot:FindFirstChild("TutorialAttachment1", true).Parent
				v29 = if v30 then v30 else nil
			else
				v29 = nil
			end
		end
		if v29 then
			for v31, v322 in v29:GetChildren() do
				if v322:IsA("BasePart") and v322.Name == "Dirt" then
					if v322:GetAttribute("PlantName") then
						v8("UPGRADE_PLANT", p2)
						return
					end
					local v33 = v322:GetAttributeChangedSignal("PlantName"):Connect(function() --[[ Line: 550 | Upvalues: v322 (copy), v8 (ref), p2 (copy) ]]
						if not v322:GetAttribute("PlantName") then
							return
						end
						v8("UPGRADE_PLANT", p2)
					end)
					table.insert(t, v33)
				end
			end
		end
	elseif p1 == "UPGRADE_PLANT" then
		v32 = 4
		Header.Text = "Click on your Plant and Upgrade it"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		local v35 = FindTutorialAttachment(p2)
		if v35 then
			CreateBeamToTarget(v35)
		end
		local v36 = false
		local function CloseActivePlantGui() --[[ CloseActivePlantGui | Line: 575 | Upvalues: PlayerGui (ref) ]]
			for v1, v2 in PlayerGui:GetChildren() do
				if v2.Name == "PlantGui" and v2:IsA("BillboardGui") then
					v2:Destroy()
				end
			end
		end
		local v37 = PlayerGui.ChildAdded:Connect(function(p1) --[[ Line: 585 | Upvalues: v6 (ref), v7 (ref), v2 (ref) ]]
			if p1.Name ~= "PlantGui" or not p1:IsA("BillboardGui") then
				return
			end
			if v6 then
				v6.Enabled = false
			end
			if v7 then
				v7.Enabled = false
			end
			local v1 = nil
			v1 = p1.Destroying:Connect(function() --[[ Line: 589 | Upvalues: v2 (ref), v6 (ref), v7 (ref), v1 (ref) ]]
				if v2 == "UPGRADE_PLANT" then
					if v6 then
						v6.Enabled = true
					end
					if v7 then
						v7.Enabled = true
					end
				end
				v1:Disconnect()
			end)
		end)
		table.insert(t, v37)
		local v39
		if v3 and v3.Parent then
			v39 = v3
		else
			local FarmPlot = p2:FindFirstChild("FarmPlot")
			if FarmPlot then
				local v40 = FarmPlot:FindFirstChild("TutorialAttachment1", true).Parent
				v39 = if v40 then v40 else nil
			else
				v39 = nil
			end
		end
		if v39 then
			for v41, v42 in v39:GetChildren() do
				if v42:IsA("BasePart") and (v42.Name == "Dirt" and v42:GetAttribute("PlantName")) then
					local v43 = v42:GetAttributeChangedSignal("PlantLevel"):Connect(function() --[[ Line: 604 | Upvalues: v36 (ref), v42 (copy), CloseActivePlantGui (copy), v8 (ref), p2 (copy) ]]
						if v36 then
							return
						end
						local v1 = v42:GetAttribute("PlantLevel")
						if not (v1 and v1 >= 2) then
							return
						end
						v36 = true
						CloseActivePlantGui()
						v8("ROLL_SEED", p2)
					end)
					table.insert(t, v43)
				end
			end
			ReplicatedStorage.Remotes.LogFunnel:FireServer(v32, p1)
			return
		end
	elseif p1 == "PICKUP_CRATE" then
		v32 = 5
		Header.Text = "Pick up a Crate"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		local CratePosition = p2:FindFirstChild("CratePosition")
		if CratePosition and CratePosition:IsA("Attachment") then
			CreateBeamOnly(CratePosition)
		end
		v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
		if v1:FindFirstChild("HeldCrates") then
			v8("SELL_CRATE", p2)
			return
		end
		local v47 = v1.ChildAdded:Connect(function(p1) --[[ Line: 639 | Upvalues: v8 (ref), p2 (copy) ]]
			if p1.Name ~= "HeldCrates" then
				return
			end
			v8("SELL_CRATE", p2)
		end)
		table.insert(t, v47)
	elseif p1 == "SELL_CRATE" then
		v32 = 6
		Header.Text = "Sell the Crate at the Desk"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		local Sell = p2:FindFirstChild("Sell", true)
		if Sell then
			local Desk = Sell:FindFirstChild("Desk")
			if Desk then
				local PromptAttachment = Desk:FindFirstChild("PromptAttachment")
				if PromptAttachment and PromptAttachment:IsA("Attachment") then
					CreateBeamOnly(PromptAttachment)
				end
			end
		end
		local v49 = SellCrates.OnClientEvent:Connect(function() --[[ Line: 666 | Upvalues: v8 (ref), p2 (copy) ]]
			v8("UPGRADE_SAW", p2)
		end)
		table.insert(t, v49)
	elseif p1 == "ROLL_SEED" then
		v32 = 7
		Header.Text = "Roll for a new Seed"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		local RollPlatform = p2:FindFirstChild("RollPlatform")
		if RollPlatform then
			local Lever = RollPlatform:FindFirstChild("Lever")
			if Lever then
				local LevelPrompt = Lever:FindFirstChild("LevelPrompt")
				if LevelPrompt and LevelPrompt:IsA("Attachment") then
					CreateBeamOnly(LevelPrompt)
				end
			end
		end
		local v51 = RollSeeds.OnClientEvent:Connect(function() --[[ Line: 690 | Upvalues: v8 (ref), p2 (copy) ]]
			v8("BUY_SEED", p2)
		end)
		table.insert(t, v51)
	elseif p1 == "BUY_SEED" then
		v32 = 8
		Header.Text = "Buy your new Seed"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		local RollPlatform = p2:FindFirstChild("RollPlatform")
		if RollPlatform then
			for i = 1, 5 do
				local v52 = RollPlatform:FindFirstChild((tostring(i)))
				if v52 and v52:IsA("Attachment") then
					local v53 = false
					for v54, v55 in v52:GetChildren() do
						if v55:IsA("Model") then
							v53 = true
							break
						end
					end
					if v53 then
						CreateBeamOnly(v52)
						break
					end
				end
			end
		end
		local v57 = BuySeed.OnClientEvent:Connect(function(p1, p22) --[[ Line: 724 | Upvalues: v8 (ref), p2 (copy) ]]
			if not p22 then
				return
			end
			v8("PLANT_SEED_2", p2)
		end)
		table.insert(t, v57)
	elseif p1 == "PLANT_SEED_2" then
		v32 = 9
		Header.Text = "Plant your new Seed"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		ScreenHighlight.Visible = false
		SH1.Visible = false
		SH2.Visible = false
		SH3.Visible = false
		SH4.Visible = false
		local v58 = FindTutorialAttachment2(p2)
		if v58 then
			CreateBeamToTarget(v58)
		end
		local v60 = PlayerGui.ChildAdded:Connect(function(p1) --[[ Line: 745 | Upvalues: v6 (ref), v7 (ref), v2 (ref) ]]
			if p1.Name ~= "PlotUnlockGui" or not p1:IsA("BillboardGui") then
				return
			end
			if v6 then
				v6.Enabled = false
			end
			if v7 then
				v7.Enabled = false
			end
			local v1 = nil
			v1 = p1.Destroying:Connect(function() --[[ Line: 749 | Upvalues: v2 (ref), v6 (ref), v7 (ref), v1 (ref) ]]
				if v2 ~= "PLANT_SEED_2" then
					v1:Disconnect()
					return
				end
				if v6 then
					v6.Enabled = true
				end
				if not v7 then
					v1:Disconnect()
					return
				end
				v7.Enabled = true
				v1:Disconnect()
			end)
		end)
		table.insert(t, v60)
		local v61
		if v3 and v3.Parent then
			v61 = v3
		else
			local FarmPlot = p2:FindFirstChild("FarmPlot")
			if FarmPlot then
				local v62 = FarmPlot:FindFirstChild("TutorialAttachment1", true).Parent
				v61 = if v62 then v62 else nil
			else
				v61 = nil
			end
		end
		local FarmPlot = p2:FindFirstChild("FarmPlot")
		if v58 and FarmPlot then
			for v63, v64 in FarmPlot:GetChildren() do
				if v64:IsA("Model") and (v64.Name:match("^Plot%d+$") and v64 ~= v61) then
					local v65 = v64:GetAttributeChangedSignal("Unlocked"):Connect(function() --[[ Line: 768 | Upvalues: v64 (copy), v58 (copy), v2 (ref), v8 (ref), p2 (copy) ]]
						if v64:GetAttribute("Unlocked") ~= true then
							return
						end
						local v1 = v58
						local v22 = v64
						local Dirt = v22:FindFirstChild("Dirt")
						if Dirt and Dirt:IsA("BasePart") then
							v1.Parent = v22
							v1.WorldPosition = Dirt.Position
						end
						v2 = nil
						v8("PLANT_SEED_2", p2)
					end)
					table.insert(t, v65)
				end
			end
		end
		local FarmPlot_2 = p2:FindFirstChild("FarmPlot")
		local v67
		if FarmPlot_2 then
			local TutorialAttachment2 = FarmPlot_2:FindFirstChild("TutorialAttachment2", true)
			v67 = if TutorialAttachment2 then TutorialAttachment2.Parent else nil
		else
			v67 = nil
		end
		if v67 then
			for v68, v69 in v67:GetChildren() do
				if v69:IsA("BasePart") and v69.Name == "Dirt" then
					if v69:GetAttribute("PlantName") then
						v8("PICKUP_CRATE", p2)
						return
					end
					local v70 = v69:GetAttributeChangedSignal("PlantName"):Connect(function() --[[ Line: 789 | Upvalues: v69 (copy), v8 (ref), p2 (copy) ]]
						if not v69:GetAttribute("PlantName") then
							return
						end
						v8("PICKUP_CRATE", p2)
					end)
					table.insert(t, v70)
				end
			end
		end
	elseif p1 == "UPGRADE_SAW" then
		v32 = 10
		Header.Text = "Upgrade your Saw Yield"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		local PlotUpgradeSign = p2:FindFirstChild("PlotUpgradeSign")
		if PlotUpgradeSign then
			local Screen = PlotUpgradeSign:FindFirstChild("Screen")
			if Screen then
				local Tutorial = Screen:FindFirstChild("Tutorial")
				if Tutorial and Tutorial:IsA("Attachment") then
					CreateBeamOnly(Tutorial)
				end
			end
		end
		local FarmPlot = p2:FindFirstChild("FarmPlot")
		if FarmPlot then
			local v72 = FarmPlot:GetAttribute("SawYield_Floor1") or 1
			local v73 = FarmPlot:GetAttributeChangedSignal("SawYield_Floor1"):Connect(function() --[[ Line: 821 | Upvalues: FarmPlot (copy), v72 (copy), v8 (ref), p2 (copy) ]]
				if not (v72 < (FarmPlot:GetAttribute("SawYield_Floor1") or 1)) then
					return
				end
				v8("COMPLETE", p2)
			end)
			table.insert(t, v73)
		end
	elseif p1 == "COMPLETE" then
		v32 = 11
		for v75, v76 in t do
			v76:Disconnect()
		end
		table.clear(t)
		ScreenHighlight.Visible = false
		SH1.Visible = false
		SH2.Visible = false
		SH3.Visible = false
		SH4.Visible = false
		if v6 then
			v6:Destroy()
			v6 = nil
		end
		if v4 then
			v4:Destroy()
			v4 = nil
		end
		if v5 then
			v5:Destroy()
			v5 = nil
		end
		if v7 then
			v7:Destroy()
			v7 = nil
		end
		SFXModule.PlaySFX("Reward")
		ConfettiHandler.SpawnConfetti(40)
		Header.Text = "Great job! Keep farming!"
		Header_2.Text = "[TUTORIAL]"
		Header.Visible = true
		SFXModule.PlaySFX("NotificationInfo")
		task.delay(3, function() --[[ Line: 842 | Upvalues: Header (ref) ]]
			Header.Visible = false
		end)
		UIController.OpenGui("TutorialFrame")
	end
	ReplicatedStorage.Remotes.LogFunnel:FireServer(v32, p1)
end
local function Main() --[[ Main | Line: 854 | Upvalues: DataAggregation (copy), ReplicatedStorage (copy), v1 (ref), LocalPlayer (copy), SetSelectedPlot1Model (copy), v3 (ref), v8 (copy) ]]
	if DataAggregation.WaitForReplica().Data.CompletedOnboarding == true then
		return
	end
	local v12 = ReplicatedStorage.Remotes.Plot.GetPlot:InvokeServer()
	if not v12 then
		return
	end
	v1 = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
	local v32 = nil
	local FarmPlot = v12:FindFirstChild("FarmPlot")
	if FarmPlot then
		for v4, v5 in FarmPlot:GetChildren() do
			if v5:IsA("Model") and (v5.Name:match("^Plot%d+$") and v5:GetAttribute("Unlocked") == true) then
				v32 = v32 or v5
				local Dirt = v5:FindFirstChild("Dirt")
				if Dirt and (Dirt:IsA("BasePart") and Dirt:GetAttribute("PlantName")) then
					SetSelectedPlot1Model(v12, v5)
					break
				end
			end
		end
	end
	if not v3 and v32 then
		SetSelectedPlot1Model(v12, v32)
	end
	local v6
	if v3 and v3.Parent then
		v6 = v3
	else
		local FarmPlot_2 = v12:FindFirstChild("FarmPlot")
		if FarmPlot_2 then
			local v7 = FarmPlot_2:FindFirstChild("TutorialAttachment1", true).Parent
			v6 = if v7 then v7 else nil
		else
			v6 = nil
		end
	end
	local v82
	if v6 and v6:GetAttribute("Unlocked") == true then
		local v9 = false
		local v10 = false
		for v11, v122 in v6:GetChildren() do
			if v122:IsA("BasePart") and (v122.Name == "Dirt" and v122:GetAttribute("PlantName")) then
				v10 = true
				if (v122:GetAttribute("PlantLevel") or 1) >= 2 then
					v9 = true
				end
			end
		end
		if v9 then
			local FarmPlot_2 = v12:FindFirstChild("FarmPlot")
			local v13 = if FarmPlot_2 then FarmPlot_2:GetAttribute("SawYield_Floor1") or 1 else 1
			local FarmPlot_3 = v12:FindFirstChild("FarmPlot")
			local v14
			if FarmPlot_3 then
				local TutorialAttachment2 = FarmPlot_3:FindFirstChild("TutorialAttachment2", true)
				v14 = if TutorialAttachment2 then TutorialAttachment2.Parent else nil
			else
				v14 = nil
			end
			local v15 = false
			if v14 then
				for v16, v17 in v14:GetChildren() do
					if v17:IsA("BasePart") and (v17.Name == "Dirt" and v17:GetAttribute("PlantName")) then
						v15 = true
					end
				end
			end
			v82 = if v13 >= 2 then "COMPLETE" elseif v15 then "PICKUP_CRATE" else "ROLL_SEED"
		elseif v10 then
			v82 = "UPGRADE_PLANT"
		else
			v1 = LocalPlayer.Character
			local v18
			if v1 then
				local v19 = v1:FindFirstChildWhichIsA("Tool")
				if v19 then
					local v20 = v19:GetAttribute("Plant")
					v18 = if v20 and (typeof(v20) == "string" and v20 ~= "") then v19 else nil
				else
					v18 = nil
				end
			else
				v18 = nil
			end
			v82 = if v18 then "PLANT_SEED" else "EQUIP_SEED"
		end
	else
		v82 = "WALK_TO_PLOT"
	end
	v8(v82, v12)
end
task.spawn(Main)
return {}