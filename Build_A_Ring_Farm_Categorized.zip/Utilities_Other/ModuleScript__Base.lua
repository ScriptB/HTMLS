-- Path: ReplicatedStorage.UserGenerated.Randoms.Base
-- Class: ModuleScript

-- https://lua.expert/
return table.freeze({})