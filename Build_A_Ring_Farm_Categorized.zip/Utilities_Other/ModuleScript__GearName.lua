-- Path: ReplicatedStorage.CmdrClient.Types.GearName
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Gear = require(ReplicatedStorage.Shared.Registry).Gear
return function(p1) --[[ Line: 5 | Upvalues: Gear (copy) ]]
	p1:RegisterType("gearName", {
		Transform = function(p1) --[[ Transform | Line: 7 | Upvalues: Gear (ref) ]]
			local list = {}
			local t = {}
			for k, v in pairs(Gear) do
				table.insert(list, k)
			end
			local v1 = p1:lower()
			for i, v in ipairs(list) do
				if v:lower():find(v1, 1, true) then
					table.insert(t, v)
				end
			end
			table.sort(t, function(p1, p2) --[[ Line: 22 | Upvalues: v1 (copy) ]]
				local v12 = if p1:lower() == v1 then true else false
				local v2 = if p2:lower() == v1 then true else false
				if v12 and not v2 then
					return true
				end
				if v2 and not v12 then
					return false
				end
				return p1 < p2
			end)
			return t
		end,
		Validate = function(p1) --[[ Validate | Line: 33 ]]
			return #p1 > 0, "No event with that name could be found."
		end,
		Autocomplete = function(p1) --[[ Autocomplete | Line: 37 ]]
			return p1
		end,
		Parse = function(p1) --[[ Parse | Line: 41 ]]
			return p1[1]
		end
	})
end