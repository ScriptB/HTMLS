-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.pop
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ pop | Line: 20 ]]
	local t = {}
	if type(p2) ~= "number" then
		p2 = 1
	end
	for i = 1, #p1 - p2 do
		table.insert(t, p1[i])
	end
	return t
end