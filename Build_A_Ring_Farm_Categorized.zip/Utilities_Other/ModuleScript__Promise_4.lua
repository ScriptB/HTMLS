-- Path: ReplicatedStorage.Packages._Index.sleitnick_comm@1.0.1.Promise
-- Class: ModuleScript

-- https://lua.expert/
return require(script.Parent.Parent["evaera_promise@4.0.0"].promise)