-- Path: ReplicatedStorage.Shared.Contracts.Definitions.Novice
-- Class: ModuleScript

-- https://lua.expert/
local CreateContract = require(script.Parent.Parent.CreateContract)
return table.freeze({
	submit500MValue = CreateContract.seedValue(500000000, {
		Description = "Submit plants worth 500M total seed value",
		Category = "Flexible"
	}),
	submit2Frozen = CreateContract.byMutation("Frozen", 2, {
		Description = "Submit 2 Frozen plants",
		Category = "Specific"
	}),
	submit3PrismaticPlus = CreateContract.byRarity("Prismatic", 3, {
		Description = "Submit 3 Prismatic+ plants",
		Category = "Flexible"
	}),
	submit1Worth250M = CreateContract.eachWorth(250000000, 1, {
		Description = "Submit 1 plant worth 250M+",
		Category = "Flexible"
	})
})