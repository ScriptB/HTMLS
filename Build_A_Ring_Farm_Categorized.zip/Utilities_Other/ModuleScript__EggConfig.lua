-- Path: ReplicatedStorage.Shared.EggConfig
-- Class: ModuleScript

-- https://lua.expert/
return {
	Prices = {
		CommonEgg = 25000000,
		RareEgg = 25000000000,
		EpicEgg = 10000000000000
	},
	UnlockPrices = {
		Podium2 = 500000000,
		Podium3 = 25000000000,
		Podium4 = 25000000000000,
		Podium5 = 1000000000000000
	},
	CommonEgg = {
		["Golden Retriever"] = 52,
		Capybara = 30,
		Llama = 15,
		Elephant = 2.5,
		Gorilla = 0.5
	},
	RareEgg = {
		Elephant = 52,
		Gorilla = 30,
		Crocodile = 15,
		Lion = 2.5,
		["Polar Bear"] = 0.5
	},
	EpicEgg = {
		Crocodile = 52,
		Lion = 30,
		["Polar Bear"] = 15,
		Mammoth = 2.5,
		Hydra = 0.5
	},
	DinosaurEgg = {
		Triceratops = 30,
		Spinosaurus = 15,
		Gallimimus = 52,
		Velociraptor = 2.5,
		["T-Rex"] = 0.5
	},
	Size = {
		Regular = 63,
		Big = 32,
		Giant = 5
	},
	RestockChances = {
		CommonEgg = 62,
		RareEgg = 31,
		EpicEgg = 7
	}
}