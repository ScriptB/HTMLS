-- Path: ReplicatedFirst.LoadingScreen.LoadingScreen.Animation
-- Class: LocalScript

-- https://lua.expert/
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
Players.LocalPlayer:WaitForChild("PlayerGui")
local v1 = script.Parent
local Container = v1:WaitForChild("Background"):WaitForChild("Container")
local PlaceImage = Container:WaitForChild("PlaceImage")
local Dots = Container:WaitForChild("Dots")
local GameName = Container:WaitForChild("GameName")
v1.Enabled = true
spawn(function() --[[ Line: 20 ]]
	game:GetService("ContentProvider"):PreloadAsync({ workspace, game:GetService("ReplicatedStorage"), game:GetService("PlayerGui") })
end)
local v2 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v3 = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v4 = TweenInfo.new(1.2, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true)
local v5 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
PlaceImage.ImageTransparency = 1
GameName.TextTransparency = 1
task.spawn(function() --[[ Line: 32 | Upvalues: TweenService (copy), PlaceImage (copy), v5 (copy), GameName (copy), Dots (copy) ]]
	TweenService:Create(PlaceImage, v5, {
		ImageTransparency = 0
	}):Play()
	TweenService:Create(GameName, v5, {
		TextTransparency = 0
	}):Play()
	task.delay(1, function() --[[ Line: 38 | Upvalues: Dots (ref), TweenService (ref), v5 (ref) ]]
		for i = 1, 5 do
			local v1 = Dots:FindFirstChild((tostring(i)))
			if v1 then
				task.wait(0.2)
				TweenService:Create(v1, v5, {
					BackgroundTransparency = 0
				}):Play()
			end
		end
	end)
end)
local function BounceDot(p1) --[[ BounceDot | Line: 50 | Upvalues: TweenService (copy), v2 (copy), v3 (copy) ]]
	local Position = p1.Position
	local v1 = TweenService:Create(p1, v2, {
		Position = UDim2.new(Position.X.Scale, Position.X.Offset, Position.Y.Scale - 0.045, Position.Y.Offset)
	})
	local v22 = TweenService:Create(p1, v3, {
		Position = Position
	})
	v1:Play()
	v1.Completed:Wait()
	v22:Play()
	v22.Completed:Wait()
end
task.spawn(function() --[[ Line: 60 | Upvalues: v1 (copy), Dots (copy), BounceDot (copy) ]]
	while v1.Enabled do
		for i = 1, 5 do
			local v12 = Dots:FindFirstChild((tostring(i)))
			if v12 then
				task.spawn(function() --[[ Line: 65 | Upvalues: BounceDot (ref), v12 (copy) ]]
					BounceDot(v12)
				end)
				task.wait(0.15)
			end
		end
		task.wait(0.3)
	end
end)
task.spawn(function() --[[ Line: 75 | Upvalues: PlaceImage (copy), TweenService (copy), v4 (copy), v1 (copy) ]]
	PlaceImage.Rotation = -5
	local v12 = TweenService:Create(PlaceImage, v4, {
		Rotation = 5
	})
	v12:Play()
	while v1.Enabled do
		task.wait(0.5)
	end
	v12:Destroy()
end)