-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.mergeDeep
-- Class: ModuleScript

-- https://lua.expert/
local None = require(script.Parent.Parent.None)
local copyDeep = require(script.Parent.copyDeep)
local function v2(...) --[[ mergeDeep | Line: 28 | Upvalues: None (copy), copyDeep (copy), v2 (copy) ]]
	local t = {}
	for i = 1, select("#", ...) do
		local v1 = select(i, ...)
		if type(v1) == "table" then
			for k, v in pairs(v1) do
				if v == None then
					t[k] = nil
					continue
				end
				if type(v) == "table" then
					if t[k] ~= nil and type(t[k]) == "table" then
						t[k] = v2(t[k], v)
						continue
					end
					t[k] = copyDeep(v)
					continue
				end
				t[k] = v
			end
		end
	end
	return t
end
return v2