-- Path: ReplicatedStorage.Shared.VFX.ClickEffect
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local v1 = UDim2.fromScale(0.1, 0.1)
return {
	clickeffect = function() --[[ clickeffect | Line: 9 | Upvalues: Players (copy), TweenService (copy), v1 (copy) ]]
		local LocalPlayer = Players.LocalPlayer
		if not LocalPlayer then
			warn("[ClickEffect] No LocalPlayer found.")
			return
		end
		local PlayerGui = LocalPlayer:FindFirstChildOfClass("PlayerGui")
		if not PlayerGui then
			warn("[ClickEffect] PlayerGui not found for LocalPlayer.")
			return
		end
		local clickeffect = script:FindFirstChild("clickeffect")
		if not clickeffect then
			warn("[ClickEffect] \'clickeffect\' GUI not found under this script.")
			return
		end
		local v12 = LocalPlayer:GetMouse()
		local v2 = clickeffect:Clone()
		v2.Parent = PlayerGui
		local Frame = v2:FindFirstChild("Frame")
		if Frame and Frame:IsA("Frame") then
			Frame.Position = UDim2.fromOffset(v12.X, v12.Y)
			Frame.Size = UDim2.fromOffset(0, 0)
			Frame.Transparency = 0
			local v3 = TweenService:Create(Frame, TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
				Size = v1
			})
			local v4 = TweenService:Create(Frame, TweenInfo.new(0.3, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
				Transparency = 1
			})
			v3:Play()
			v4:Play()
			v3.Completed:Wait()
		else
			warn("[ClickEffect] \'Frame\' not found inside \'clickeffect\' GUI.")
		end
		v2:Destroy()
	end
}