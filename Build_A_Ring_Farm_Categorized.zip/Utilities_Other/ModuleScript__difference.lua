-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.difference
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
local difference = require(script.Parent.Parent.Set.difference)
local toArray = require(script.Parent.Parent.Set.toArray)
local toSet = require(script.Parent.toSet)
return function(p1, ...) --[[ difference | Line: 25 | Upvalues: toSet (copy), difference (copy), toArray (copy) ]]
	local v1 = toSet(p1)
	local t = {}
	for v2, v3 in { ... } do
		if typeof(v3) == "table" then
			table.insert(t, toSet(v3))
		end
	end
	return toArray((difference(v1, unpack(t))))
end