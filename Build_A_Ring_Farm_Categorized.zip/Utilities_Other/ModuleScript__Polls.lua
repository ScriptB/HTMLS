-- Path: ReplicatedStorage.SparkMod.Polls
-- Class: ModuleScript

-- https://lua.expert/
local RunService = game:GetService("RunService")
local Remotes = require(script.Parent.Internal.Remotes)
local Signal = require(script.Parent.Internal.Signal)
require(script.Parent.Types.Polls)
local t = {}
local v1 = false
local v2 = false
local t2 = {
	PollStarted = Signal.new(),
	PollEnded = Signal.new(),
	TalliesUpdated = Signal.new(),
	Ready = Signal.new(),
	GetActive = function(p1) --[[ GetActive | Line: 45 | Upvalues: t (ref) ]]
		return t
	end,
	GetResults = function(p1, p2) --[[ GetResults | Line: 49 | Upvalues: t (ref) ]]
		return t[p2]
	end,
	IsActive = function(p1, p2) --[[ IsActive | Line: 53 | Upvalues: t (ref) ]]
		return t[p2] ~= nil
	end,
	GetActiveIds = function(p1) --[[ GetActiveIds | Line: 57 | Upvalues: t (ref) ]]
		local t2 = {}
		for v1 in t do
			table.insert(t2, v1)
		end
		table.sort(t2)
		return t2
	end
}
function t2.GetActiveAsync(p1) --[[ GetActiveAsync | Line: 68 | Upvalues: v2 (ref), t2 (copy) ]]
	if v2 then
		return t2:GetActive()
	end
	t2.Ready:Wait()
	return t2:GetActive()
end
function t2.GetResultsAsync(p1, p2) --[[ GetResultsAsync | Line: 73 | Upvalues: v2 (ref), t2 (copy) ]]
	if v2 then
		return t2:GetResults(p2)
	end
	t2.Ready:Wait()
	return t2:GetResults(p2)
end
function t2.IsActiveAsync(p1, p2) --[[ IsActiveAsync | Line: 78 | Upvalues: v2 (ref), t2 (copy) ]]
	if v2 then
		return t2:IsActive(p2)
	end
	t2.Ready:Wait()
	return t2:IsActive(p2)
end
function t2.GetActiveIdsAsync(p1) --[[ GetActiveIdsAsync | Line: 83 | Upvalues: v2 (ref), t2 (copy) ]]
	if v2 then
		return t2:GetActiveIds()
	end
	t2.Ready:Wait()
	return t2:GetActiveIds()
end
function t2.Init(p1) --[[ Init | Line: 90 | Upvalues: v1 (ref), Remotes (copy), RunService (copy), t (ref), t2 (copy), v2 (ref) ]]
	if v1 then
		return
	end
	v1 = true
	Remotes:Init()
	if not RunService:IsServer() then
		Remotes:OnClient("SparkMod.Polls.Started", function(p1) --[[ Line: 101 | Upvalues: t (ref), t2 (ref) ]]
			t[p1.pollId] = p1
			t2.PollStarted:Fire(p1)
		end)
		Remotes:OnClient("SparkMod.Polls.Ended", function(p1, p2) --[[ Line: 106 | Upvalues: t (ref), t2 (ref) ]]
			t[p1] = nil
			t2.PollEnded:Fire(p1, p2)
		end)
		Remotes:OnClient("SparkMod.Polls.Tallies", function(p1, p2, p3, p4) --[[ Line: 111 | Upvalues: t (ref), t2 (ref) ]]
			local v1 = t[p1]
			if v1 then
				v1.tallies = p2
				v1.totalResponses = p3
				v1.playerCount = if p4 then p4 else v1.playerCount
			end
			t2.TalliesUpdated:Fire(p1, p2, p3, p4 or 0)
		end)
		Remotes:OnClient("SparkMod.Polls.Sync", function(p1) --[[ Line: 121 | Upvalues: t (ref), v2 (ref), t2 (ref) ]]
			t = if p1 then p1 else {}
			if v2 then
				return
			end
			v2 = true
			t2.Ready:Fire()
		end)
		task.spawn(function() --[[ Line: 127 | Upvalues: Remotes (ref), t (ref), v2 (ref), t2 (ref) ]]
			local v1 = Remotes:InvokeServer("SparkMod.Polls.GetState")
			if v1 and typeof(v1) == "table" then
				t = v1
			end
			if v2 then
				return
			end
			v2 = true
			t2.Ready:Fire()
		end)
	end
end
return t2