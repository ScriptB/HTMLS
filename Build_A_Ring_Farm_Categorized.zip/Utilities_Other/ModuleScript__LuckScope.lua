-- Path: ReplicatedStorage.CmdrClient.Types.LuckScope
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ Line: 1 ]]
	p1:RegisterType("luckScope", p1.Cmdr.Util.MakeEnumType("LuckScope", { "global", "local" }))
end