-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader
-- Class: LocalScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
require(ReplicatedStorage.Shared.ProfileTypes)
local Promise = require(ReplicatedStorage.Shared.Promise)
local Trove = require(ReplicatedStorage.Packages.Trove)
require(ReplicatedStorage.Shared.EnginePromptGuard)
local DataAggregation = require(script.Modules.DataAggregation)
local LocalPlayer = Players.LocalPlayer
local t = {}
local t2 = {}
local t3 = {}
local t4 = {}
local function PromiseChild(p1, p2) --[[ PromiseChild | Line: 27 | Upvalues: Promise (copy) ]]
	local v1 = p1:FindFirstChild(p2)
	if v1 then
		return Promise.resolve(v1)
	else
		return Promise.fromEvent(p1.ChildAdded, function(p1_2_2) --[[ Line: 32 | Upvalues: p2 (copy) ]]
			return p1_2_2.Name == p2
		end)
	end
end
local function SetupCharacterLifecycle(p1) --[[ SetupCharacterLifecycle | Line: 37 | Upvalues: Promise (copy), PromiseChild (copy), LocalPlayer (copy), Trove (copy) ]]
	local function OnCharacterAdded(p12_2) --[[ OnCharacterAdded | Line: 38 | Upvalues: Promise (ref), PromiseChild (ref), LocalPlayer (ref), Trove (ref), p1 (copy) ]]
		local t2 = {}
		local t2_2 = {}
		local HumanoidRootPart = p12_2:FindFirstChild("HumanoidRootPart")
		local v1
		if HumanoidRootPart then
			v1 = Promise.resolve(HumanoidRootPart)
		else
			local v3 = "HumanoidRootPart"
			v1 = Promise.fromEvent(p12_2.ChildAdded, function(p1_2_2) --[[ Line: 32 | Upvalues: v3 (copy) ]]
				return p1_2_2.Name == v3
			end)
		end
		t2_2[1] = v1
		t2_2[2] = PromiseChild(p12_2, "Humanoid")
		t2[1] = Promise.all(t2_2)
		t2[2] = Promise.fromEvent(LocalPlayer.CharacterRemoving, function(p1_2) --[[ Line: 44 | Upvalues: p12_2 (copy) ]]
			return p1_2 == p12_2
		end):andThenReturn(Promise.reject())
		Promise.race(t2):andThen(function() --[[ Line: 47 | Upvalues: p12_2 (copy), Trove (ref), p1 (ref), LocalPlayer (ref) ]]
			if p12_2.Parent == nil then
				return
			end
			local Humanoid = p12_2:FindFirstChild("Humanoid")
			if not (Humanoid and Humanoid:IsA("Humanoid")) then
				return
			end
			local v1 = Trove.new()
			if p1.onDied then
				v1:Connect(Humanoid.Died, p1.onDied)
			end
			v1:Add(LocalPlayer.CharacterRemoving:Once(function() --[[ Line: 63 | Upvalues: v1 (copy) ]]
				v1:Destroy()
			end))
			if not p1.onCharacterAdded then
				return
			end
			p1.onCharacterAdded(p12_2, v1)
		end)
	end
	local Character = LocalPlayer.Character
	if Character then
		task.spawn(OnCharacterAdded, Character)
	end
	LocalPlayer.CharacterAdded:Connect(OnCharacterAdded)
end
local function LoadHandlerModule(p1) --[[ LoadHandlerModule | Line: 81 | Upvalues: t3 (copy), DataAggregation (copy), t4 (copy), Promise (copy), PromiseChild (copy), LocalPlayer (copy), Trove (copy) ]]
	if type(p1) ~= "table" then
		return
	end
	table.insert(t3, p1)
	if p1.onProfileAdded then
		local v2 = DataAggregation.GetReplica()
		if v2 then
			t4[p1] = true
			task.spawn(p1.onProfileAdded, v2.Data)
		end
	end
	if p1.init then
		task.spawn(xpcall, p1.init, warn)
	end
	if not (p1.onCharacterAdded or p1.onDied) then
		return
	end
	local function OnCharacterAdded(p12_2) --[[ OnCharacterAdded | Line: 38 | Upvalues: Promise (ref), PromiseChild (ref), LocalPlayer (ref), Trove (ref), p1 (copy) ]]
		local t2 = {}
		local t2_2 = {}
		local HumanoidRootPart = p12_2:FindFirstChild("HumanoidRootPart")
		local v1
		if HumanoidRootPart then
			v1 = Promise.resolve(HumanoidRootPart)
		else
			local v3 = "HumanoidRootPart"
			v1 = Promise.fromEvent(p12_2.ChildAdded, function(p1_2_2) --[[ Line: 32 | Upvalues: v3 (copy) ]]
				return p1_2_2.Name == v3
			end)
		end
		t2_2[1] = v1
		t2_2[2] = PromiseChild(p12_2, "Humanoid")
		t2[1] = Promise.all(t2_2)
		t2[2] = Promise.fromEvent(LocalPlayer.CharacterRemoving, function(p1_2) --[[ Line: 44 | Upvalues: p12_2 (copy) ]]
			return p1_2 == p12_2
		end):andThenReturn(Promise.reject())
		Promise.race(t2):andThen(function() --[[ Line: 47 | Upvalues: p12_2 (copy), Trove (ref), p1 (ref), LocalPlayer (ref) ]]
			if p12_2.Parent == nil then
				return
			end
			local Humanoid = p12_2:FindFirstChild("Humanoid")
			if not (Humanoid and Humanoid:IsA("Humanoid")) then
				return
			end
			local v1 = Trove.new()
			if p1.onDied then
				v1:Connect(Humanoid.Died, p1.onDied)
			end
			v1:Add(LocalPlayer.CharacterRemoving:Once(function() --[[ Line: 63 | Upvalues: v1 (copy) ]]
				v1:Destroy()
			end))
			if not p1.onCharacterAdded then
				return
			end
			p1.onCharacterAdded(p12_2, v1)
		end)
	end
	local Character = LocalPlayer.Character
	if Character then
		task.spawn(OnCharacterAdded, Character)
	end
	LocalPlayer.CharacterAdded:Connect(OnCharacterAdded)
end
local function LogError(p1, p2) --[[ LogError | Line: 106 | Upvalues: t2 (copy) ]]
	t2[p1] = p2
end
local function RequireModule(p1) --[[ RequireModule | Line: 110 | Upvalues: Promise (copy), t2 (copy) ]]
	return Promise.new(function(p12_2, p2_2) --[[ Line: 111 | Upvalues: p1 (copy), t2 (ref) ]]
		local v1, v2_2 = pcall(require, p1)
		if v1 then
			p12_2(v2_2)
		else
			t2[p1] = v2_2
			p2_2(v2_2)
		end
	end)
end
local function LoadClientHandlers() --[[ LoadClientHandlers | Line: 122 | Upvalues: t (copy), Promise (copy), t2 (copy), LoadHandlerModule (copy), RequireModule (copy) ]]
	for v1, v2 in script.Handlers:GetChildren() do
		if not v2:FindFirstChild("DISABLED") and v2:IsA("ModuleScript") then
			local v4 = Promise.new(function(p12_2, p2_2) --[[ Line: 111 | Upvalues: v2 (copy), t2 (ref) ]]
				local v1, v2_2 = pcall(require, v2)
				if v1 then
					p12_2(v2_2)
				else
					t2[v2] = v2_2
					p2_2(v2_2)
				end
			end)
			table.insert(t, v4:andThen(LoadHandlerModule))
		end
	end
	for v6, v7 in script.Modules:GetChildren() do
		if not v7:FindFirstChild("DISABLED") and v7:IsA("ModuleScript") then
			table.insert(t, RequireModule(v7))
		end
	end
end
local v1 = os.clock()
LoadClientHandlers()
Promise.all(t):andThen(function() --[[ Line: 149 | Upvalues: v1 (copy) ]]
	print((("Client successfully loaded in %*s"):format(os.clock() - v1)))
end):catch(function() --[[ Line: 152 | Upvalues: t2 (copy), v1 (copy) ]]
	local v12 = ""
	for v2, v3 in t2 do
		v12 = v12 .. ("[Module=%*] - %* | %*\n"):format(v2:GetFullName(), v3, (debug.traceback()))
	end
	warn((("Client partially loaded in %*s\nErrors:\n%*"):format(os.clock() - v1, v12)))
end)
DataAggregation.PromiseReplica():andThen(function(p1) --[[ Line: 160 | Upvalues: t3 (copy), t4 (copy) ]]
	for v1, v2 in t3 do
		if v2.onProfileAdded and not t4[v2] then
			t4[v2] = true
			task.spawn(v2.onProfileAdded, p1.Data)
		end
	end
end)