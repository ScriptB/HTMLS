-- Path: ReplicatedStorage.Shared.FriendOTronConfig
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	MachinePath = { "FriendOTron" },
	MachineTag = "FriendOTronMachine",
	BlueChamberPart = "BlueGlass",
	PurpleChamberPart = "PurpleGlass",
	SeedAnchorName = "SeedAnchor",
	RollGlassPart = "Glass",
	RollAnchorName = "RollAnchor",
	LeverPath = { "Lever", "Handle" },
	SpinsBillboardPath = { "Main", "Spins" },
	SpinsLabelName = "NumSpins",
	SpinsTextPrefix = "Spins: ",
	SpinsPath = { "FriendOTron", "Spins" },
	PendingSeedKeyPath = { "FriendOTron", "PendingSeedKey" },
	CooldownUntilPath = { "FriendOTron", "CooldownUntil" },
	LeverCooldown = 1.5,
	InsertCooldown = 0.5,
	CooldownDuration = 900,
	CooldownBillboardPath = { "Main", "Cooldown" },
	CooldownTimeLabelName = "TimeRemaining",
	CooldownAlertMessage = "Friend-O-Tron cooling down (%s)",
	RollCycleDuration = 1.4,
	RollCycleStartInterval = 0.05,
	RollCycleEndInterval = 0.3,
	RollHoldDuration = 2,
	RollRevealScale = 1.6,
	SpinsByRarity = {
		Common = 0,
		Uncommon = 0,
		Rare = 1,
		Epic = 2,
		Legendary = 3,
		Secret = 5,
		Prismatic = 6,
		Divine = 8,
		Exotic = 10,
		Transcended = 12
	},
	Plants = {
		{
			Name = "Promise Lily",
			Rarity = "Uncommon",
			BaseIncome = 22,
			Weight = 67.5
		},
		{
			Name = "Twinflame Tulip",
			Rarity = "Epic",
			BaseIncome = 450,
			Weight = 27
		},
		{
			Name = "Amulet Anemone",
			Rarity = "Legendary",
			BaseIncome = 1800,
			Weight = 4
		},
		{
			Name = "Duoheart Daisy",
			Rarity = "Prismatic",
			BaseIncome = 28000,
			Weight = 1
		},
		{
			Name = "Heartvine Bloom",
			Rarity = "Exotic",
			BaseIncome = 150000,
			Weight = 0.4
		},
		{
			Name = "Soulbound Orchid",
			Rarity = "Transcended",
			BaseIncome = 500000,
			Weight = 0.1
		}
	}
}
function t.GetSpinsForRarity(p1) --[[ GetSpinsForRarity | Line: 64 | Upvalues: t (copy) ]]
	if p1 then
		return t.SpinsByRarity[p1] or 0
	else
		return 0
	end
end
function t.FindPlant(p1) --[[ FindPlant | Line: 69 | Upvalues: t (copy) ]]
	for i, v in ipairs(t.Plants) do
		if v.Name == p1 then
			return v
		end
	end
	return nil
end
return t