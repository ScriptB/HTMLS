-- Path: Players.Asuneteric.PlayerGui.MainUI.MoneyCounter.FriendBoostText.FriendsBoost
-- Class: LocalScript

-- https://lua.expert/
local Players = game:GetService("Players")
local StarterGui = game:GetService("StarterGui")
local LocalPlayer = Players.LocalPlayer
local v1 = script.Parent
local function updateBoost() --[[ updateBoost | Line: 7 | Upvalues: Players (copy), LocalPlayer (copy), v1 (copy) ]]
	local sum = 0
	for v12, v2 in Players:GetPlayers() do
		if v2 ~= LocalPlayer and v2:IsFriendsWith(LocalPlayer.UserId) then
			sum = sum + 10
		end
	end
	v1.Text = "Friend Boost: +" .. sum .. "%"
end
Players.PlayerAdded:Connect(function(p1) --[[ Line: 19 | Upvalues: LocalPlayer (copy), updateBoost (copy) ]]
	if not LocalPlayer:IsFriendsWithAsync(p1.UserId) then
		return
	end
	updateBoost()
end)
Players.PlayerRemoving:Connect(function(p1) --[[ Line: 25 | Upvalues: LocalPlayer (copy), updateBoost (copy) ]]
	if not LocalPlayer:IsFriendsWithAsync(p1.UserId) then
		return
	end
	updateBoost()
end)
task.spawn(function() --[[ Line: 31 | Upvalues: StarterGui (copy), updateBoost (copy) ]]
	local v1, v2 = pcall(function() --[[ Line: 32 | Upvalues: StarterGui (ref) ]]
		return StarterGui:GetCore("PlayerFriendedEvent")
	end)
	if v1 and v2 then
		v2.Event:Connect(function() --[[ Line: 37 | Upvalues: updateBoost (ref) ]]
			updateBoost()
		end)
	end
	local v3, v4 = pcall(function() --[[ Line: 42 | Upvalues: StarterGui (ref) ]]
		return StarterGui:GetCore("PlayerUnfriendedEvent")
	end)
	if not (v3 and v4) then
		return
	end
	v4.Event:Connect(function() --[[ Line: 47 | Upvalues: updateBoost (ref) ]]
		updateBoost()
	end)
end)
updateBoost()