-- Path: StarterGui.MainUI.Menus.ShopFrame.ScrollingFrame.ServerLuck1.Background.Frame.Pack.LocalScrip
-- Class: LocalScript

-- https://lua.expert/
local v1 = script.Parent
local v2 = TweenInfo.new(0.5, Enum.EasingStyle.Elastic)
local v3 = game:GetService("TweenService"):Create(v1, v2, {
	Rotation = 30
})
local v4 = game:GetService("TweenService"):Create(v1, v2, {
	Rotation = -30
})
local v5 = game:GetService("TweenService"):Create(v1, v2, {
	Rotation = 0
})
while true do
	task.wait(1)
	v3:Play()
	v3.Completed:Wait()
	v4:Play()
	v4.Completed:Wait()
	v5:Play()
	v5.Completed:Wait()
end