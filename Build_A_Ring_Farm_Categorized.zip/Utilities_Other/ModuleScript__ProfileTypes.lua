-- Path: ReplicatedStorage.Shared.ProfileTypes
-- Class: ModuleScript

-- https://lua.expert/
return {}