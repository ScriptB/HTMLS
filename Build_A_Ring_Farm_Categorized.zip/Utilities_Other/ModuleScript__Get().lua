-- Path: ReplicatedStorage.ClientSource.Client.TemplateController.Components.Get()
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
game:GetService("RunService")
game:GetService("TweenService")
game:GetService("UserInputService")
require(ReplicatedStorage.Packages.Knit)
require(ReplicatedStorage.Packages.Signal)
local t = {}
game.Players.LocalPlayer:GetMouse()
function t.Start() --[[ Start | Line: 25 ]] end
function t.Init() --[[ Init | Line: 29 ]] end
return t