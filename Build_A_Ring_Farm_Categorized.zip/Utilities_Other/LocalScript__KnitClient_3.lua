-- Path: StarterPlayer.StarterPlayerScripts.KnitClient
-- Class: LocalScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ClientSource = ReplicatedStorage:WaitForChild("ClientSource")
local Knit = ReplicatedStorage:WaitForChild("Packages"):WaitForChild("Knit")
local v1 = require(Knit)
for k, v in pairs(ClientSource:GetDescendants()) do
	if v:IsA("ModuleScript") and v.Name:match("Controller$") then
		require(v)
	end
end
v1.Start():andThen(function() --[[ Line: 13 | Upvalues: Knit (copy) ]]
	print("Knit Client initiated.")
	Knit:SetAttribute("KnitClient_Initialized", true)
end):catch(warn)