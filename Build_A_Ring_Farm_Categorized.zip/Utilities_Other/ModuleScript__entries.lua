-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.entries
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ entries | Line: 17 ]]
	local t = {}
	for k, v in pairs(p1) do
		table.insert(t, { k, v })
	end
	return t
end