-- Path: ReplicatedStorage.Shared.VFX.PopUpEffect
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")
game:GetService("Workspace")
local SharedUtils = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SharedUtils"))
local Configuration = require(ReplicatedStorage.Shared.Configuration)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local MainUI = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("MainUI")
local PopUp = script:WaitForChild("PopUp")
local v1 = TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v2 = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v3 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
return {
	SpawnPopUp = function(p1) --[[ SpawnPopUp | Line: 33 | Upvalues: PopUp (copy), Configuration (copy), SharedUtils (copy), MainUI (copy), SFXModule (copy), TweenService (copy), v1 (copy), v2 (copy), v3 (copy), Debris (copy) ]]
		local v12 = PopUp:Clone()
		local Text = v12:FindFirstChild("Text")
		local Image = v12:FindFirstChild("Image")
		local v22 = Text and Text:FindFirstChild("Stroke")
		if not Text then
			warn("PopUp Template missing \'Text\' label")
			v12:Destroy()
			return
		end
		if Configuration.AMOUNT_TO_ABBREVIATE <= p1 then
			Text.Text = SharedUtils.NumberToCashAbbreviated(p1)
		else
			Text.Text = SharedUtils.NumberToCash(p1)
		end
		local v32 = 0.5 + (math.random() * 0.1 * 2 - 0.1)
		local v4 = 0.5 + (math.random() * 0.1 * 2 - 0.1)
		v12.Position = UDim2.fromScale(v32, v4)
		v12.Size = UDim2.fromScale(0, 0)
		v12.Rotation = math.random(-10, 10)
		v12.BackgroundTransparency = 1
		Text.TextTransparency = 1
		Text.TextStrokeTransparency = 1
		if Image then
			Image.ImageTransparency = 1
		end
		if v22 then
			v22.Transparency = 1
		end
		v12.Parent = MainUI
		SFXModule.PlaySFX("Cash")
		local v5 = TweenService:Create(v12, v1, {
			Size = PopUp.Size
		})
		local v6 = TweenService:Create(Text, v2, {
			TextTransparency = 0,
			TextStrokeTransparency = 0
		})
		local v7 = if Image then TweenService:Create(Image, v2, {
	ImageTransparency = 0
}) else Image
		local v8 = if v22 then TweenService:Create(v22, v2, {
	Transparency = 0
}) else v22
		v5:Play()
		v6:Play()
		if v7 then
			v7:Play()
		end
		if v8 then
			v8:Play()
		end
		task.delay(1.0499999999999998, function() --[[ Line: 93 | Upvalues: v12 (copy), TweenService (ref), v3 (ref), Text (copy), Image (copy), v22 (copy), Debris (ref) ]]
			if not v12.Parent then
				return
			end
			local v1 = TweenService:Create(v12, v3, {
				Position = v12.Position - UDim2.fromScale(0, 0.15)
			})
			local v2 = TweenService:Create(Text, v3, {
				TextTransparency = 1,
				TextStrokeTransparency = 1
			})
			local v32 = Image and TweenService:Create(Image, v3, {
				ImageTransparency = 1
			})
			local v4 = v22 and TweenService:Create(v22, v3, {
				Transparency = 1
			})
			v1:Play()
			v2:Play()
			if v32 then
				v32:Play()
			end
			if v4 then
				v4:Play()
			end
			Debris:AddItem(v12, v3.Time + 0.1)
		end)
	end
}