-- Path: ReplicatedStorage.Shared.Contracts.Definitions
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	Novice = require(script.Novice),
	Skilled = require(script.Skilled),
	Expert = require(script.Expert),
	Master = require(script.Master),
	Transcendent = require(script.Transcendent)
}
function t.GetById(p1) --[[ GetById | Line: 11 | Upvalues: t (copy) ]]
	local v1 = string.find(p1, "/")
	if not v1 then
		return nil
	end
	local v2 = string.sub(p1, 1, v1 - 1)
	local v3 = string.sub(p1, v1 + 1)
	local v4 = t[v2]
	if type(v4) == "table" then
		return v4[v3]
	else
		return nil
	end
end
function t.GetRankForId(p1) --[[ GetRankForId | Line: 25 ]]
	local v1 = string.find(p1, "/")
	if v1 then
		return string.sub(p1, 1, v1 - 1)
	else
		return nil
	end
end
return table.freeze(t)