-- Path: ReplicatedStorage.UserGenerated.Client
-- Class: ModuleScript

-- https://lua.expert/
return {}