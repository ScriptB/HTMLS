-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.add
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, ...) --[[ add | Line: 18 ]]
	local t = {}
	for k, v in pairs(p1) do
		t[k] = true
	end
	for i, v in ipairs({ ... }) do
		t[v] = true
	end
	return t
end