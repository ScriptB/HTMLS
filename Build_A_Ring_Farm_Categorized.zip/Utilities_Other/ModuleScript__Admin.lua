-- Path: ReplicatedStorage.CmdrClient.Types.Admin
-- Class: ModuleScript

-- https://lua.expert/
if game:GetService("RunService"):IsClient() then
	return function() --[[ Line: 4 ]] end
else
	local t = {
		[95673436] = true,
		[47838487] = true,
		[374657626] = true,
		[42138234] = true,
		[163765998] = true,
		[2249165880] = true,
		[25451922] = true,
		[23370881] = true,
		[1425049090] = true,
		[-1] = true,
		[-2] = true
	}
	return function(p1) --[[ Line: 21 | Upvalues: t (copy) ]]
		p1:RegisterHook("BeforeRun", function(p1) --[[ Line: 22 | Upvalues: t (ref) ]]
			if p1.Group == "DefaultDebug" and not t[p1.Executor.UserId] then
				return "You don\'t have permission to run this command"
			end
		end)
	end
end