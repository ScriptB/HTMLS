-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Util.func
-- Class: ModuleScript

-- https://lua.expert/
return {
	truthy = function() --[[ truthy | Line: 1 ]]
		return true
	end,
	noop = function() --[[ noop | Line: 3 ]] end,
	returned = function(...) --[[ returned | Line: 5 ]]
		return ...
	end
}