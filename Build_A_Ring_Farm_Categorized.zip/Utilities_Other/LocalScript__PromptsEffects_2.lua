-- Path: StarterPlayer.StarterPlayerScripts.PromptsEffects
-- Class: LocalScript

-- https://lua.expert/
local ProximityPromptService = game:GetService("ProximityPromptService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
require(ReplicatedStorage.Shared.VFX.Haptics)
require(ReplicatedStorage.Shared.VFX.ScreenShake)
local LocalPlayer = Players.LocalPlayer
ProximityPromptService.PromptShown:Connect(function(p1) --[[ Line: 8 | Upvalues: Players (copy) ]]
	local v1 = p1:FindFirstAncestorWhichIsA("BasePart") or p1:FindFirstAncestorWhichIsA("Model")
	if v1.Name == "Hitbox" then
		v1 = p1:FindFirstAncestorWhichIsA("Model")
	end
	if v1:FindFirstChild("CratePosition") then
		v1 = v1:FindFirstChild("Crates")
	end
	local Highlight = Instance.new("Highlight")
	Highlight.DepthMode = Enum.HighlightDepthMode.Occluded
	Highlight.FillTransparency = 0.75
	local OutlineColor = Highlight.OutlineColor
	local function applyColor() --[[ applyColor | Line: 24 | Upvalues: p1 (copy), Highlight (copy), OutlineColor (copy) ]]
		local v1 = p1:GetAttribute("HighlightColor")
		if typeof(v1) == "Color3" then
			Highlight.FillColor = v1
			Highlight.OutlineColor = v1
		else
			Highlight.FillColor = Color3.fromRGB(230, 230, 230)
			Highlight.OutlineColor = OutlineColor
		end
	end
	local v3 = p1:GetAttribute("HighlightColor")
	if typeof(v3) == "Color3" then
		Highlight.FillColor = v3
		Highlight.OutlineColor = v3
	else
		Highlight.FillColor = Color3.fromRGB(230, 230, 230)
		Highlight.OutlineColor = OutlineColor
	end
	Highlight.Adornee = v1
	Highlight.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
	local v4 = p1:GetAttributeChangedSignal("HighlightColor"):Connect(applyColor)
	p1.PromptHidden:Once(function() --[[ Line: 41 | Upvalues: v4 (copy), Highlight (copy) ]]
		v4:Disconnect()
		Highlight:Destroy()
	end)
end)