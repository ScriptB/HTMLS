-- Path: ReplicatedStorage.Shared.Registry.Gear
-- Class: ModuleScript

-- https://lua.expert/
local tbl = {}
local function DefineGear(p1, p2, p3, p4) --[[ DefineGear | Line: 3 | Upvalues: tbl (copy) ]]
	tbl[p1] = {
		Chance = p2,
		MaxStock = p3,
		Cost = p4
	}
end
Color3.fromRGB(22, 22, 22)
tbl["Normal Fertilizer"] = {
	Chance = 70,
	MaxStock = 3,
	Cost = 500000
}
tbl["Strong Fertilizer"] = {
	Chance = 20,
	MaxStock = 2,
	Cost = 50000000
}
tbl["Super Fertilizer"] = {
	Chance = 10,
	MaxStock = 1,
	Cost = 15000000000
}
tbl["Bee Fertilizer"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Acid Spray"] = {
	Chance = 30,
	MaxStock = 3,
	Cost = 1000000
}
tbl["Wet Spray"] = {
	Chance = 25,
	MaxStock = 2,
	Cost = 10000000
}
tbl["Frozen Spray"] = {
	Chance = 20,
	MaxStock = 2,
	Cost = 750000000
}
tbl["Autumn Spray"] = {
	Chance = 15,
	MaxStock = 1,
	Cost = 1000000000
}
tbl["Void Spray"] = {
	Chance = 10,
	MaxStock = 1,
	Cost = 10000000000
}
tbl["Radioactive Spray"] = {
	Chance = 5,
	MaxStock = 1,
	Cost = 100000000000
}
tbl["Rainbow Spray"] = {
	Chance = 1,
	MaxStock = 1,
	Cost = 1000000000000
}
tbl["Trucker Spray"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Tropical Seed Pack"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Corrupted Seed Pack"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Dinosaur Egg"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Plant Rush Boss Box"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Scrappy Fertilizer"] = {
	Chance = 0,
	MaxStock = 0,
	Cost = 0
}
tbl["Cosmic Spray"] = {
	Chance = 0.5,
	MaxStock = 1,
	Cost = 25000000000000
}
tbl["Bubblegum Spray"] = {
	Chance = 0.15,
	MaxStock = 1,
	Cost = 250000000000000
}
tbl["Fire Spray"] = {
	Chance = 0.05,
	MaxStock = 1,
	Cost = 1000000000000000
}
tbl["Prismatic Fertilizer"] = {
	Chance = 0.25,
	MaxStock = 1,
	Cost = 25000000000000
}
tbl["Normal Pet Treat"] = {
	Chance = 50,
	MaxStock = 2,
	Cost = 1000000
}
tbl["Strong Pet Treat"] = {
	Chance = 20,
	MaxStock = 1,
	Cost = 75000000
}
tbl["Super Pet Treat"] = {
	Chance = 10,
	MaxStock = 1,
	Cost = 20000000000
}
local t = {}
for k, v in pairs(tbl) do
	t[k] = v.Chance
end
return { t, tbl }