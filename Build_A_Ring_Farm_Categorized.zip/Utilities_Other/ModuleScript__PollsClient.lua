-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.PollsClient
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Polls = require(ReplicatedStorage.SparkMod.Polls)
local LocalPlayer = Players.LocalPlayer
return {
	init = function() --[[ init | Line: 14 | Upvalues: ReplicatedStorage (copy), LocalPlayer (copy), TweenService (copy), Polls (copy) ]]
		local Polls_2 = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("Polls")
		local Vote = Polls_2:WaitForChild("Vote")
		local Tallies = Polls_2:WaitForChild("Tallies")
		local GetActive = Polls_2:WaitForChild("GetActive")
		local Active = Polls_2:WaitForChild("Active")
		local v1 = nil
		local v2 = nil
		local v3 = false
		local v4 = 0
		local v5 = nil
		local v6 = nil
		local v7 = nil
		local v8 = nil
		local Canvas = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("PollUI"):WaitForChild("Canvas")
		local MainText = Canvas.MainText
		local BarHolder = Canvas.BarHolder
		local GreenFill = BarHolder.Bar.GreenFill
		local RedFill = BarHolder.Bar.RedFill
		local Percentage = GreenFill.Percentage
		local Percentage_2 = RedFill.Percentage
		local GreenVotes = BarHolder.GreenVotes
		local RedVotes = BarHolder.RedVotes
		local Option1Btn = Canvas.OptionBtns.Option1Btn
		local Option2Btn = Canvas.OptionBtns.Option2Btn
		local UIScale = Canvas:FindFirstChildOfClass("UIScale")
		if not UIScale then
			UIScale = Instance.new("UIScale")
			UIScale.Parent = Canvas
		end
		UIScale.Scale = 0
		Canvas.Visible = false
		local function formatVotes(p1) --[[ formatVotes | Line: 61 ]]
			local v2 = tostring((math.floor(p1))):reverse():gsub("(%d%d%d)", "%1,"):reverse()
			if v2:sub(1, 1) == "," then
				v2 = v2:sub(2)
			end
			return v2 .. " Votes"
		end
		local function renderBars(p1, p2) --[[ renderBars | Line: 68 | Upvalues: TweenService (ref), GreenFill (copy), RedFill (copy), Percentage (copy), Percentage_2 (copy), GreenVotes (copy), formatVotes (copy), RedVotes (copy) ]]
			local v1 = p1 + p2
			local v2, v3, v4, v5
			if v1 <= 0 then
				v2 = 0
				v3 = 0.5
				v4 = 0.5
				v5 = 0
			elseif p1 > 0 and p2 > 0 then
				local v6 = math.floor(p1 / v1 * 100 + 0.5)
				v2 = 100 - v6
				local v7 = math.clamp(p1 / v1, 0.05, 0.95)
				v3 = v7
				v4 = 1 - v7
				v5 = v6
			else
				v3 = p1 / v1
				local v8 = math.floor(v3 * 100 + 0.5)
				v2 = 100 - v8
				v4 = p2 / v1
				v5 = v8
			end
			local v9 = TweenInfo.new(0.45, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
			TweenService:Create(GreenFill, v9, {
				Size = UDim2.new(v3, 0, 1, 0)
			}):Play()
			TweenService:Create(RedFill, v9, {
				Size = UDim2.new(v4, 0, 1, 0)
			}):Play()
			Percentage.Text = string.format("%d%%", v5)
			Percentage_2.Text = string.format("%d%%", v2)
			GreenVotes.Text = formatVotes(p1)
			RedVotes.Text = formatVotes(p2)
		end
		local function stopTick() --[[ stopTick | Line: 97 | Upvalues: v7 (ref) ]]
			if not v7 then
				return
			end
			task.cancel(v7)
			v7 = nil
		end
		local function stopTimer() --[[ stopTimer | Line: 104 | Upvalues: v8 (ref) ]]
			if not v8 then
				return
			end
			task.cancel(v8)
			v8 = nil
		end
		local function startTimer(p1, p2) --[[ startTimer | Line: 111 | Upvalues: v8 (ref), MainText (copy) ]]
			if not v8 then
				v8 = task.spawn(function() --[[ Line: 113 | Upvalues: p2 (copy), MainText (ref), p1 (copy) ]]
					while true do
						local v2 = math.max(0, p2 - os.time())
						MainText.Text = string.format("%s (%d:%02d)", p1, math.floor(v2 / 60), v2 % 60)
						if v2 <= 0 then
							break
						end
						task.wait(1)
					end
				end)
				return
			end
			task.cancel(v8)
			v8 = nil
			v8 = task.spawn(function() --[[ Line: 113 | Upvalues: p2 (copy), MainText (ref), p1 (copy) ]]
				while true do
					local v2 = math.max(0, p2 - os.time())
					MainText.Text = string.format("%s (%d:%02d)", p1, math.floor(v2 / 60), v2 % 60)
					if v2 <= 0 then
						break
					end
					task.wait(1)
				end
			end)
		end
		local function startTick() --[[ startTick | Line: 125 | Upvalues: v7 (ref), v1 (ref), v6 (ref), renderBars (copy) ]]
			if not v7 then
				v7 = task.spawn(function() --[[ Line: 127 | Upvalues: v1 (ref), v6 (ref), renderBars (ref) ]]
					while v1 and v6 do
						task.wait(0.25)
						if not (v6 and (v6.prevTallies and v6.prevTime)) then
							continue
						end
						local v12 = v6.lastTime - v6.prevTime
						if v12 <= 0 then
							continue
						end
						local v3 = 1 - (1 - math.min(1, (os.clock() - v6.lastTime) / v12)) ^ 2
						local t2 = { 0, 0 }
						t2[1] = v6.lastTallies[1] + math.max(0, v6.lastTallies[1] - v6.prevTallies[1]) * 0.7 * v3
						t2[2] = v6.lastTallies[2] + math.max(0, v6.lastTallies[2] - v6.prevTallies[2]) * 0.7 * v3
						local playerCount = v6.playerCount
						if playerCount > 0 then
							local v8 = t2[1] + t2[2]
							if playerCount < v8 then
								local v9 = playerCount / v8
								t2[1] = t2[1] * v9
								t2[2] = t2[2] * v9
							end
						end
						v6.displayTallies[1] = math.max(v6.displayTallies[1], (math.floor(t2[1])))
						v6.displayTallies[2] = math.max(v6.displayTallies[2], (math.floor(t2[2])))
						renderBars(v6.displayTallies[1], v6.displayTallies[2])
					end
				end)
			end
		end
		local function onTallyUpdate(p1, p2) --[[ onTallyUpdate | Line: 164 | Upvalues: v6 (ref), v7 (ref), v1 (ref), renderBars (copy) ]]
			local v12 = os.clock()
			local v2 = p1[1] or 0
			local v3 = p1[2] or 0
			if v6 then
				v6.prevTallies = v6.lastTallies
				v6.prevTime = v6.lastTime
				v6.lastTallies = { v2, v3 }
				v6.lastTime = v12
				v6.playerCount = p2
				v6.displayTallies[1] = math.max(v6.displayTallies[1], v2)
				v6.displayTallies[2] = math.max(v6.displayTallies[2], v3)
			else
				v6 = {
					prevTallies = nil,
					prevTime = nil,
					lastTallies = { v2, v3 },
					lastTime = v12,
					playerCount = p2,
					displayTallies = { v2, v3 }
				}
				if v7 then
					renderBars(v6.displayTallies[1], v6.displayTallies[2])
					return
				end
				v7 = task.spawn(function() --[[ Line: 127 | Upvalues: v1 (ref), v6 (ref), renderBars (ref) ]]
					while v1 and v6 do
						task.wait(0.25)
						if not (v6 and (v6.prevTallies and v6.prevTime)) then
							continue
						end
						local v12 = v6.lastTime - v6.prevTime
						if v12 <= 0 then
							continue
						end
						local v3 = 1 - (1 - math.min(1, (os.clock() - v6.lastTime) / v12)) ^ 2
						local t2 = { 0, 0 }
						t2[1] = v6.lastTallies[1] + math.max(0, v6.lastTallies[1] - v6.prevTallies[1]) * 0.7 * v3
						t2[2] = v6.lastTallies[2] + math.max(0, v6.lastTallies[2] - v6.prevTallies[2]) * 0.7 * v3
						local playerCount = v6.playerCount
						if playerCount > 0 then
							local v8 = t2[1] + t2[2]
							if playerCount < v8 then
								local v9 = playerCount / v8
								t2[1] = t2[1] * v9
								t2[2] = t2[2] * v9
							end
						end
						v6.displayTallies[1] = math.max(v6.displayTallies[1], (math.floor(t2[1])))
						v6.displayTallies[2] = math.max(v6.displayTallies[2], (math.floor(t2[2])))
						renderBars(v6.displayTallies[1], v6.displayTallies[2])
					end
				end)
			end
			renderBars(v6.displayTallies[1], v6.displayTallies[2])
		end
		local function applyVotedLook(p1) --[[ applyVotedLook | Line: 192 | Upvalues: Option1Btn (copy), Option2Btn (copy), TweenService (ref) ]]
			local v1 = TweenInfo.new(0.1)
			local UIScale = Option1Btn.UIScale
			local UIScale_2 = Option2Btn.UIScale
			if p1 == 1 then
				TweenService:Create(UIScale, v1, {
					Scale = 1
				}):Play()
				TweenService:Create(UIScale_2, v1, {
					Scale = 0.92
				}):Play()
				TweenService:Create(Option1Btn, v1, {
					ImageTransparency = 0
				}):Play()
				TweenService:Create(Option2Btn, v1, {
					ImageTransparency = 0.5
				}):Play()
				return
			end
			if p1 == 2 then
				TweenService:Create(UIScale, v1, {
					Scale = 0.92
				}):Play()
				TweenService:Create(UIScale_2, v1, {
					Scale = 1
				}):Play()
				TweenService:Create(Option1Btn, v1, {
					ImageTransparency = 0.5
				}):Play()
				TweenService:Create(Option2Btn, v1, {
					ImageTransparency = 0
				}):Play()
			else
				UIScale.Scale = 1
				UIScale_2.Scale = 1
				Option1Btn.ImageTransparency = 0
				Option2Btn.ImageTransparency = 0
			end
		end
		local function openCanvas() --[[ openCanvas | Line: 213 | Upvalues: v4 (ref), Canvas (copy), UIScale (ref), TweenService (ref) ]]
			v4 = v4 + 1
			Canvas.Visible = true
			UIScale.Scale = 0
			TweenService:Create(UIScale, TweenInfo.new(0.333, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Scale = 1
			}):Play()
		end
		local function closeCanvas() --[[ closeCanvas | Line: 220 | Upvalues: v4 (ref), TweenService (ref), UIScale (ref), Canvas (copy) ]]
			v4 = v4 + 1
			local v1 = v4
			local v2 = TweenService:Create(UIScale, TweenInfo.new(0.125, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				Scale = 0
			})
			v2:Play()
			v2.Completed:Once(function() --[[ Line: 225 | Upvalues: v4 (ref), v1 (copy), Canvas (ref) ]]
				if v4 ~= v1 then
					return
				end
				Canvas.Visible = false
			end)
		end
		local function showPoll(p1) --[[ showPoll | Line: 232 | Upvalues: v1 (ref), v5 (ref), v2 (ref), v3 (ref), v6 (ref), v7 (ref), Option1Btn (copy), Option2Btn (copy), v8 (ref), MainText (copy), GreenFill (copy), RedFill (copy), onTallyUpdate (copy), openCanvas (copy) ]]
			if #p1.options ~= 2 then
				warn((("[PollsClient] PollUI requires exactly 2 options, got %* \226\128\148 skipping \'%*\'"):format(#p1.options, p1.pollId)))
				return
			end
			v1 = p1.pollId
			v5 = nil
			v2 = nil
			v3 = false
			v6 = nil
			if v7 then
				task.cancel(v7)
				v7 = nil
			end
			Option1Btn.Text.Text = p1.options[1]
			Option2Btn.Text.Text = p1.options[2]
			local question = p1.question
			local v12 = p1.endsAt or 0
			if v8 then
				task.cancel(v8)
				v8 = nil
			end
			v8 = task.spawn(function() --[[ Line: 113 | Upvalues: v12 (copy), MainText (ref), question (copy) ]]
				while true do
					local v2 = math.max(0, v12 - os.time())
					MainText.Text = string.format("%s (%d:%02d)", question, math.floor(v2 / 60), v2 % 60)
					if v2 <= 0 then
						break
					end
					task.wait(1)
				end
			end)
			TweenInfo.new(0.1)
			Option1Btn.UIScale.Scale = 1
			Option2Btn.UIScale.Scale = 1
			Option1Btn.ImageTransparency = 0
			Option2Btn.ImageTransparency = 0
			GreenFill.Size = UDim2.new(0.5, 0, 1, 0)
			RedFill.Size = UDim2.new(0.5, 0, 1, 0)
			onTallyUpdate({ p1.tallies and p1.tallies[1] or 0, p1.tallies and p1.tallies[2] or 0 }, p1.playerCount or 0)
			openCanvas()
		end
		local function hidePoll() --[[ hidePoll | Line: 259 | Upvalues: v1 (ref), v5 (ref), v2 (ref), v3 (ref), v6 (ref), v7 (ref), v8 (ref), closeCanvas (copy) ]]
			v1 = nil
			v5 = nil
			v2 = nil
			v3 = false
			v6 = nil
			if v7 then
				task.cancel(v7)
				v7 = nil
			end
			if not v8 then
				closeCanvas()
				return
			end
			task.cancel(v8)
			v8 = nil
			closeCanvas()
		end
		local function reconcile(p1) --[[ reconcile | Line: 273 | Upvalues: v1 (ref), showPoll (copy), v5 (ref), v2 (ref), v3 (ref), v6 (ref), v7 (ref), v8 (ref), closeCanvas (copy) ]]
			if typeof(p1) ~= "table" then
				return
			end
			local v12 = nil
			for v22, v32 in p1 do
				if v32.status == "active" and #v32.options == 2 then
					v12 = v32
					break
				end
			end
			if v12 then
				if v1 ~= v12.pollId then
					showPoll(v12)
				end
			else
				if not v1 or v1 == v5 then
					return
				end
				v1 = nil
				v5 = nil
				v2 = nil
				v3 = false
				v6 = nil
				if v7 then
					task.cancel(v7)
					v7 = nil
				end
				if v8 then
					task.cancel(v8)
					v8 = nil
				end
				closeCanvas()
			end
		end
		local function tryVote(p1) --[[ tryVote | Line: 295 | Upvalues: v1 (ref), v2 (ref), v3 (ref), Vote (copy), applyVotedLook (copy) ]]
			if v1 and not (v2 or v3) then
				v3 = true
				local v12 = v1
				task.spawn(function() --[[ Line: 300 | Upvalues: Vote (ref), v12 (copy), p1 (copy), v3 (ref), v1 (ref), v2 (ref), applyVotedLook (ref) ]]
					local v13, v22_2 = pcall(function() --[[ Line: 301 | Upvalues: Vote (ref), v12 (ref), p1 (ref) ]]
						return Vote:InvokeServer(v12, p1)
					end)
					v3 = false
					if v1 ~= v12 then
						return
					end
					if not v13 then
						warn((("[PollsClient] Vote remote failed: %*"):format((tostring(v22_2)))))
						return
					end
					if typeof(v22_2) == "table" and v22_2.ok then
						v2 = p1
						applyVotedLook(p1)
						return
					end
					warn((("[PollsClient] Vote failed: %*"):format(typeof(v22_2) == "table" and tostring(v22_2.error) or "invalid response")))
				end)
			end
		end
		local function wireButton(p1, p2) --[[ wireButton | Line: 319 | Upvalues: v2 (ref), v3 (ref), TweenService (ref), v1 (ref), Vote (copy), applyVotedLook (copy) ]]
			local UIScale = p1.UIScale
			local v12 = TweenInfo.new(0.1)
			p1.MouseEnter:Connect(function() --[[ Line: 322 | Upvalues: v2 (ref), v3 (ref), TweenService (ref), UIScale (copy), v12 (copy) ]]
				if not (v2 or v3) then
					TweenService:Create(UIScale, v12, {
						Scale = 1.1
					}):Play()
				end
			end)
			p1.MouseLeave:Connect(function() --[[ Line: 326 | Upvalues: v2 (ref), v3 (ref), TweenService (ref), UIScale (copy), v12 (copy) ]]
				if not (v2 or v3) then
					TweenService:Create(UIScale, v12, {
						Scale = 1
					}):Play()
				end
			end)
			p1.MouseButton1Down:Connect(function() --[[ Line: 330 | Upvalues: v2 (ref), v3 (ref), TweenService (ref), UIScale (copy), v12 (copy) ]]
				if not (v2 or v3) then
					TweenService:Create(UIScale, v12, {
						Scale = 0.95
					}):Play()
				end
			end)
			p1.MouseButton1Up:Connect(function() --[[ Line: 334 | Upvalues: v2 (ref), v3 (ref), TweenService (ref), UIScale (copy), v12 (copy) ]]
				if not (v2 or v3) then
					TweenService:Create(UIScale, v12, {
						Scale = 1.1
					}):Play()
				end
			end)
			p1.MouseButton1Click:Connect(function() --[[ Line: 338 | Upvalues: p2 (copy), v1 (ref), v2 (ref), v3 (ref), Vote (ref), applyVotedLook (ref) ]]
				local v12 = p2
				if not v1 or v2 then
					return
				end
				if v3 then
					return
				end
				v3 = true
				local v22 = v1
				task.spawn(function() --[[ Line: 300 | Upvalues: Vote (ref), v22 (copy), v12 (copy), v3 (ref), v1 (ref), v2 (ref), applyVotedLook (ref) ]]
					local v13, v22_2 = pcall(function() --[[ Line: 301 | Upvalues: Vote (ref), v22 (ref), v12 (ref) ]]
						return Vote:InvokeServer(v12, p1)
					end)
					v3 = false
					if v1 ~= v22 then
						return
					end
					if not v13 then
						warn((("[PollsClient] Vote remote failed: %*"):format((tostring(v22_2)))))
						return
					end
					if typeof(v22_2) == "table" and v22_2.ok then
						v2 = v12
						applyVotedLook(v12)
						return
					end
					warn((("[PollsClient] Vote failed: %*"):format(typeof(v22_2) == "table" and tostring(v22_2.error) or "invalid response")))
				end)
			end)
		end
		wireButton(Option1Btn, 1)
		wireButton(Option2Btn, 2)
		Polls.PollEnded:Connect(function(p1, p2) --[[ Line: 347 | Upvalues: v1 (ref), v5 (ref), v7 (ref), v6 (ref), renderBars (copy), v2 (ref), v3 (ref), v8 (ref), closeCanvas (copy) ]]
			if p1 ~= v1 then
				return
			end
			v5 = p1
			if v7 then
				task.cancel(v7)
				v7 = nil
			end
			v6 = nil
			renderBars(p2 and p2.tallies and p2.tallies[1] or 0, p2 and p2.tallies and p2.tallies[2] or 0)
			task.delay(2, function() --[[ Line: 355 | Upvalues: v1 (ref), p1 (copy), v5 (ref), v2 (ref), v3 (ref), v6 (ref), v7 (ref), v8 (ref), closeCanvas (ref) ]]
				if v1 == p1 then
					v1 = nil
					v5 = nil
					v2 = nil
					v3 = false
					v6 = nil
					if v7 then
						task.cancel(v7)
						v7 = nil
					end
					if v8 then
						task.cancel(v8)
						v8 = nil
					end
					closeCanvas()
				end
				if v5 ~= p1 then
					return
				end
				v5 = nil
			end)
		end)
		Tallies.OnClientEvent:Connect(function(p1, p2, p3) --[[ Line: 361 | Upvalues: v1 (ref), onTallyUpdate (copy) ]]
			if p1 == v1 then
				onTallyUpdate(p2, p3 or 0)
			end
		end)
		Active.OnClientEvent:Connect(function(p1) --[[ Line: 366 | Upvalues: reconcile (copy) ]]
			reconcile(p1)
		end)
		task.spawn(function() --[[ Line: 371 | Upvalues: GetActive (copy), reconcile (copy) ]]
			local v1, v2 = pcall(function() --[[ Line: 372 | Upvalues: GetActive (ref) ]]
				return GetActive:InvokeServer()
			end)
			if not v1 then
				return
			end
			reconcile(v2)
		end)
	end
}