-- Path: Players.Asuneteric.PlayerGui.MainUI.RightSide.ChangingPacks.TimeSkip5.RobuxPrice.UIStroke._!.kgal
-- Class: LocalScript

-- https://lua.expert/
while true do
	task.wait(1000000000)
end