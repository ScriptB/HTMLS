-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.has
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
return function(p1, p2) --[[ has | Line: 21 ]]
	return p1[p2] ~= nil
end