-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.FXInitializer
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
require(ReplicatedStorage.Shared.VFXModule)
require(ReplicatedStorage.Shared.SFXModule)
require(script.RainbowParts)
return 0