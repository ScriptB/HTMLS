-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.BackgroundSounds.Music
-- Class: ModuleScript

-- https://lua.expert/
local SoundService = game:GetService("SoundService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.Parent.Modules.DataAggregation)
require(script.Parent.Parent.Parent.Modules.ReplicaClient)
local BackgroundMusic = SoundService.BackgroundMusic
local t = {}
local v1 = false
local v2 = 2
for i, v in ipairs(BackgroundMusic.Cycle:GetChildren()) do
	table.insert(t, v)
end
BackgroundMusic.Cycle.ChildAdded:Connect(function(p1) --[[ Line: 19 | Upvalues: t (copy) ]]
	table.insert(t, p1)
end)
local function PlayMusic() --[[ PlayMusic | Line: 24 | Upvalues: v1 (ref), t (copy), v2 (ref) ]]
	v1 = false
	while not v1 do
		local v12 = t[v2]
		v12:Play()
		v12.Ended:Wait()
		v2 = if v2 == #t then 1 else v2 + 1
		task.wait()
	end
end
local function StopMusic() --[[ StopMusic | Line: 35 | Upvalues: v1 (ref), t (copy) ]]
	v1 = true
	for k, v in pairs(t) do
		v:Stop()
	end
end
local function Main() --[[ Main | Line: 44 | Upvalues: v2 (ref), t (copy), PlayMusic (copy), SoundService (copy), v1 (ref), ReplicatedStorage (copy) ]]
	v2 = math.random(1, #t)
	task.spawn(PlayMusic)
	local function PlayEventMusic(p1, p2) --[[ PlayEventMusic | Line: 49 | Upvalues: SoundService (ref), PlayMusic (ref), v1 (ref), t (ref) ]]
		if p1 == false then
			for k, v in pairs(SoundService.EventMusic.EventMusic:GetChildren()) do
				if v.IsPlaying then
					v:Stop()
				end
			end
			task.spawn(PlayMusic)
		else
			for k, v in pairs(SoundService.EventMusic.EventMusic:GetChildren()) do
				if v.IsPlaying then
					v:Stop()
				end
			end
			v1 = true
			for k, v in pairs(t) do
				v:Stop()
			end
			local v12 = SoundService.EventMusic.EventMusic:FindFirstChild(p2)
			if not v12 then
				return
			end
			v12:Play()
		end
	end
	ReplicatedStorage.Remotes.EventMusic.Event:Connect(function(p1, p2) --[[ Line: 75 | Upvalues: PlayEventMusic (copy) ]]
		PlayEventMusic(p1, p2)
	end)
	ReplicatedStorage.Remotes.EventMusic2.OnClientEvent:Connect(function(p1, p2) --[[ Line: 79 | Upvalues: PlayEventMusic (copy) ]]
		PlayEventMusic(p1, p2)
	end)
end
task.spawn(Main)
return {}