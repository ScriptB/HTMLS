-- Path: ReplicatedStorage.ClientSource.Client.DataController
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Knit = require(ReplicatedStorage.Packages.Knit)
require(ReplicatedStorage.Packages.Signal)
local v1 = Knit.CreateController({
	Name = "DataController",
	Data = nil
})
local v2 = nil
local LocalPlayer = game.Players.LocalPlayer
function v1.GetPlayerData(p1) --[[ GetPlayerData | Line: 15 | Upvalues: v1 (copy) ]]
	return v1.Data
end
function v1.WaitUntilProfileLoaded(p1) --[[ WaitUntilProfileLoaded | Line: 19 | Upvalues: v1 (copy) ]]
	repeat
		task.wait()
	until v1.Data
end
function v1.RequestToUpdateData(p1) --[[ RequestToUpdateData | Line: 23 | Upvalues: v2 (ref) ]]
	v2.GetData:Fire()
end
function v1.KnitStart(p1) --[[ KnitStart | Line: 27 | Upvalues: v2 (ref), v1 (copy) ]]
	v2.GetData:Connect(function(p1) --[[ Line: 29 | Upvalues: v1 (ref) ]]
		v1.Data = p1
	end)
	v1:RequestToUpdateData()
	v1:WaitUntilProfileLoaded()
	v2.UpdateSpecificData:Connect(function(p1, p2) --[[ Line: 37 | Upvalues: v1 (ref) ]]
		local Data = v1.Data
		for i = 1, #p1 do
			if Data[p1[i]] or i == #p1 then
				if i ~= #p1 then
					Data = Data[p1[i]]
				end
			else
				local v12 = "profileData"
				for j = 1, i do
					v12 = v12 .. "." .. p1[j]
				end
				error("\'" .. v12 .. "\' table does not exist. ALWAYS PREVENT THIS BY MAKING TABLES INSIDE PROFILETEMPLATE.")
			end
		end
		Data[p1[#p1]] = p2
	end)
end
function v1.KnitInit(p1) --[[ KnitInit | Line: 56 | Upvalues: v2 (ref), Knit (copy) ]]
	v2 = Knit.GetService("ProfileService")
end
return v1