-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.concat
-- Class: ModuleScript

-- https://lua.expert/
local None = require(script.Parent.Parent.None)
return function(...) --[[ concat | Line: 26 | Upvalues: None (copy) ]]
	local t = {}
	for i = 1, select("#", ...) do
		local v1 = select(i, ...)
		if type(v1) == "table" then
			for i2, v in ipairs(v1) do
				if v ~= None then
					table.insert(t, v)
				end
			end
		end
	end
	return t
end