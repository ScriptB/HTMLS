-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.fromArray
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ fromArray | Line: 20 ]]
	local v1 = table.create(#p1)
	for i, v in ipairs(p1) do
		v1[v] = true
	end
	return v1
end