-- Path: Players.Asuneteric.PlayerGui.MainUI.Menus.ShopFrame.ScrollingFrame.CorruptedSeedPack.Background.Frame.Sunburst.LocalScript
-- Class: LocalScript

-- https://lua.expert/
local TweenService = game:GetService("TweenService")
local v1 = script.Parent
local v2 = TweenInfo.new(10, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, 0, false, 0)
local function v3() --[[ spin | Line: 14 | Upvalues: v1 (copy), TweenService (copy), v2 (copy), v3 (copy) ]]
	v1.Rotation = 0
	local v12 = TweenService:Create(v1, v2, {
		Rotation = 360
	})
	v12:Play()
	v12.Completed:Wait()
	v3()
end
v3()