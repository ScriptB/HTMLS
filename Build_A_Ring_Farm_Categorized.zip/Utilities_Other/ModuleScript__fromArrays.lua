-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.fromArrays
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ fromArrays | Line: 20 ]]
	local t = {}
	for i = 1, #p1 do
		t[p1[i]] = p2[i]
	end
	return t
end