-- Path: ReplicatedStorage.UserGenerated.IO.Crypto
-- Class: ModuleScript

-- https://lua.expert/
return {}