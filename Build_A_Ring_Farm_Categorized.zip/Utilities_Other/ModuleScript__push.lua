-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.push
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, ...) --[[ push | Line: 22 ]]
	local t = {}
	for i, v in ipairs(p1) do
		table.insert(t, v)
	end
	for i, v in ipairs({ ... }) do
		table.insert(t, v)
	end
	return t
end