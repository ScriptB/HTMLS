-- Path: ReplicatedStorage.GuiAnimatorPlugin.Modules.JointEditModule
-- Class: ModuleScript

-- https://lua.expert/
local RigModule = require(script.Parent.RigModule)
local JointEditorScreenGui = game:WaitForChild("CoreGui"):FindFirstChild("JointEditorScreenGui") or Instance.new("ScreenGui", game:WaitForChild("CoreGui"))
JointEditorScreenGui.Name = "JointEditorScreenGui"
return {
	ClearEditor = function(p1) --[[ ClearEditor | Line: 6 | Upvalues: JointEditorScreenGui (copy) ]]
		JointEditorScreenGui:ClearAllChildren()
	end,
	MoveJoint = function(p1, p2, p3, p4) --[[ MoveJoint | Line: 11 | Upvalues: JointEditorScreenGui (copy), RigModule (copy) ]]
		p1:ClearEditor()
		local MoveTool = Instance.new("Folder", JointEditorScreenGui)
		MoveTool.Name = "MoveTool"
		local t = {}
		local tbl = {}
		local function ChangeTransform(p1) --[[ ChangeTransform | Line: 18 | Upvalues: p4 (copy) ]]
			p4(p1)
		end
		local function ArrowInput(p1, p22, p3) --[[ ArrowInput | Line: 24 | Upvalues: p2 (copy), p4 (copy) ]]
			if p22.UserInputType ~= Enum.UserInputType.MouseButton1 or not Enum.UserInputState.Begin then
				return
			end
			p2:Activate(false)
			local v1 = p2:GetMouse()
			local v2 = Vector2.new(v1.X, v1.Y)
			local v3 = v1.Move:Connect(function() --[[ Line: 30 | Upvalues: v1 (copy), v2 (ref), p3 (copy), p4 (ref) ]]
				local v12 = Vector2.new(v1.X, v1.Y)
				local v22 = v12 - v2
				v2 = v12
				p4(v22 * p3)
			end)
			local v4 = nil
			v4 = p1.InputEnded:Connect(function(p1) --[[ Line: 37 | Upvalues: v3 (copy), v4 (ref) ]]
				if p1.UserInputType ~= Enum.UserInputType.MouseButton1 then
					return
				end
				v3:Disconnect()
				v4:Disconnect()
			end)
		end
		local function UpdatePos() --[[ UpdatePos | Line: 47 | Upvalues: RigModule (ref), p3 (copy), tbl (copy) ]]
			local _, _2, _3, v1 = RigModule:GetTransformJointPositions(p3)
			for k, v in pairs(tbl) do
				v(v1)
			end
		end
		local function AddArrow(p1, p2) --[[ AddArrow | Line: 53 | Upvalues: MoveTool (copy), t (copy), ArrowInput (copy) ]]
			local Frame = Instance.new("Frame", MoveTool)
			Frame.BackgroundColor3 = p1
			Frame.Size = UDim2.fromOffset(50, 4)
			Frame.Rotation = p2
			local v5 = Vector2.new(math.cos((math.rad(p2))), (math.sin((math.rad(p2)))))
			local v6 = v5 * 50
			Frame.AnchorPoint = Vector2.new(0.5, 0.5)
			Frame.Active = true
			Frame.BorderSizePixel = 0
			table.insert(t, Frame)
			Frame.InputBegan:Connect(function(p1) --[[ Line: 64 | Upvalues: ArrowInput (ref), Frame (copy), v5 (copy) ]]
				ArrowInput(Frame, p1, v5)
			end)
			return Frame, function(p1) --[[ Line: 67 | Upvalues: v6 (copy), Frame (copy) ]]
				local v1 = v6 / 2 + p1
				Frame.Position = UDim2.fromOffset(v1.X, v1.Y)
			end
		end
		local _, v1 = AddArrow(Color3.new(255/255, 0/255, 0/255), 0)
		local _2, v2 = AddArrow(Color3.new(0/255, 0/255, 255/255), 90)
		table.insert(tbl, v1)
		table.insert(tbl, v2)
		local _3, _4, _5, v3 = RigModule:GetTransformJointPositions(p3)
		for k, v in pairs(tbl) do
			v(v3)
		end
		p3.Parent.Changed:Connect(function() --[[ Line: 76 | Upvalues: RigModule (ref), p3 (copy), tbl (copy) ]]
			local _, _2, _3, v1 = RigModule:GetTransformJointPositions(p3)
			for k, v in pairs(tbl) do
				v(v1)
			end
		end)
	end,
	RotateJoint = function(p1, p2, p3, p4, p5) --[[ RotateJoint | Line: 81 | Upvalues: JointEditorScreenGui (copy), RigModule (copy) ]]
		p1:ClearEditor()
		p2:Activate(false)
		local v1 = p2:GetMouse()
		local RotateTool = Instance.new("Folder", JointEditorScreenGui)
		RotateTool.Name = "RotateTool"
		local function GetJointPos() --[[ GetJointPos | Line: 87 | Upvalues: RigModule (ref), p3 (copy) ]]
			local _, _2, _3, v1 = RigModule:GetTransformJointPositions(p3)
			return v1
		end
		local function GetMouseAngle() --[[ GetMouseAngle | Line: 91 | Upvalues: v1 (copy), RigModule (ref), p3 (copy) ]]
			local v12 = Vector2.new(v1.X, v1.Y)
			local _, _2, _3, v2 = RigModule:GetTransformJointPositions(p3)
			local v3 = v12 - v2
			return math.deg((math.atan2(v3.Y, v3.X)))
		end
		local function ChangeTransform(p1) --[[ ChangeTransform | Line: 98 | Upvalues: p4 (copy) ]]
			return p4(p1)
		end
		local function CircleInput(p1, p2) --[[ CircleInput | Line: 101 | Upvalues: v1 (copy), RigModule (ref), p3 (copy), p4 (copy), p5 (copy) ]]
			if p2.UserInputType ~= Enum.UserInputType.MouseButton1 or not Enum.UserInputState.Begin then
				return
			end
			local v12 = Vector2.new(v1.X, v1.Y)
			local _, _2, _3, v2 = RigModule:GetTransformJointPositions(p3)
			local v3 = v12 - v2
			local v6 = 0
			p1.Rotation = math.deg((math.atan2(v3.Y, v3.X)))
			p1.RotatingPart.Rotation = 0
			local v7 = Vector2.new(v1.X, v1.Y)
			local _4, _5, _6, v8 = RigModule:GetTransformJointPositions(p3)
			local v9 = v7 - v8
			local v11 = math.deg((math.atan2(v9.Y, v9.X)))
			local v122 = v1.Move:Connect(function() --[[ Line: 108 | Upvalues: v1 (ref), RigModule (ref), p3 (ref), v11 (ref), v6 (ref), p4 (ref), p1 (copy) ]]
				local v12 = Vector2.new(v1.X, v1.Y)
				local _, _2, _3, v2 = RigModule:GetTransformJointPositions(p3)
				local v3 = v12 - v2
				local v5 = math.deg((math.atan2(v3.Y, v3.X)))
				local v62 = v5 - v11
				v11 = v5
				v6 = v6 + p4(v62)
				p1.RotatingPart.Rotation = v6
			end)
			local v13 = nil
			v13 = p1.InputEnded:Connect(function(p12) --[[ Line: 115 | Upvalues: v122 (copy), v13 (ref), p1 (copy), v11 (ref), p5 (ref) ]]
				if p12.UserInputType ~= Enum.UserInputType.MouseButton1 then
					return
				end
				v122:Disconnect()
				v13:Disconnect()
				p1.Rotation = v11
				p1.RotatingPart.Rotation = 0
				p5()
			end)
		end
		local _, v2 = (function(p1) --[[ AddCircle | Line: 128 | Upvalues: RotateTool (copy), CircleInput (copy) ]]
			local v1 = script.RotatingToolUI:Clone()
			v1.Parent = RotateTool
			v1.Size = UDim2.fromOffset(50, 50)
			v1.Rotation = p1
			v1.InputBegan:Connect(function(p1) --[[ Line: 134 | Upvalues: CircleInput (ref), v1 (copy) ]]
				CircleInput(v1, p1)
			end)
			return v1, function(p1) --[[ Line: 137 | Upvalues: v1 (copy) ]]
				v1.Position = UDim2.fromOffset(p1.X, p1.Y)
			end
		end)(p3.Parent.Rotation)
		local function UpdatePos(p1) --[[ UpdatePos | Line: 143 | Upvalues: RigModule (ref), p3 (copy) ]]
			local _, _2, _3, v1 = RigModule:GetTransformJointPositions(p3)
			p1(v1)
		end
		local _2, _3, _4, v3 = RigModule:GetTransformJointPositions(p3)
		v2(v3)
		p3.Parent.Changed:Connect(function() --[[ Line: 150 | Upvalues: v2 (copy), RigModule (ref), p3 (copy) ]]
			local _, _2, _3, v22 = RigModule:GetTransformJointPositions(p3)
			v2(v22)
		end)
	end
}