-- Path: StarterGui.MainUI.Menus.SettingsFrame.TextBox.Effect.UIGradient.LocalScript
-- Class: LocalScript

-- https://lua.expert/
while wait() do
	local v1 = script.Parent
	v1.Rotation = v1.Rotation + 3
end