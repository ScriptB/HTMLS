-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.equals
-- Class: ModuleScript

-- https://lua.expert/
local v1 = script.Parent.Parent
local Util = require(v1.Util)
require(v1.Types)
local function compare(p1, p2) --[[ compare | Line: 7 ]]
	if type(p1) == "table" and type(p2) == "table" then
		for k, v in pairs(p1) do
			if p2[k] ~= v then
				return false
			end
		end
		for k, v in pairs(p2) do
			if p1[k] ~= v then
				return false
			end
		end
		return true
	else
		return p1 == p2
	end
end
return function(...) --[[ equals | Line: 45 | Upvalues: Util (copy), compare (copy) ]]
	if Util.equalObjects(...) then
		return true
	end
	local v1 = select("#", ...)
	local v2 = select(1, ...)
	for i = 2, v1 do
		if not compare(v2, (select(i, ...))) then
			return false
		end
	end
	return true
end