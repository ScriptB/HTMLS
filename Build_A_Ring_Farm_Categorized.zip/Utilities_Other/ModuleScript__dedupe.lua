-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.dedupe
-- Class: ModuleScript

-- https://lua.expert/
local fromArray = require(script.Parent.Parent.Set.fromArray)
local toArray = require(script.Parent.Parent.Set.toArray)
return function(p1) --[[ dedupe | Line: 4 | Upvalues: toArray (copy), fromArray (copy) ]]
	return toArray(fromArray(p1))
end