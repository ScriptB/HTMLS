-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Modules.DataAggregation
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ReplicaClient = require(script.Parent.ReplicaClient)
local Promise = require(ReplicatedStorage.Shared.Promise)
require(ReplicatedStorage.Shared.ProfileTypes)
local Sift = require(ReplicatedStorage.Packages.Sift)
local Signal = require(ReplicatedStorage.Shared.Signal)
local v1 = Signal.new()
local v2 = Signal.new()
local v3 = nil
local v4 = nil
local function OnDataReplicaCreated(p1) --[[ OnDataReplicaCreated | Line: 19 | Upvalues: v3 (ref), v1 (copy) ]]
	v3 = p1
	v1:Fire()
end
local function OnSessionDataReplicaCreated(p1) --[[ OnSessionDataReplicaCreated | Line: 24 | Upvalues: v4 (ref), v2 (copy) ]]
	v4 = p1
	v2:Fire()
end
ReplicaClient.OnNew("PERSISTENT_DATA_REPLICA", OnDataReplicaCreated)
ReplicaClient.OnNew("SESSION_DATA_REPLICA", OnSessionDataReplicaCreated)
ReplicaClient.RequestData()
local function GetWaypoints(p1) --[[ GetWaypoints | Line: 33 ]]
	if type(p1) == "string" then
		return string.split(p1, ".")
	else
		return p1
	end
end
local function ResolveValue(p1, p2) --[[ ResolveValue | Line: 40 ]]
	local v1 = p1
	for v2, v3 in p2 do
		if type(v1) ~= "table" then
			return nil
		end
		v1 = v1[v3]
	end
	return v1
end
local function PathStartsWith(p1, p2) --[[ PathStartsWith | Line: 51 ]]
	if #p1 < #p2 then
		return false
	end
	for v1, v2 in p2 do
		if tostring(p1[v1]) ~= v2 then
			return false
		end
	end
	return true
end
local t = {
	GetReplica = function() --[[ GetReplica | Line: 65 | Upvalues: v3 (ref) ]]
		return v3
	end,
	WaitForReplica = function() --[[ WaitForReplica | Line: 69 | Upvalues: v3 (ref), v1 (copy) ]]
		local v12 = task.delay(5, function() --[[ Line: 70 ]]
			warn("Infinite yield possible waiting for replica on client.")
		end)
		if v3 then
			task.cancel(v12)
			return v3
		end
		v1:Wait()
		task.cancel(v12)
		return v3
	end,
	PromiseReplica = function() --[[ PromiseReplica | Line: 83 | Upvalues: v3 (ref), Promise (copy), v1 (copy) ]]
		if v3 then
			return Promise.resolve(v3)
		else
			return Promise.fromEvent(v1):andThen(function() --[[ Line: 87 | Upvalues: v3 (ref) ]]
				return v3
			end)
		end
	end,
	GetSessionReplica = function() --[[ GetSessionReplica | Line: 92 | Upvalues: v4 (ref) ]]
		return v4
	end,
	WaitForSessionReplica = function() --[[ WaitForSessionReplica | Line: 96 | Upvalues: v4 (ref), v2 (copy) ]]
		local v1 = task.delay(5, function() --[[ Line: 97 ]]
			warn("Infinite yield possible waiting for session replica on client.")
		end)
		if v4 then
			task.cancel(v1)
			return v4
		end
		v2:Wait()
		task.cancel(v1)
		return v4
	end,
	GetData = function() --[[ GetData | Line: 110 | Upvalues: v3 (ref) ]]
		assert(v3, debug.traceback("[DataAggregation] Data not ready yet"))
		return v3.Data
	end,
	GetKey = function(p1) --[[ GetKey | Line: 115 | Upvalues: v3 (ref) ]]
		assert(v3, debug.traceback("[DataAggregation] Data not ready yet"))
		local v2 = if type(p1) == "string" then string.split(p1, ".") else p1
		local v32 = v3.Data
		for v4, v5 in v2 do
			if type(v32) ~= "table" then
				return nil
			end
			v32 = v32[v5]
		end
		return v32
	end,
	OnKeyChanged = function(p1, p2) --[[ OnKeyChanged | Line: 120 | Upvalues: v3 (ref), Sift (copy) ]]
		local v1 = v3
		assert(v1, debug.traceback("[DataAggregation] Data not ready yet"))
		local v2 = if type(p1) == "string" then string.split(p1, ".") else p1
		local v32 = v3.Data
		local v4 = v32
		for v5, v6 in v2 do
			if type(v32) == "table" then
				v32 = v32[v6]
			else
				v4 = nil
				break
			end
		end
		if type(v4) == "table" then
			v4 = Sift.Dictionary.copyDeep(v4)
		end
		return v3:OnChange(function(p1, p22) --[[ Line: 129 | Upvalues: v2 (copy), v3 (ref), v4 (ref), Sift (ref), p2 (copy) ]]
			local v1 = v2
			local v22
			if #p22 < #v1 then
				v22 = false
			else
				v22 = true
				for v32, v42 in v1 do
					if tostring(p22[v32]) ~= v42 then
						v22 = false
						break
					end
				end
			end
			if not v22 then
				return
			end
			local v6 = v3.Data
			local v7 = v6
			for v8, v9 in v2 do
				if type(v6) == "table" then
					v6 = v6[v9]
				else
					v7 = nil
					break
				end
			end
			if not (if type(v7) == "table" then if type(v4) == "table" then not Sift.Dictionary.equalsDeep(v7, v4) elseif v7 == v4 then false else true elseif v7 == v4 then false else true) then
				return
			end
			v4 = if type(v7) == "table" then Sift.Dictionary.copyDeep(v7) else v7
			p2(v7)
		end)
	end,
	OnKeyAdded = function(p1, p2) --[[ OnKeyAdded | Line: 152 | Upvalues: v3 (ref), Sift (copy) ]]
		local v1 = v3
		assert(v1, debug.traceback("[DataAggregation] Data not ready yet"))
		local v2 = if type(p1) == "string" then string.split(p1, ".") else p1
		local v32 = v3.Data
		local v4 = v32
		for v5, v6 in v2 do
			if type(v32) == "table" then
				v32 = v32[v6]
			else
				v4 = nil
				break
			end
		end
		assert(if type(v4) == "table" then true else false, debug.traceback((("[DataAggregation] Path does not lead to a table. Got %*."):format((type(v4))))))
		local v9 = Sift.Dictionary.copyDeep(v4)
		return v3:OnChange(function(p1, p22) --[[ Line: 163 | Upvalues: v2 (copy), v3 (ref), v9 (ref), p2 (copy), Sift (ref) ]]
			local v1 = v2
			local v22
			if #p22 < #v1 then
				v22 = false
			else
				v22 = true
				for v32, v4 in v1 do
					if tostring(p22[v32]) ~= v4 then
						v22 = false
						break
					end
				end
			end
			if not v22 then
				return
			end
			local v6 = v3.Data
			local v7 = v6
			for v8, v92 in v2 do
				if type(v6) == "table" then
					v6 = v6[v92]
				else
					v7 = nil
					break
				end
			end
			if type(v7) ~= "table" then
				return
			end
			for v10, v11 in v7 do
				if v9[v10] == nil then
					p2(v10, v11, v7)
				end
			end
			v9 = Sift.Dictionary.copyDeep(v7)
		end)
	end,
	OnKeyRemoved = function(p1, p2) --[[ OnKeyRemoved | Line: 181 | Upvalues: v3 (ref), Sift (copy) ]]
		local v1 = v3
		assert(v1, "[DataAggregation] Data not ready yet")
		local v2 = if type(p1) == "string" then string.split(p1, ".") else p1
		local v32 = v3.Data
		local v4 = v32
		for v5, v6 in v2 do
			if type(v32) == "table" then
				v32 = v32[v6]
			else
				v4 = nil
				break
			end
		end
		assert(if type(v4) == "table" then true else false, (("[DataAggregation] Path does not lead to a table. Got %*."):format((type(v4)))))
		local v9 = Sift.Dictionary.copyDeep(v4)
		return v3:OnChange(function(p1, p22) --[[ Line: 192 | Upvalues: v2 (copy), v3 (ref), v9 (ref), p2 (copy), Sift (ref) ]]
			local v1 = v2
			local v22
			if #p22 < #v1 then
				v22 = false
			else
				v22 = true
				for v32, v4 in v1 do
					if tostring(p22[v32]) ~= v4 then
						v22 = false
						break
					end
				end
			end
			if not v22 then
				return
			end
			local v6 = v3.Data
			local v7 = v6
			for v8, v92 in v2 do
				if type(v6) == "table" then
					v6 = v6[v92]
				else
					v7 = nil
					break
				end
			end
			if type(v7) ~= "table" then
				return
			end
			for v10, v11 in v9 do
				if v7[v10] == nil then
					p2(v10, v11, v7)
				end
			end
			v9 = Sift.Dictionary.copyDeep(v7)
		end)
	end
}
function t.ObserveKey(p1, p2) --[[ ObserveKey | Line: 210 | Upvalues: v3 (ref), t (copy), v1 (copy) ]]
	if not v3 then
		local v12 = nil
		local v2 = false
		task.spawn(function() --[[ Line: 219 | Upvalues: v3 (ref), v1 (ref), v2 (ref), p2 (copy), p1 (copy), v12 (ref), t (ref) ]]
			if not v3 then
				v1:Wait()
			end
			if v2 then
				return
			end
			local Data = assert(v3).Data
			local v4 = p1
			local v7 = Data
			local v8 = v7
			for v9, v10 in if type(v4) == "string" then string.split(v4, ".") else v4 do
				if type(v7) == "table" then
					v7 = v7[v10]
				else
					v8 = nil
					break
				end
			end
			p2(v8)
			v12 = t.OnKeyChanged(p1, p2)
		end)
		return {
			Disconnect = function() --[[ Disconnect | Line: 230 | Upvalues: v2 (ref), v12 (ref) ]]
				v2 = true
				if not v12 then
					return
				end
				v12:Disconnect()
			end
		}
	end
	local v32 = task.spawn
	local v6 = v3.Data
	local v7 = v6
	for v8, v9 in if type(p1) == "string" then string.split(p1, ".") else p1 do
		if type(v6) == "table" then
			v6 = v6[v9]
		else
			v7 = nil
			break
		end
	end
	v32(p2, v7)
	return t.OnKeyChanged(p1, p2)
end
function t.PromiseKey(p1) --[[ PromiseKey | Line: 239 | Upvalues: v3 (ref), Promise (copy), t (copy) ]]
	if not v3 then
		return t.PromiseReplica():andThen(function(p12) --[[ Line: 243 | Upvalues: p1 (copy) ]]
			local v1 = p1
			local v2 = if type(v1) == "string" then string.split(v1, ".") else v1
			local v4 = p12.Data
			for v5, v6 in v2 do
				if type(v4) ~= "table" then
					return nil
				end
				v4 = v4[v6]
			end
			return v4
		end)
	end
	local v1 = if type(p1) == "string" then string.split(p1, ".") else p1
	local v2 = v3.Data
	local v32 = v2
	for v4, v5 in v1 do
		if type(v2) == "table" then
			v2 = v2[v5]
		else
			v32 = nil
			break
		end
	end
	return Promise.resolve(v32)
end
return t