-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Modules.CustomPack.Icon.Attribute
-- Class: ModuleScript

-- https://lua.expert/
local RunService = game:GetService("RunService")
game:GetService("GroupService")
game:GetService("Players")
if RunService:IsStudio() then
	return {}
end
print((("\240\159\141\141 Running TopbarPlus %* by ForeverHD"):format((require(script.Parent.VERSION)))))
return {}