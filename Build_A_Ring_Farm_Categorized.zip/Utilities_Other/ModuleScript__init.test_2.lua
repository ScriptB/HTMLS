-- Path: ReplicatedStorage.Packages._Index.sleitnick_timer@2.0.0.timer.timer.init.test
-- Class: ModuleScript

-- https://lua.expert/
local ServerScriptService = game:GetService("ServerScriptService")
require(ServerScriptService.TestRunner.Test)
return function(p1) --[[ Line: 5 ]]
	local v1 = require(script.Parent)
	p1:Describe("Timer", function() --[[ Line: 8 | Upvalues: p1 (copy), v1 (copy) ]]
		local v12 = nil
		p1:BeforeEach(function() --[[ Line: 11 | Upvalues: v12 (ref), v1 (ref) ]]
			v12 = v1.new(0.1)
			v12.TimeFunction = os.clock
		end)
		p1:AfterEach(function() --[[ Line: 16 | Upvalues: v12 (ref) ]]
			if not v12 then
				return
			end
			v12:Destroy()
			v12 = nil
		end)
		p1:Test("should create a new timer", function() --[[ Line: 23 | Upvalues: p1 (ref), v1 (ref), v12 (ref) ]]
			p1:Expect(v1.is(v12)):ToBe(true)
		end)
		p1:Test("should tick appropriately", function() --[[ Line: 25 | Upvalues: v12 (ref), p1 (ref) ]]
			local v1 = os.clock()
			v12:Start()
			v12.Tick:Wait()
			local v2 = os.clock() - v1
			p1:Expect(v2):ToBeNear(v2, 0.02)
		end)
		p1:Test("should start immediately", function() --[[ Line: 33 | Upvalues: v12 (ref), p1 (ref) ]]
			local v1 = os.clock()
			local v2 = nil
			v12.Tick:Connect(function() --[[ Line: 36 | Upvalues: v2 (ref) ]]
				if v2 then
					return
				end
				v2 = os.clock()
			end)
			v12:StartNow()
			v12.Tick:Wait()
			p1:Expect(v2):ToBeA("number")
			p1:Expect(v2 - v1):ToBeNear(0, 0.02)
		end)
		p1:Test("should stop", function() --[[ Line: 48 | Upvalues: v12 (ref), p1 (ref) ]]
			local v1 = 0
			v12.Tick:Connect(function() --[[ Line: 50 | Upvalues: v1 (ref) ]]
				v1 = v1 + 1
			end)
			v12:StartNow()
			v12:Stop()
			task.wait(1)
			p1:Expect(v1):ToBe(1)
		end)
		p1:Test("should detect if running", function() --[[ Line: 59 | Upvalues: p1 (ref), v12 (ref) ]]
			p1:Expect(v12:IsRunning()):ToBe(false)
			v12:Start()
			p1:Expect(v12:IsRunning()):ToBe(true)
			v12:Stop()
			p1:Expect(v12:IsRunning()):ToBe(false)
			v12:StartNow()
			p1:Expect(v12:IsRunning()):ToBe(true)
			v12:Stop()
			p1:Expect(v12:IsRunning()):ToBe(false)
		end)
	end)
end