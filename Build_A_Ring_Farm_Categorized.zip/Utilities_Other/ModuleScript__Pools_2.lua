-- Path: ReplicatedStorage.SparkMod.Types.Pools
-- Class: ModuleScript

-- https://lua.expert/
require(game.ReplicatedStorage.SparkMod.Internal.Signal)
require(script.Parent.Luck)
return {}