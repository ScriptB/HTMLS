-- Path: ReplicatedStorage.Packages._Index.sleitnick_component@2.4.8.Promise
-- Class: ModuleScript

-- https://lua.expert/
return require(script.Parent.Parent["evaera_promise@4.0.0"].promise)