-- Path: ReplicatedStorage.Shared.Contracts.Definitions.Expert
-- Class: ModuleScript

-- https://lua.expert/
local CreateContract = require(script.Parent.Parent.CreateContract)
return table.freeze({
	submit100BValue = CreateContract.seedValue(100000000000, {
		Description = "Submit plants worth 100B total seed value",
		Category = "Flexible"
	}),
	submit2Void = CreateContract.byMutation("Void", 2, {
		Description = "Submit 2 Void plants AND at least 100B submitted value",
		Category = "Specific",
		MinSubmittedValue = 100000000000
	}),
	submit1Radioactive = CreateContract.byMutation("Radioactive", 1, {
		Description = "Submit 1 Radioactive plant AND at least 100B submitted value",
		Category = "Specific",
		MinSubmittedValue = 100000000000
	}),
	submit1ExoticPlus = CreateContract.byRarity("Exotic", 1, {
		Description = "Submit 1 Exotic+ plant AND at least 100B submitted value",
		Category = "Flexible",
		MinSubmittedValue = 100000000000
	})
})