-- Path: ReplicatedStorage.SparkMod.Types.Actions
-- Class: ModuleScript

-- https://lua.expert/
return {}