-- Path: ReplicatedStorage.UserGenerated.Collections
-- Class: ModuleScript

-- https://lua.expert/
return {}