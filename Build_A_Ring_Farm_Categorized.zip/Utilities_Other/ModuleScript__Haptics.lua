-- Path: ReplicatedStorage.Shared.VFX.Haptics
-- Class: ModuleScript

-- https://lua.expert/
local t = {}
local HapticService = game:GetService("HapticService")
function t.TimedRumble(p1, p2, p3, p4) --[[ TimedRumble | Line: 5 | Upvalues: HapticService (copy) ]]
	if p1 ~= nil and (p2 ~= nil and (p3 ~= nil and p4 ~= nil)) then
		spawn(function() --[[ Line: 7 | Upvalues: HapticService (ref), p1 (copy), p2 (copy), p3 (copy), p4 (copy) ]]
			if not HapticService:IsMotorSupported(p1, p2) then
				return
			end
			HapticService:SetMotor(p1, p2, p3)
			task.wait(p4)
			HapticService:SetMotor(p1, p2, 0)
		end)
	end
end
return t