-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.ContractsClient.BoardController
-- Class: ModuleScript

-- https://lua.expert/
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ContractCard = require(script.Parent.ContractCard)
local Observers = require(ReplicatedStorage.Packages.Observers)
local SignalBank = require(script.Parent.Parent.Parent.Binding.SignalBank)
local Trove = require(ReplicatedStorage.Packages.Trove)
local t = { "1", "2", "3" }
local t2 = {
	["1"] = "FeedContractPrompt",
	["2"] = "FeedContractPrompt_2",
	["3"] = "FeedContractPrompt_3"
}
local LocalPlayer = Players.LocalPlayer
local DiscardSeed = ReplicatedStorage.Assets.UI.Prompts:WaitForChild("DiscardSeed")
assert(DiscardSeed:IsA("ProximityPrompt"), "[ContractsClient] DiscardSeed must be a ProximityPrompt")
local t3 = {}
local v2 = false
local v3 = nil
local v4 = nil
local t4 = {}
local function CaptureMasters(p1) --[[ CaptureMasters | Line: 37 | Upvalues: v4 (ref), t4 (copy) ]]
	local PlantContracts = p1:WaitForChild("PlantContracts")
	assert(PlantContracts:IsA("SurfaceGui"), "[ContractsClient] PlantContracts template is not a SurfaceGui")
	v4 = PlantContracts:Clone()
	local Contracts = v4:FindFirstChild("Contracts")
	if not Contracts then
		return
	end
	for v2, v3 in Contracts:GetChildren() do
		if v3:IsA("GuiObject") then
			local v42 = string.match(v3.Name, "^Template_(.+)$")
			if v42 then
				t4[v42] = v3:Clone()
			end
			v3:Destroy()
		end
	end
end
local v5 = nil
local function GetPlotsFolder() --[[ GetPlotsFolder | Line: 62 | Upvalues: v5 (ref) ]]
	if v5 and v5.Parent then
		return v5
	end
	local Map = workspace:FindFirstChild("Map")
	v5 = if Map then Map:FindFirstChild("Plots") else Map
	return v5
end
local function FindPlotModel(p1) --[[ FindPlotModel | Line: 74 | Upvalues: v5 (ref) ]]
	if not (v5 and v5.Parent) then
		local Map = workspace:FindFirstChild("Map")
		v5 = if Map then Map:FindFirstChild("Plots") else Map
	end
	local v2 = v5
	if not v2 then
		return nil
	end
	local v3 = p1
	while v3 and v3.Parent do
		if v3.Parent == v2 and v3:IsA("Model") then
			return v3
		end
		v3 = v3.Parent
	end
	return nil
end
local function SetupFeedPrompt(p1, p2, p3, p4, p5, p6) --[[ SetupFeedPrompt | Line: 89 | Upvalues: t2 (copy), DiscardSeed (copy), LocalPlayer (copy), SignalBank (copy) ]]
	local v1 = t2[p2]
	if not v1 then
		return
	end
	local v2 = false
	local function tryAttach(p1) --[[ tryAttach | Line: 104 | Upvalues: v2 (ref), p6 (copy), v1 (copy), DiscardSeed (ref), p2 (copy), p5 (copy), LocalPlayer (ref), p3 (copy), p4 (copy), SignalBank (ref) ]]
		if v2 or not p6() then
			return
		end
		if p1:IsA("Attachment") and p1.Name == v1 then
			v2 = true
			local v12 = DiscardSeed:Clone()
			v12.ActionText = "Submit"
			v12.ObjectText = ("Contract %*"):format(p2)
			v12.Parent = p1
			p5:Add(v12)
			p5:Connect(v12.Triggered, function(p1) --[[ Line: 119 | Upvalues: LocalPlayer (ref), p3 (ref), p2 (ref), p4 (ref), SignalBank (ref) ]]
				if p1 == LocalPlayer then
					task.spawn(function() --[[ Line: 123 | Upvalues: p3 (ref), p2 (ref), p4 (ref), SignalBank (ref) ]]
						local v1, v2 = pcall(function() --[[ Line: 124 | Upvalues: p3 (ref), p2 (ref) ]]
							return p3.SubmitHeld(p2)
						end)
						if not v1 or type(v2) ~= "table" then
							return
						end
						if v2.Success then
							p4.PlayFeed()
							return
						end
						if v2.Error == "NoMatch" then
							SignalBank.Alert:Fire("Preset", "ERROR", "This plant doesn\'t count toward this contract")
							return
						end
						if v2.Error ~= "NoHeldSeed" then
							return
						end
						SignalBank.Alert:Fire("Preset", "ERROR", "Hold a plant to Submit")
					end)
				end
			end)
		end
	end
	local v3 = p1:FindFirstChild(v1, true)
	if v3 then
		tryAttach(v3)
	end
	if v2 then
		return
	end
	p5:Connect(p1.DescendantAdded, tryAttach)
end
local function BuildBoard(p1, p2, p3) --[[ BuildBoard | Line: 154 | Upvalues: Trove (copy), v4 (ref), v3 (ref), t4 (copy), ContractCard (copy), t (copy), SetupFeedPrompt (copy) ]]
	local v1 = Trove.new()
	local v2 = true
	v1:Add(function() --[[ Line: 157 | Upvalues: v2 (ref) ]]
		v2 = false
	end)
	local v32 = v4:Clone()
	v32.Adornee = p1
	v32.Enabled = true
	v32.ResetOnSpawn = false
	v32.Parent = v3
	v1:Add(v32)
	local Contracts = v32:FindFirstChild("Contracts")
	local t2 = {}
	local t3 = {}
	local function findSlot(p1, p2) --[[ findSlot | Line: 173 ]]
		for v1, v2 in p1 do
			if v2.SlotKey == p2 then
				return v2
			end
		end
		return nil
	end
	local function createCard(p1, p22) --[[ createCard | Line: 182 | Upvalues: v2 (ref), Contracts (copy), t4 (ref), t2 (copy), ContractCard (ref), p2 (copy), p3 (copy) ]]
		if not (v2 and Contracts) then
			return
		end
		local v1 = t4[p22.Rank] or t4.Novice
		if v1 then
			local v22 = v1:Clone()
			v22.LayoutOrder = tonumber(p1) or 0
			v22.Visible = true
			v22.Parent = Contracts
			t2[p1] = ContractCard.new({
				Frame = v22,
				SlotKey = p1,
				Slot = p22,
				Api = p2,
				Effects = p3
			})
		end
	end
	local function applyBoard(p1) --[[ applyBoard | Line: 203 | Upvalues: v2 (ref), t (ref), t3 (copy), t2 (copy), createCard (copy), p2 (copy) ]]
		if not v2 then
			return
		end
		for v1, v22 in t do
			if not t3[v22] then
				local v3 = nil
				for v4, v5 in p1 do
					if v5.SlotKey == v22 then
						v3 = v5
						break
					end
				end
				local v6 = t2[v22]
				if v3 and not v6 then
					createCard(v22, v3)
					continue
				end
				if v3 and v6 then
					if v6.Slot.DefinitionId == v3.DefinitionId then
						v6:Update(v3)
						continue
					end
					t3[v22] = true
					t2[v22] = nil
					v6:Destroy(function() --[[ Line: 223 | Upvalues: t3 (ref), v22 (copy), v2 (ref), p2 (ref), createCard (ref) ]]
						t3[v22] = false
						if not v2 then
							return
						end
						local v1 = v22
						local v23 = nil
						for v3, v4 in p2.GetBoard() do
							if v4.SlotKey == v1 then
								v23 = v4
								break
							end
						end
						if not v23 then
							return
						end
						createCard(v22, v23)
					end)
					continue
				end
				if not v3 and v6 then
					t2[v22] = nil
					v6:Destroy()
				end
			end
		end
	end
	local v42 = p2.ObserveBoard(applyBoard)
	v1:Add(function() --[[ Line: 242 | Upvalues: v42 (copy) ]]
		if not (v42 and v42.Disconnect) then
			return
		end
		v42:Disconnect()
	end)
	for v5, v6 in t do
		SetupFeedPrompt(p1, v6, p2, p3, v1, function() --[[ Line: 249 | Upvalues: v2 (ref) ]]
			return v2
		end)
	end
	return function() --[[ Line: 254 | Upvalues: v1 (copy) ]]
		v1:Destroy()
	end
end
function t3.Start(p1, p2) --[[ Start | Line: 259 | Upvalues: v2 (ref), v3 (ref), LocalPlayer (copy), CaptureMasters (copy), Observers (copy), FindPlotModel (copy), BuildBoard (copy), Trove (copy) ]]
	if not v2 then
		v2 = true
		v3 = LocalPlayer:WaitForChild("PlayerGui")
		CaptureMasters((v3:WaitForChild("PlantContracts")))
		Observers.observeTag("PLANT_CONTRACTS_BOARD_PART", function(p12) --[[ Line: 270 | Upvalues: FindPlotModel (ref), BuildBoard (ref), p1 (copy), p2 (copy), Trove (ref), LocalPlayer (ref) ]]
			if not p12:IsA("BasePart") then
				return nil
			end
			local v1 = FindPlotModel(p12)
			if not v1 then
				return BuildBoard(p12, p1, p2)
			end
			local v2 = Trove.new()
			local v3 = nil
			local function evaluate() --[[ evaluate | Line: 287 | Upvalues: v1 (copy), LocalPlayer (ref), v3 (ref), BuildBoard (ref), p12 (copy), p1 (ref), p2 (ref) ]]
				local isUserId = v1:GetAttribute("OwnerUserId") == LocalPlayer.UserId
				if isUserId and not v3 then
					v3 = BuildBoard(p12, p1, p2)
					return
				end
				if isUserId or not v3 then
					return
				end
				v3()
				v3 = nil
			end
			v2:Connect(v1:GetAttributeChangedSignal("OwnerUserId"), evaluate)
			v2:Add(function() --[[ Line: 298 | Upvalues: v3 (ref) ]]
				if not v3 then
					return
				end
				v3()
				v3 = nil
			end)
			local isUserId = v1:GetAttribute("OwnerUserId") == LocalPlayer.UserId
			if isUserId and not v3 then
				v3 = BuildBoard(p12, p1, p2)
			elseif not isUserId and v3 then
				v3()
				v3 = nil
			end
			return function() --[[ Line: 306 | Upvalues: v2 (copy) ]]
				v2:Destroy()
			end
		end, { workspace })
	end
end
return table.freeze(t3)