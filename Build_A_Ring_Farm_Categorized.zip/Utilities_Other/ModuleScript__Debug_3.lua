-- Path: ReplicatedStorage.CmdrClient.Types.Debug
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	[95673436] = true,
	[47838487] = true,
	[374657626] = true,
	[4354458] = true,
	[42138234] = true,
	[163765998] = true,
	[14277028] = true,
	[2249165880] = true,
	[25451922] = true,
	[23370881] = true,
	[1425049090] = true,
	[-1] = true,
	[-2] = true
}
return function(p1) --[[ Line: 17 | Upvalues: t (copy) ]]
	p1:RegisterHook("BeforeRun", function(p1) --[[ Line: 18 | Upvalues: t (ref) ]]
		if p1.Group == "DefaultAdmin" and not t[p1.Executor.UserId] then
			return "You don\'t have permission to run this command"
		end
	end)
end