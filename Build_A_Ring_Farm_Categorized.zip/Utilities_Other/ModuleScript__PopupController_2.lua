-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.UIController.GeneralControllers.PopupController
-- Class: ModuleScript

-- https://lua.expert/
local t = {}
local ReplicatedStorage = game:GetService("ReplicatedStorage")
game:GetService("TweenService")
game:GetService("SoundService")
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local GuiService = game:GetService("GuiService")
local v1 = nil
local DataAggregation = require(script.Parent.Parent.Parent.Parent.Modules.DataAggregation)
require(script.Parent.Parent.Parent.Parent.Modules.ReplicaClient)
require(script.Parent.Parent.Parent.Parent.Binding.SignalBank)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local Registry = require(ReplicatedStorage.Shared.Registry)
local EnginePromptGuard = require(ReplicatedStorage.Shared.EnginePromptGuard)
require(ReplicatedStorage.Shared.Timer)
require(ReplicatedStorage.Shared.SharedUtils)
local LocalPlayer = Players.LocalPlayer
local v2 = nil
local v3 = nil
function t.Init(p1, p2) --[[ Init | Line: 34 | Upvalues: v1 (ref), v2 (ref), v3 (ref), DataAggregation (copy), MarketplaceService (copy), Registry (copy), EnginePromptGuard (copy), LocalPlayer (copy), GuiService (copy), SFXModule (copy) ]]
	v1 = p2
	v2 = p1
	v3 = DataAggregation.WaitForReplica()
	p1.Menus.HarvesterPack_Popup.Main.Btn.Txt.Text = "\238\128\130" .. MarketplaceService:GetProductInfo(Registry.Products.HarvesterPack.Id, Enum.InfoType.Product).PriceInRobux
	p1.Menus.StarterPack_Popup.Main.Btn.Txt.Text = "\238\128\130" .. MarketplaceService:GetProductInfo(Registry.Products.StarterPack.Id, Enum.InfoType.Product).PriceInRobux
	p1.Menus.HarvesterPack_Popup.Main.Btn.MouseButton1Click:Connect(function() --[[ Line: 85 | Upvalues: EnginePromptGuard (ref), MarketplaceService (ref), LocalPlayer (ref), Registry (ref), v1 (ref) ]]
		EnginePromptGuard.AcquireProductPurchase()
		MarketplaceService:PromptProductPurchase(LocalPlayer, Registry.Products.HarvesterPack.Id)
		v1.CloseGui("HarvesterPack_Popup")
	end)
	p1.Menus.StarterPack_Popup.Main.Btn.MouseButton1Click:Connect(function() --[[ Line: 92 | Upvalues: EnginePromptGuard (ref), MarketplaceService (ref), LocalPlayer (ref), Registry (ref), v1 (ref) ]]
		EnginePromptGuard.AcquireProductPurchase()
		MarketplaceService:PromptProductPurchase(LocalPlayer, Registry.Products.StarterPack.Id)
		v1.CloseGui("StarterPack_Popup")
	end)
	GuiService.MenuOpened:Connect(function() --[[ Line: 99 | Upvalues: v1 (ref), SFXModule (ref) ]]
		v1.OpenGui("ExitFrame")
		SFXModule.PlaySFX("Announcement")
	end)
	GuiService.MenuClosed:Connect(function() --[[ Line: 104 | Upvalues: v1 (ref) ]]
		v1.CloseGui("ExitFrame")
	end)
end
return t