-- Path: ReplicatedStorage.CmdrClient.Commands.promptlimited
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "promptlimited",
	Description = "Triggers the LimitedStock purchase flow (Reserve + PromptProductPurchase) for a given eventId",
	Group = "DefaultAdmin",
	Aliases = { "prompt" },
	Args = {
		{
			Type = "players",
			Name = "players",
			Description = "The players to prompt"
		},
		{
			Type = "string",
			Name = "eventId",
			Description = "LimitedStock eventId (e.g. LimitedPet_Test)"
		}
	}
}