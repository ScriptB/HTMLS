-- Path: StarterGui.MainUI.RightSide.ChangingPacks.TimeSkip30.RobuxPrice.UIStroke._!.kgal
-- Class: LocalScript

-- https://lua.expert/
while true do
	task.wait(1000000000)
end