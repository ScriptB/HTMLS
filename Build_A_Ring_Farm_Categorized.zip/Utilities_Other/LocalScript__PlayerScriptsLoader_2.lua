-- Path: StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader
-- Class: LocalScript

-- https://lua.expert/
require(script.Parent:WaitForChild("PlayerModule"))