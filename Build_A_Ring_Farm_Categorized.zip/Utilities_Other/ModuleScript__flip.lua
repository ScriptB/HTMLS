-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Dictionary.flip
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ flip | Line: 17 ]]
	local t = {}
	for k, v in pairs(p1) do
		t[v] = k
	end
	return t
end