-- Path: Players.Asuneteric.PlayerScripts.ComponentLoader
-- Class: LocalScript

-- https://lua.expert/
local StarterPlayer = game:GetService("StarterPlayer")
if not StarterPlayer.StarterPlayerScripts:FindFirstChild("Components") then
	return
end
for v1, v2 in StarterPlayer.StarterPlayerScripts.Components:GetDescendants() do
	if v2:IsA("ModuleScript") then
		require(v2)
	end
end