-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.filter
-- Class: ModuleScript

-- https://lua.expert/
local Util = require(script.Parent.Parent.Util)
return function(p1, p2) --[[ filter | Line: 24 | Upvalues: Util (copy) ]]
	local t = {}
	if type(p2) ~= "function" then
		p2 = Util.func.truthy
	end
	for k, v in pairs(p1) do
		if p2(k, p1) then
			t[k] = true
		end
	end
	return t
end