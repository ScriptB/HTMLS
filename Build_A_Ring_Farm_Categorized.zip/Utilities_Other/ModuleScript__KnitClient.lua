-- Path: ReplicatedStorage.Packages._Index.superbullet_knit@0.0.1.knit.KnitClient
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	ServicePromises = true,
	Middleware = nil,
	PerServiceMiddleware = {}
}
local v1 = nil
local t2 = {
	Player = game:GetService("Players").LocalPlayer,
	Util = script.Parent.Parent
}
local Promise = require(t2.Util.Promise)
local ClientComm = require(t2.Util.Comm).ClientComm
local KnitErrorHelper = require(script.Parent.KnitErrorHelper)
local t3 = {}
local t4 = {}
local v2 = nil
local v3 = false
local v4 = false
local v5 = Instance.new("BindableEvent")
local function DoesControllerExist(p1) --[[ DoesControllerExist | Line: 133 | Upvalues: t3 (copy) ]]
	return t3[p1] ~= nil
end
local function InitializeComponents(p1, p2) --[[ InitializeComponents | Line: 139 ]]
	local Components = p2:WaitForChild("Components", 1)
	if not Components then
		return
	end
	local Others = Components:WaitForChild("Others", 1)
	if Others then
		p1.Components = {}
		for k, v in pairs(Others:GetChildren()) do
			if v:IsA("ModuleScript") then
				p1.Components[v.Name] = require(v)
			end
		end
	end
	local v1 = Components:WaitForChild("Get()", 1)
	if v1 and v1:IsA("ModuleScript") then
		p1.GetComponent = require(v1)
	end
	local v2 = Components:WaitForChild("Set()", 1)
	if v2 and v2:IsA("ModuleScript") then
		p1.SetComponent = require(v2)
	end
	for k, v in pairs(Components:GetDescendants()) do
		if v:IsA("ModuleScript") then
			local v3, v4 = pcall(require, v)
			if v3 and (typeof(v4) == "table" and not v:GetAttribute("Initialized")) then
				if v4.Init and typeof(v4.Init) == "function" then
					v:SetAttribute("Initialized", true)
					local v5, v6 = pcall(function() --[[ Line: 180 | Upvalues: v4 (copy) ]]
						v4.Init()
					end)
					if not v5 then
						warn((("Error initializing component %*: %*"):format(v:GetFullName(), v6)))
					end
				end
				if v4.Start and (typeof(v4.Start) == "function" and not v:GetAttribute("Started")) then
					v:SetAttribute("Started", true)
					task.spawn(function() --[[ Line: 193 | Upvalues: v4 (copy), v (copy) ]]
						local v1, v2 = pcall(function() --[[ Line: 194 | Upvalues: v4 (ref) ]]
							v4.Start()
						end)
						if v1 then
							return
						end
						warn((("Error starting component %*: %*"):format(v:GetFullName(), v2)))
					end)
				end
			end
		end
	end
end
local function GetServicesFolder() --[[ GetServicesFolder | Line: 209 | Upvalues: v2 (ref) ]]
	if v2 then
		return v2
	end
	v2 = script.Parent:WaitForChild("Services", 30)
	if v2 then
		return v2
	end
	error("\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\n\226\157\140 Knit Error: Services folder not found\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\nThe server has not finished initializing yet.\n\nMost common cause:\n\226\154\160\239\184\143  A KnitInit error occurred on the server\n    Check the server console for KnitInit errors above.\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129")
end
local function GetMiddlewareForService(p1) --[[ GetMiddlewareForService | Line: 230 | Upvalues: v1 (ref) ]]
	local v12 = if v1.Middleware == nil then {} else v1.Middleware
	local v2 = v1.PerServiceMiddleware[p1]
	if v2 == nil then
		return v12
	else
		return v2
	end
end
local function BuildService(p1) --[[ BuildService | Line: 237 | Upvalues: v2 (ref), v1 (ref), ClientComm (copy), t4 (copy) ]]
	if not v2 then
		v2 = script.Parent:WaitForChild("Services", 30)
		if not v2 then
			error("\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\n\226\157\140 Knit Error: Services folder not found\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\nThe server has not finished initializing yet.\n\nMost common cause:\n\226\154\160\239\184\143  A KnitInit error occurred on the server\n    Check the server console for KnitInit errors above.\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129")
		end
	end
	local v22 = if v1.Middleware == nil then {} else v1.Middleware
	local v3 = v1.PerServiceMiddleware[p1]
	local v4 = if v3 == nil then v22 else v3
	local v5 = ClientComm.new(v2, v1.ServicePromises, p1):BuildObject(v4.Inbound, v4.Outbound)
	t4[p1] = v5
	return v5
end
function t2.CreateController(p1) --[[ CreateController | Line: 277 | Upvalues: t3 (copy), v3 (ref) ]]
	assert(type(p1) == "table", (("Controller must be a table; got %*"):format((type(p1)))))
	assert(type(p1.Name) == "string", (("Controller.Name must be a string; got %*"):format((type(p1.Name)))))
	assert(#p1.Name > 0, "Controller.Name must be a non-empty string")
	assert(not (t3[p1.Name] ~= nil), (("Controller %* already exists"):format(p1.Name)))
	assert(not v3, "Controllers cannot be created after calling \"Knit.Start()\"")
	t3[p1.Name] = p1
	return p1
end
function t2.AddControllers(p1) --[[ AddControllers | Line: 298 | Upvalues: v3 (ref) ]]
	assert(not v3, "Controllers cannot be added after calling \"Knit.Start()\"")
	local t = {}
	for v2, v32 in p1:GetChildren() do
		if v32:IsA("ModuleScript") then
			table.insert(t, require(v32))
		end
	end
	return t
end
function t2.AddControllersDeep(p1) --[[ AddControllersDeep | Line: 316 | Upvalues: v3 (ref) ]]
	assert(not v3, "Controllers cannot be added after calling \"Knit.Start()\"")
	local t = {}
	for v2, v32 in p1:GetDescendants() do
		if v32:IsA("ModuleScript") then
			table.insert(t, require(v32))
		end
	end
	return t
end
function t2.GetService(p1) --[[ GetService | Line: 383 | Upvalues: t4 (copy), v3 (ref), KnitErrorHelper (copy), t3 (copy), v2 (ref), v1 (ref), ClientComm (copy) ]]
	local v12 = t4[p1]
	if v12 then
		return v12
	end
	assert(v3, KnitErrorHelper.GetStartErrorMessage(v3, "GetService", t3, true))
	assert(type(p1) == "string", (("ServiceName must be a string; got %*"):format((type(p1)))))
	if not v2 then
		v2 = script.Parent:WaitForChild("Services", 30)
		if not v2 then
			error("\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\n\226\157\140 Knit Error: Services folder not found\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\nThe server has not finished initializing yet.\n\nMost common cause:\n\226\154\160\239\184\143  A KnitInit error occurred on the server\n    Check the server console for KnitInit errors above.\n\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129\226\148\129")
		end
	end
	local v8 = if v1.Middleware == nil then {} else v1.Middleware
	local v9 = v1.PerServiceMiddleware[p1]
	local v10 = if v9 == nil then v8 else v9
	local v11 = ClientComm.new(v2, v1.ServicePromises, p1):BuildObject(v10.Inbound, v10.Outbound)
	t4[p1] = v11
	return v11
end
function t2.GetController(p1) --[[ GetController | Line: 399 | Upvalues: t3 (copy), v3 (ref), KnitErrorHelper (copy) ]]
	local v1 = t3[p1]
	if v1 then
		return v1
	end
	assert(v3, KnitErrorHelper.GetStartErrorMessage(v3, "GetController", t3, true))
	assert(type(p1) == "string", (("ControllerName must be a string; got %*"):format((type(p1)))))
	error(("Could not find controller \"%*\". Check to verify a controller with this name exists."):format(p1), 2)
end
function t2.GetControllers() --[[ GetControllers | Line: 413 | Upvalues: v3 (ref), KnitErrorHelper (copy), t3 (copy) ]]
	assert(v3, KnitErrorHelper.GetStartErrorMessage(v3, "GetControllers", t3, true))
	return t3
end
function t2.Start(p1) --[[ Start | Line: 436 | Upvalues: v3 (ref), Promise (copy), t3 (copy), v1 (ref), t (copy), InitializeComponents (copy), v4 (ref), v5 (copy) ]]
	if v3 then
		return Promise.reject("Knit already started")
	end
	v3 = true
	table.freeze(t3)
	if p1 == nil then
		v1 = t
	else
		local v12 = typeof(p1) == "table"
		assert(v12, (("KnitOptions should be a table or nil; got %*"):format((typeof(p1)))))
		v1 = p1
		for v32, v42 in t do
			if p1[v32] == nil then
				p1[v32] = v42
			end
		end
	end
	if type(v1.PerServiceMiddleware) == "table" then
		return Promise.new(function(p1_2) --[[ Line: 460 | Upvalues: t3 (ref), Promise (ref) ]]
			local t2 = {}
			for v1, v2 in t3 do
				if type(v2.KnitInit) == "function" then
					table.insert(t2, Promise.new(function(p1_2, p2_2) --[[ Line: 468 | Upvalues: v2 (copy) ]]
						debug.setmemorycategory(v2.Name)
						local v1, v22 = pcall(function() --[[ Line: 470 | Upvalues: v2 (ref) ]]
							v2:KnitInit()
						end)
						if v1 then
							p1_2()
							return
						end
						local v3 = debug.info(v2.KnitInit, "s"):match("^@?(.+)$") or v2.Name
						p2_2(string.format("", v2.Name, v3, (tostring(v22))))
					end))
				end
			end
			p1_2(Promise.all(t2))
		end):andThen(function() --[[ Line: 487 | Upvalues: t3 (ref), InitializeComponents (ref), v4 (ref), v5 (ref) ]]
			for v1, v2 in t3 do
				if v2.Instance then
					InitializeComponents(v2, v2.Instance)
					v2.Instance = nil
				end
			end
			for v3, v42 in t3 do
				if type(v42.KnitStart) == "function" then
					task.spawn(function() --[[ Line: 499 | Upvalues: v42 (copy) ]]
						debug.setmemorycategory(v42.Name)
						v42:KnitStart()
					end)
				end
			end
			v4 = true
			v5:Fire()
			task.defer(function() --[[ Line: 509 | Upvalues: v5 (ref) ]]
				v5:Destroy()
			end)
		end)
	end
	v1.PerServiceMiddleware = {}
	return Promise.new(function(p1_2) --[[ Line: 460 | Upvalues: t3 (ref), Promise (ref) ]]
		local t2 = {}
		for v1, v2 in t3 do
			if type(v2.KnitInit) == "function" then
				table.insert(t2, Promise.new(function(p1_2, p2_2) --[[ Line: 468 | Upvalues: v2 (copy) ]]
					debug.setmemorycategory(v2.Name)
					local v1, v22 = pcall(function() --[[ Line: 470 | Upvalues: v2 (ref) ]]
						v2:KnitInit()
					end)
					if v1 then
						p1_2()
						return
					end
					local v3 = debug.info(v2.KnitInit, "s"):match("^@?(.+)$") or v2.Name
					p2_2(string.format("", v2.Name, v3, (tostring(v22))))
				end))
			end
		end
		p1_2(Promise.all(t2))
	end):andThen(function() --[[ Line: 487 | Upvalues: t3 (ref), InitializeComponents (ref), v4 (ref), v5 (ref) ]]
		for v1, v2 in t3 do
			if v2.Instance then
				InitializeComponents(v2, v2.Instance)
				v2.Instance = nil
			end
		end
		for v3, v42 in t3 do
			if type(v42.KnitStart) == "function" then
				task.spawn(function() --[[ Line: 499 | Upvalues: v42 (copy) ]]
					debug.setmemorycategory(v42.Name)
					v42:KnitStart()
				end)
			end
		end
		v4 = true
		v5:Fire()
		task.defer(function() --[[ Line: 509 | Upvalues: v5 (ref) ]]
			v5:Destroy()
		end)
	end)
end
function t2.OnStart() --[[ OnStart | Line: 527 | Upvalues: v4 (ref), Promise (copy), v5 (copy) ]]
	if v4 then
		return Promise.resolve()
	else
		return Promise.fromEvent(v5.Event)
	end
end
return t2