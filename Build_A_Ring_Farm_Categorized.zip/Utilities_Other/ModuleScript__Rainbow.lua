-- Path: ReplicatedStorage.Shared.MutationAppliers.Rainbow
-- Class: ModuleScript

-- https://lua.expert/
return function(p1) --[[ Line: 1 ]]
	for v1, v2 in p1:GetDescendants() do
		if v2:IsA("BasePart") and not (v2.Transparency >= 1) then
			if v2:IsA("UnionOperation") then
				v2.UsePartColor = true
			end
			if v2:IsA("MeshPart") then
				v2.TextureID = ""
			end
			v2:AddTag("RainbowColorShift")
		end
	end
end