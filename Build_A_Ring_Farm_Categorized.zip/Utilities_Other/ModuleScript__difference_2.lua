-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.difference
-- Class: ModuleScript

-- https://lua.expert/
require(script.Parent.Parent.Types)
return function(p1, ...) --[[ difference | Line: 21 ]]
	local v1 = table.clone(p1)
	for v2, v3 in { ... } do
		if typeof(v3) == "table" then
			for v4 in v3 do
				v1[v4] = nil
			end
		end
	end
	return v1
end