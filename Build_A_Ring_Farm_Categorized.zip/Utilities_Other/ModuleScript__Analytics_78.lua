-- Path: ReplicatedStorage.UserGenerated.Analytics
-- Class: ModuleScript

-- https://lua.expert/
return {}