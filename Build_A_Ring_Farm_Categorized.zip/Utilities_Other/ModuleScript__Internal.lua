-- Path: ReplicatedStorage.SparkMod.Internal
-- Class: ModuleScript

-- https://lua.expert/
return {}