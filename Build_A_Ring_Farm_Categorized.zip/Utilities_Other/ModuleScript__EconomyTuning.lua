-- Path: ReplicatedStorage.Shared.EconomyTuning
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ABTests = require(ReplicatedStorage.UserGenerated.ABTests)
local t = {}
local t2 = {
	ExtraPowerGrowth = 1.33,
	FloorConfig = {
		{
			PlotUnlockGrowth = 1.4,
			PlotUnlockBase = { 25, 150, 400 }
		},
		{
			PlotUnlockGrowth = 1.33,
			PlotUnlockBase = { 12000, 24000, 55000 }
		},
		{
			PlotUnlockGrowth = 1.33,
			PlotUnlockBase = { 1200000, 2400000, 5500000 }
		}
	},
	FarmExpandCosts = {
		[2] = 8000,
		[3] = 150000,
		[4] = 25000000,
		[5] = 500000000,
		[6] = 20000000000,
		[7] = 10000000000000,
		[8] = 150000000000000,
		[9] = 5000000000000000
	}
}
function t.Get(p1) --[[ Get | Line: 39 | Upvalues: ABTests (copy), t2 (copy) ]]
	if ABTests.GetAttribute(p1, "NerfedUpperFloorCosts", false) then
		return t2
	else
		return nil
	end
end
t.Changed = ABTests.PlayerUpdated
return t