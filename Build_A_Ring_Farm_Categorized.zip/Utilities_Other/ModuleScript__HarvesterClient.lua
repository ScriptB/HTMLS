-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.HarvesterClient
-- Class: ModuleScript

-- https://lua.expert/
game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HarvestPlant = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("HarvestPlant")
local LowPerformanceMode = ReplicatedStorage:WaitForChild("LowPerformanceMode")
local OrbEffect = require(ReplicatedStorage.Shared.VFX.OrbEffect)
HarvestPlant.OnClientEvent:Connect(function(p1, p2, p3, p4) --[[ Line: 11 | Upvalues: LowPerformanceMode (copy), OrbEffect (copy) ]]
	if LowPerformanceMode.Value == true then
		return
	end
	if typeof(p2) == "table" then
		for i, v in ipairs(p2) do
			OrbEffect.CreateCropEffectToPart(v, p3, p1, p4)
		end
	else
		if typeof(p2) ~= "Vector3" then
			return
		end
		OrbEffect.CreateCropEffectToPart(p2, p3, p1, p4)
	end
end)
return 0