-- Path: ReplicatedStorage.Shared.VFX.HitCount
-- Class: ModuleScript

-- https://lua.expert/
local t = {
	hits = 0
}
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")
local HitCount = Players.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("OnScreen"):WaitForChild("HitCount")
local TextLabel = HitCount:WaitForChild("TextLabel")
local BonusLabel = HitCount:WaitForChild("BonusLabel")
local TextLabel_2 = TextLabel:FindFirstChild("TextLabel")
local TextLabel_3 = BonusLabel:WaitForChild("TextLabel")
local Size = TextLabel.Size
TextLabel.Visible = false
local Size_2 = BonusLabel.Size
BonusLabel.Visible = false
local v1 = nil
local v2 = nil
local function setText(p1) --[[ setText | Line: 32 | Upvalues: TextLabel (copy), TextLabel_2 (copy) ]]
	if TextLabel:IsA("TextLabel") or TextLabel:IsA("TextButton") then
		TextLabel.Text = p1
	end
	if not (TextLabel_2 and (TextLabel_2:IsA("TextLabel") or TextLabel_2:IsA("TextButton"))) then
		return
	end
	TextLabel_2.Text = p1
end
function t.BonusHit() --[[ BonusHit | Line: 44 | Upvalues: BonusLabel (copy), Size (copy), TextLabel_3 (copy), Debris (copy), TweenService (copy), v1 (ref), v2 (ref) ]]
	BonusLabel.Visible = true
	BonusLabel.Size = Size
	BonusLabel.TextTransparency = 0
	local UIStroke = BonusLabel:FindFirstChildOfClass("UIStroke")
	if UIStroke then
		UIStroke.Transparency = 0
	end
	if TextLabel_3 then
		TextLabel_3.TextTransparency = 1
	end
	local AnimStroke = Instance.new("UIStroke")
	AnimStroke.Name = "AnimStroke"
	AnimStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	AnimStroke.Thickness = 10
	AnimStroke.Color = Color3.new(255/255, 255/255, 255/255)
	AnimStroke.BorderOffset = UDim.new(-0.5, 0)
	AnimStroke.ZIndex = 2
	AnimStroke.Parent = BonusLabel
	Debris:AddItem(AnimStroke, 0.5)
	TweenService:Create(AnimStroke, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Transparency = 1,
		BorderOffset = UDim.new(0.2, 0)
	}):Play()
	if v1 and v1.PlaybackState == Enum.PlaybackState.Playing then
		v1:Cancel()
	end
	if v2 and v2.PlaybackState == Enum.PlaybackState.Playing then
		v2:Cancel()
	end
	local t = {
		Size = UDim2.new(Size.X.Scale * 1.2, 0, Size.Y.Scale * 1.2, 0),
		Rotation = math.random(-45, 45)
	}
	v1 = TweenService:Create(BonusLabel, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), t)
	v1:Play()
	local t2 = {
		Rotation = math.random(-15, 15)
	}
	v2 = TweenService:Create(BonusLabel, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), t2)
	v2:Play()
	if not TextLabel_3 then
		task.delay(1, function() --[[ Line: 128 | Upvalues: TweenService (ref), BonusLabel (ref) ]]
			TweenService:Create(BonusLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				TextTransparency = 1
			}):Play()
			local UIStroke = BonusLabel:FindFirstChildOfClass("UIStroke")
			if not UIStroke then
				return
			end
			TweenService:Create(UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				Transparency = 1
			}):Play()
		end)
		return
	end
	TweenService:Create(TextLabel_3, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
		TextTransparency = 0.5
	}):Play()
	task.delay(1, function() --[[ Line: 128 | Upvalues: TweenService (ref), BonusLabel (ref) ]]
		TweenService:Create(BonusLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			TextTransparency = 1
		}):Play()
		local UIStroke = BonusLabel:FindFirstChildOfClass("UIStroke")
		if not UIStroke then
			return
		end
		TweenService:Create(UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Transparency = 1
		}):Play()
	end)
end
function t.Hit() --[[ Hit | Line: 146 | Upvalues: t (copy), TextLabel (copy), TextLabel_2 (copy), Size (copy), Debris (copy), TweenService (copy), v1 (ref), v2 (ref) ]]
	local v12 = t
	v12.hits = v12.hits + 1
	local v22 = ("%d Hits"):format(t.hits)
	if TextLabel:IsA("TextLabel") or TextLabel:IsA("TextButton") then
		TextLabel.Text = v22
	end
	if TextLabel_2 and (TextLabel_2:IsA("TextLabel") or TextLabel_2:IsA("TextButton")) then
		TextLabel_2.Text = v22
	end
	TextLabel.Visible = true
	TextLabel.Size = Size
	TextLabel.TextTransparency = 0
	local UIStroke = TextLabel:FindFirstChildOfClass("UIStroke")
	if UIStroke then
		UIStroke.Transparency = 0
	end
	if TextLabel_2 then
		TextLabel_2.TextTransparency = 1
	end
	local AnimStroke = Instance.new("UIStroke")
	AnimStroke.Name = "AnimStroke"
	AnimStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	AnimStroke.Thickness = 10
	AnimStroke.Color = Color3.new(255/255, 255/255, 255/255)
	AnimStroke.BorderOffset = UDim.new(-0.5, 0)
	AnimStroke.ZIndex = 2
	AnimStroke.Parent = TextLabel
	Debris:AddItem(AnimStroke, 0.5)
	TweenService:Create(AnimStroke, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Transparency = 1,
		BorderOffset = UDim.new(0.2, 0)
	}):Play()
	if v1 and v1.PlaybackState == Enum.PlaybackState.Playing then
		v1:Cancel()
	end
	if v2 and v2.PlaybackState == Enum.PlaybackState.Playing then
		v2:Cancel()
	end
	local t2 = {
		Size = UDim2.new(Size.X.Scale * 1.2, 0, Size.Y.Scale * 1.2, 0),
		Rotation = math.random(-45, 45)
	}
	v1 = TweenService:Create(TextLabel, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), t2)
	v1:Play()
	local t3 = {
		Rotation = math.random(-15, 15)
	}
	v2 = TweenService:Create(TextLabel, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), t3)
	v2:Play()
	local v3
	if not TextLabel_2 then
		v3 = t.hits
		task.delay(5, function() --[[ Line: 237 | Upvalues: v3 (copy), t (ref), TweenService (ref), TextLabel (ref) ]]
			if v3 ~= t.hits then
				return
			end
			t.hits = 0
			TweenService:Create(TextLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				TextTransparency = 1
			}):Play()
			local UIStroke = TextLabel:FindFirstChildOfClass("UIStroke")
			if not UIStroke then
				return
			end
			TweenService:Create(UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				Transparency = 1
			}):Play()
		end)
		return
	end
	TweenService:Create(TextLabel_2, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, true), {
		TextTransparency = 0.5
	}):Play()
	v3 = t.hits
	task.delay(5, function() --[[ Line: 237 | Upvalues: v3 (copy), t (ref), TweenService (ref), TextLabel (ref) ]]
		if v3 ~= t.hits then
			return
		end
		t.hits = 0
		TweenService:Create(TextLabel, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			TextTransparency = 1
		}):Play()
		local UIStroke = TextLabel:FindFirstChildOfClass("UIStroke")
		if not UIStroke then
			return
		end
		TweenService:Create(UIStroke, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			Transparency = 1
		}):Play()
	end)
end
return t