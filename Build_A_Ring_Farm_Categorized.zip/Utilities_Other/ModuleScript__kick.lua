-- Path: ReplicatedStorage.CmdrClient.Commands.kick
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "kick",
	Description = "Kicks a player or set of players.",
	Group = "DefaultAdmin",
	Aliases = { "boot" },
	Args = {
		{
			Type = "players",
			Name = "players",
			Description = "The players to kick."
		}
	}
}