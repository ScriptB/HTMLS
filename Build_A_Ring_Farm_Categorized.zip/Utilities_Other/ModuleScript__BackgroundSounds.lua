-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.BackgroundSounds
-- Class: ModuleScript

-- https://lua.expert/
require(script.Ambient)
require(script.Music)
return {}