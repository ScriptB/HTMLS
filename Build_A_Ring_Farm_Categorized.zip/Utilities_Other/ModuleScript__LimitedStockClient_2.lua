-- Path: StarterPlayer.StarterPlayerScripts.ClientLoader.Handlers.LimitedStockClient
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Signal = require(ReplicatedStorage.Packages.Signal)
local t = {
	PurchaseGranted = Signal.new(),
	PurchaseFailed = Signal.new()
}
local LimitedStock = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("LimitedStock")
local RequestPurchase = LimitedStock:WaitForChild("RequestPurchase")
local PurchaseResolved = LimitedStock:WaitForChild("PurchaseResolved")
function t.RequestPurchase(p1) --[[ RequestPurchase | Line: 26 | Upvalues: RequestPurchase (copy) ]]
	RequestPurchase:FireServer(p1)
end
PurchaseResolved.OnClientEvent:Connect(function(p1, p2, p3) --[[ Line: 30 | Upvalues: t (copy) ]]
	if p2 then
		t.PurchaseGranted:Fire(p1)
	else
		t.PurchaseFailed:Fire(p1, p3 or "Unknown")
	end
end)
return t