-- Path: ReplicatedStorage.CmdrClient.Commands.announce
-- Class: ModuleScript

-- https://lua.expert/
return {
	Name = "announce",
	Description = "Makes a server-wide or a global-wide announcement.",
	Group = "DefaultAdmin",
	Aliases = { "m" },
	Args = {
		{
			Type = "announcementType",
			Name = "type",
			Description = "global/server"
		},
		{
			Type = "string",
			Name = "text",
			Description = "The announcement text."
		}
	}
}