-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.equalsDeep
-- Class: ModuleScript

-- https://lua.expert/
local Util = require(script.Parent.Parent.Util)
local function v2(p1, p2) --[[ compareDeep | Line: 6 | Upvalues: v2 (copy) ]]
	if type(p1) == "table" and type(p2) == "table" then
		local v1 = #p1
		if #p2 ~= v1 then
			return false
		end
		for i = 1, v1 do
			if not v2(p1[i], p2[i]) then
				return false
			end
		end
		return true
	else
		return p1 == p2
	end
end
return function(...) --[[ equalsDeep | Line: 44 | Upvalues: Util (copy), v2 (copy) ]]
	if Util.equalObjects(...) then
		return true
	end
	local v1 = select("#", ...)
	local v22 = select(1, ...)
	for i = 2, v1 do
		if not v2(v22, (select(i, ...))) then
			return false
		end
	end
	return true
end