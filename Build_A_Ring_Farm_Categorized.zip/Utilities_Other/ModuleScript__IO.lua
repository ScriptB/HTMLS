-- Path: ReplicatedStorage.UserGenerated.IO
-- Class: ModuleScript

-- https://lua.expert/
return {}