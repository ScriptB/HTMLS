-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Array.concatDeep
-- Class: ModuleScript

-- https://lua.expert/
local v1 = script.Parent.Parent
local copyDeep = require(script.Parent.copyDeep)
local None = require(v1.None)
return function(...) --[[ concatDeep | Line: 28 | Upvalues: None (copy), copyDeep (copy) ]]
	local t = {}
	for i = 1, select("#", ...) do
		local v1 = select(i, ...)
		if type(v1) == "table" then
			for i2, v in ipairs(v1) do
				if v ~= None then
					if type(v) == "table" then
						table.insert(t, copyDeep(v))
						continue
					end
					table.insert(t, v)
				end
			end
		end
	end
	return t
end