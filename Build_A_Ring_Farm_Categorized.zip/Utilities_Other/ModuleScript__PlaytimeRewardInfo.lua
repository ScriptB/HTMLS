-- Path: ReplicatedStorage.Shared.PlaytimeRewardInfo
-- Class: ModuleScript

-- https://lua.expert/
return {
	Rewards = {
		{
			Cash = 500,
			CashMinutes = 1,
			TimeMinutes = 5
		},
		{
			Cash = 5000,
			CashMinutes = 2,
			TimeMinutes = 15
		},
		{
			Seed = "Onion",
			SeedMultiplier = 1,
			TimeMinutes = 25
		},
		{
			Cash = 25000,
			CashMinutes = 4,
			TimeMinutes = 35
		},
		{
			Seed = "Cabbage",
			SeedMultiplier = 1.25,
			TimeMinutes = 45
		},
		{
			Cash = 75000,
			CashMinutes = 6,
			TimeMinutes = 55
		},
		{
			Cash = 150000,
			CashMinutes = 8,
			TimeMinutes = 65
		},
		{
			Seed = "Corn",
			SeedMultiplier = 1.5,
			TimeMinutes = 75
		},
		{
			Seed = "Cauliflower",
			SeedMultiplier = 1.75,
			TimeMinutes = 85
		},
		{
			Cash = 1000000,
			CashMinutes = 12,
			TimeMinutes = 95
		},
		{
			Cash = 7500000,
			CashMinutes = 15,
			TimeMinutes = 105
		},
		{
			Seed = "Mushroom",
			SeedMultiplier = 2,
			TimeMinutes = 115
		}
	}
}