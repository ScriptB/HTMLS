-- Path: ReplicatedStorage.Shared.MutationAppliers.Honeycomb
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Registry = require(ReplicatedStorage.Shared.Registry)
local MutationApplierUtil = require(ReplicatedStorage.Shared.MutationApplierUtil)
local v1 = Registry.Mutations[script.Name]
return function(p1) --[[ Line: 6 | Upvalues: MutationApplierUtil (copy), v1 (copy) ]]
	MutationApplierUtil.ApplyMainColor(p1, v1.MainColor)
	MutationApplierUtil.ApplyFolderVFX(p1, function(p1, p2) --[[ Line: 8 ]]
		script.hexagon1:Clone().Parent = p1
		script.specs1:Clone().Parent = p1
	end)
end