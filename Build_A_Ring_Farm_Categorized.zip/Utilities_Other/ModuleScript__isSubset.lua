-- Path: ReplicatedStorage.Packages._Index.csqrl_sift@0.0.11.sift.Set.isSubset
-- Class: ModuleScript

-- https://lua.expert/
return function(p1, p2) --[[ isSubset | Line: 19 ]]
	for k, v in pairs(p1) do
		if p2[k] ~= v then
			return false
		end
	end
	return true
end