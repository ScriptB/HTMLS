-- Path: ReplicatedStorage.Shared.VFX.OrbEffect
-- Class: ModuleScript

-- https://lua.expert/
local t = {}
local TweenService = game:GetService("TweenService")
game:GetService("RunService")
game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
require(ReplicatedStorage.Shared.SFXModule)
local MutationVisuals = require(ReplicatedStorage.Shared.MutationVisuals)
game:GetService("Debris")
local Seeds = game.ReplicatedStorage.Assets:WaitForChild("Seeds")
local SpecialFruits = ReplicatedStorage.Assets:WaitForChild("SpecialFruits")
local function weldModelToItsPrimaryPart(p1) --[[ weldModelToItsPrimaryPart | Line: 21 ]]
	local PrimaryPart = p1.PrimaryPart
	if not PrimaryPart then
		warn("Model has no PrimaryPart set:", p1.Name)
		return nil
	end
	PrimaryPart.Anchored = true
	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("BasePart") and v ~= PrimaryPart then
			v.Anchored = false
			local WeldConstraint = Instance.new("WeldConstraint")
			WeldConstraint.Part0 = PrimaryPart
			WeldConstraint.Part1 = v
			WeldConstraint.Parent = PrimaryPart
		end
	end
	return p1
end
function t.CreateCropEffectToPart(p1, p2, p3, p4) --[[ CreateCropEffectToPart | Line: 44 | Upvalues: Seeds (copy), SpecialFruits (copy), weldModelToItsPrimaryPart (copy), MutationVisuals (copy), TweenService (copy) ]]
	local v1 = Seeds:WaitForChild(p3)
	local v2 = SpecialFruits:FindFirstChild(p3)
	if v2 then
		v1 = v2
	end
	if not v1 then
		return
	end
	local v3 = weldModelToItsPrimaryPart((v1:Clone()))
	if v3 then
		v3.Parent = workspace.ParticleDebris
		v3:PivotTo(CFrame.new(p1 + Vector3.new(math.random(-2, 2), math.random(1, 3), math.random(-2, 2))))
		MutationVisuals.ApplyToPlantModel(v3, p4)
		local v9 = p1 + Vector3.new(math.random(-2, 2), math.random(5, 8), math.random(-2, 2))
		local v10 = TweenService:Create(v3.PrimaryPart, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			CFrame = CFrame.new(v9)
		})
		v10:Play()
		v10.Completed:Connect(function() --[[ Line: 84 | Upvalues: TweenService (ref), v3 (ref), p2 (copy), v9 (copy) ]]
			local v1 = TweenService:Create(v3.PrimaryPart, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				CFrame = CFrame.lookAt(p2, p2 + (p2 - v9).Unit)
			})
			v1:Play()
			v1.Completed:Connect(function() --[[ Line: 93 | Upvalues: v3 (ref) ]]
				v3:Destroy()
			end)
		end)
	end
end
return t