-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Modules.CustomPack
-- Class: ModuleScript

-- https://lua.expert/
local ReplicatedStorage = game:GetService("ReplicatedStorage")
game:GetService("SocialService")
local UserInputService = game:GetService("UserInputService")
game:GetService("SoundService")
local t = {
	Version = "1.5.2",
	OpenClose = nil,
	IsOpen = false,
	StateChanged = Instance.new("BindableEvent"),
	SelectedSlotChanged = Instance.new("BindableEvent"),
	ModuleName = "Backpack",
	KeepVRTopbarOpen = true,
	VRIsExclusive = true,
	VRClosesNonExclusive = true
}
local LocalPlayer = game.Players.LocalPlayer
local CurrentCamera = workspace.CurrentCamera
LocalPlayer:GetMouse()
local v1 = Vector2.new(1024, 768)
function CheckTouchDeviceType() --[[ CheckTouchDeviceType | Line: 30 | Upvalues: LocalPlayer (copy), v1 (copy) ]]
	local AbsoluteSize = LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("OnScreen").AbsoluteSize
	if v1.X <= AbsoluteSize.X and v1.Y <= AbsoluteSize.Y then
		return "Tablet"
	else
		return "Mobile"
	end
end
local v2 = if UserInputService.TouchEnabled and (not UserInputService.KeyboardEnabled and CheckTouchDeviceType() == "Mobile") then 50 else 80
local v3 = script:GetAttribute("TextSize")
local v4 = script:GetAttribute("BackgroundTransparency")
local v5 = script:GetAttribute("BackgroundColor")
local v6 = script:GetAttribute("DraggableColor")
local v7 = script:GetAttribute("EquippedColor")
local v8 = script:GetAttribute("SlotLockedTransparency")
local v9 = script:GetAttribute("BorderColor")
local Sound = Instance.new("Sound")
local Sound_2 = Instance.new("Sound")
local t2 = { Enum.KeyCode.Backquote, Enum.KeyCode.ButtonY }
local t3 = { Enum.KeyCode.T, Enum.KeyCode.ButtonR3 }
local v10 = script:GetAttribute("FullSlots")
local v11 = script:GetAttribute("EmptySlots")
local v12 = script:GetAttribute("SearchBoxColor")
local v13 = script:GetAttribute("SearchTextColor")
local v14 = script:GetAttribute("SearchBoxTransparency")
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local UIController = require(script.Parent.Parent.Handlers.UIController)
local Registry = require(ReplicatedStorage.Shared.Registry)
local v15 = nil
local function f16() --[[ Line: 106 ]]
	local ScreenGui = Instance.new("ScreenGui", game.Players.LocalPlayer.PlayerGui)
	local Frame = Instance.new("Frame", ScreenGui)
	Frame.BackgroundTransparency = 1
	Frame.Size = UDim2.new(1, 0, 1, 0)
	ScreenGui:Destroy()
	return Frame.AbsoluteSize
end
local Zero = Enum.KeyCode.Zero.Value
local Backspace = Enum.KeyCode.Backspace.Value
local Icon = script:WaitForChild("Icon")
local t4 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local Players = game:GetService("Players")
local ReplicatedStorage_2 = game:GetService("ReplicatedStorage")
local UserInputService_2 = game:GetService("UserInputService")
local EquipTool = ReplicatedStorage_2:WaitForChild("Remotes"):WaitForChild("EquipTool")
local GuiService = game:GetService("GuiService")
local StarterGui = game:GetService("StarterGui")
local TopbarPlusReference = ReplicatedStorage_2:FindFirstChild("TopbarPlusReference")
local v17 = true
if TopbarPlusReference then
	Icon = TopbarPlusReference.Value
end
local BackpackGui = Instance.new("ScreenGui", Players.LocalPlayer.PlayerGui)
BackpackGui.DisplayOrder = 120
BackpackGui.IgnoreGuiInset = true
BackpackGui.ResetOnSpawn = false
BackpackGui.Name = "BackpackGui"
local ContextActionService = game:GetService("ContextActionService")
local RunService = game:GetService("RunService")
local VRService = game:GetService("VRService")
require(script.GameTranslator)
local v18 = require(Icon)
require(Icon.Themes)
local Utility = require(script.Utility)
local v19 = GuiService:IsTenFootInterface()
if v19 then
	v2 = 100
	v3 = 24
end
local v20 = false
local v21 = UserInputService_2.TouchEnabled and f16().X < 1024
local LocalPlayer_2 = Players.LocalPlayer
local v22 = nil
local v23 = nil
local v24 = nil
local v25 = nil
local v26 = nil
local v27 = nil
local v28 = LocalPlayer_2.Character or LocalPlayer_2.CharacterAdded:Wait()
local Humanoid = v28:FindFirstChildOfClass("Humanoid")
local Backpack = LocalPlayer_2:WaitForChild("Backpack")
local v29 = v18.new()
v29:setRight()
v29:setImage("rbxassetid://109164447884712")
v29:bindToggleKey(t2[1], t2[2])
v29:setName("InventoryIcon")
v29:setImageScale(0.8)
v29:setOrder(-5)
v29.deselectWhenOtherIconSelected = false
local v30 = v18.new()
v30:setRight()
v30:setImage("rbxassetid://99911897637075", "deselected")
v30:setImage("rbxassetid://77157637421495", "selected")
v30:bindToggleKey(t3[1], t3[2])
v30:setName("MusicIcon")
v30:setImageScale(0.8)
v30:setOrder(-1)
v30:setCaption("Toggle Music")
v30.deselectWhenOtherIconSelected = false
v30:setEnabled(false)
local v31 = v18.new()
v31:setRight()
v31:setImage("rbxassetid://102261045850694")
v31:setName("SettingsIcon")
v31:setImageScale(0.8)
v31:setOrder(1)
v31.deselectWhenOtherIconSelected = false
local v32 = v18.new()
v32:setRight()
v32:setImage("rbxassetid://100934413098662")
v32:setName("DailyRewardsIcon")
v32:setImageScale(0.8)
v32:setOrder(2)
v32.deselectWhenOtherIconSelected = false
local v33 = v18.new()
v33:setRight()
v33:setImage("rbxassetid://119696238824829")
v33:setName("PatchNotesIcon")
v33:setImageScale(0.8)
v33:setOrder(3)
v33.deselectWhenOtherIconSelected = false
local t5 = {}
local v34 = nil
local t6 = {}
local t7 = {}
local t8 = {}
local v35 = 0
local v36 = false
local t9 = {}
local SignalBank = require(script.Parent.Parent.Binding.SignalBank)
local v37 = false
local v38 = false
local v39 = false
local t10 = {}
local t11 = {}
local v40 = false
local v41 = 0
local VREnabled = VRService.VREnabled
local v42 = VREnabled and v11 or (if v21 then 5 else v10)
local v43 = if VREnabled then 3 elseif v21 then 2 else 4
local v44 = nil
local function notifySlotLocked(p1) --[[ notifySlotLocked | Line: 277 | Upvalues: t9 (copy), SignalBank (copy) ]]
	SignalBank.Alert:Fire("Preset", "ERROR", t9[p1] or "You can\'t do this right now")
end
local function EvaluateBackpackPanelVisibility(p1) --[[ EvaluateBackpackPanelVisibility | Line: 282 | Upvalues: v29 (copy), v17 (ref), VRService (copy) ]]
	return if p1 then v29.enabled and (v17 and VRService.VREnabled) else p1
end
local function ShowVRBackpackPopup() --[[ ShowVRBackpackPopup | Line: 286 ]] end
local function NewGui(p1, p2) --[[ NewGui | Line: 292 | Upvalues: v3 (ref) ]]
	local v1 = Instance.new(p1)
	v1.Name = p2
	v1.BackgroundColor3 = Color3.new(0/255, 0/255, 0/255)
	v1.BackgroundTransparency = 1
	v1.BorderColor3 = Color3.new(0/255, 0/255, 0/255)
	v1.BorderSizePixel = 0
	v1.Size = UDim2.new(1, 0, 1, 0)
	if p1:match("Text") then
		v1.TextColor3 = Color3.new(255/255, 255/255, 255/255)
		v1.Text = ""
		v1.FontFace = script:GetAttribute("LabelFont")
		v1.TextSize = v3
		local UIStroke = Instance.new("UIStroke", v1)
		UIStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
		UIStroke.Thickness = 2
		v1.TextWrapped = true
		if p2 == "ToolName" then
			script.UIPadding:Clone().Parent = v1
			v1.TextScaled = true
		end
		if p1 == "TextButton" then
			v1.FontFace = script:GetAttribute("SlotFont")
		end
	end
	return v1
end
local function FindLowestEmpty() --[[ FindLowestEmpty | Line: 321 | Upvalues: v42 (ref), t5 (copy) ]]
	for i = 1, v42 do
		local v1 = t5[i]
		if not v1.Tool then
			return v1
		end
	end
	return nil
end
local function isInventoryEmpty() --[[ isInventoryEmpty | Line: 331 | Upvalues: v42 (ref), t5 (copy) ]]
	for i = v42 + 1, #t5 do
		local v1 = t5[i]
		if v1 and v1.Tool then
			return false
		end
	end
	return true
end
local function UseGazeSelection() --[[ UseGazeSelection | Line: 341 | Upvalues: UserInputService_2 (copy) ]]
	return UserInputService_2.VREnabled
end
local function AdjustHotbarFrames() --[[ AdjustHotbarFrames | Line: 345 | Upvalues: v24 (ref), v42 (ref), v35 (ref), t5 (copy) ]]
	local Visible = v24.Visible
	local v1 = v24.Visible and v42 or v35
	local count = 0
	for i = 1, v42 do
		local v2 = t5[i]
		if v2.Tool or Visible then
			count = count + 1
			v2:Readjust(count, v1)
			v2.Frame.Visible = true
			continue
		end
		v2.Frame.Visible = false
	end
end
local function UpdateScrollingFrameCanvasSize() --[[ UpdateScrollingFrameCanvasSize | Line: 363 | Upvalues: v26 (ref), v2 (ref), v27 (ref) ]]
	local v22 = math.floor(v26.AbsoluteSize.X / (v2 + 5))
	v26.CanvasSize = UDim2.new(0, 0, 0, math.ceil((#v27:GetChildren() - 1) / v22) * (v2 + 5) + 5)
end
local function AdjustInventoryFrames() --[[ AdjustInventoryFrames | Line: 370 | Upvalues: v42 (ref), t5 (copy), UpdateScrollingFrameCanvasSize (copy) ]]
	for i = v42 + 1, #t5 do
		local v1 = t5[i]
		v1.Frame.LayoutOrder = v1.Index
		v1.Frame.Visible = v1.Tool ~= nil
	end
	UpdateScrollingFrameCanvasSize()
end
local function UpdateBackpackLayout() --[[ UpdateBackpackLayout | Line: 379 | Upvalues: v23 (ref), v42 (ref), v2 (ref), v24 (ref), v43 (ref), VREnabled (copy), v26 (ref), AdjustHotbarFrames (copy), AdjustInventoryFrames (copy) ]]
	v23.Size = UDim2.new(0, 5 + v42 * (v2 + 5), 0, v2 + 5 + 5)
	v23.Position = UDim2.new(0.5, -v23.Size.X.Offset / 2, 1, -v23.Size.Y.Offset)
	v24.Size = UDim2.new(0, v23.Size.X.Offset, 0, v23.Size.Y.Offset * v43 + 40 + (if VREnabled then 80 else 0))
	v24.Position = UDim2.new(0.5, -v24.Size.X.Offset / 2, 1, v23.Position.Y.Offset - v24.Size.Y.Offset)
	v26.Size = UDim2.new(1, v26.ScrollBarThickness + 1, 1, -40 - (if VREnabled then 80 else 0))
	v26.Position = UDim2.new(0, 0, 0, 40 + (if VREnabled then 40 else 0))
	AdjustHotbarFrames()
	AdjustInventoryFrames()
end
local function Clamp(p1, p2, p3) --[[ Clamp | Line: 397 ]]
	return math.min(p2, (math.max(p1, p3)))
end
local function CheckBounds(p1, p2, p3) --[[ CheckBounds | Line: 401 ]]
	local AbsolutePosition = p1.AbsolutePosition
	local AbsoluteSize = p1.AbsoluteSize
	return if AbsolutePosition.X < p2 and (p2 <= AbsolutePosition.X + AbsoluteSize.X and AbsolutePosition.Y < p3) then p3 <= AbsolutePosition.Y + AbsoluteSize.Y else false
end
local function GetOffset(p1, p2) --[[ GetOffset | Line: 407 ]]
	return (p1.AbsolutePosition + p1.AbsoluteSize / 2 - p2).magnitude
end
local function UnequipAllTools() --[[ UnequipAllTools | Line: 412 | Upvalues: EquipTool (copy) ]]
	EquipTool:FireServer(nil)
end
local function EquipNewTool(p1) --[[ EquipNewTool | Line: 417 | Upvalues: EquipTool (copy) ]]
	EquipTool:FireServer(p1)
end
local function IsEquipped(p1) --[[ IsEquipped | Line: 424 | Upvalues: v28 (ref) ]]
	return if p1 then p1.Parent == v28 else p1
end
local function v45(p1, p2) --[[ MakeSlot | Line: 428 | Upvalues: t5 (copy), VRService (copy), v8 (copy), v6 (copy), v5 (copy), v23 (ref), v2 (ref), Registry (copy), v42 (ref), v24 (ref), UserInputService_2 (copy), t9 (copy), v35 (ref), v37 (ref), v20 (ref), ContextActionService (copy), t6 (copy), v34 (ref), v28 (ref), v44 (ref), NewGui (copy), v7 (copy), UpdateScrollingFrameCanvasSize (copy), EquipTool (copy), Sound_2 (copy), v15 (ref), Backpack (ref), Sound (copy), t (copy), v9 (copy), v45 (copy), v27 (ref), v39 (ref), t7 (copy), Zero (copy), t8 (copy), v29 (copy), SignalBank (copy), v26 (ref) ]]
	local v1 = p2 or #t5 + 1
	local t2 = {
		Tool = nil,
		Index = v1,
		Frame = nil
	}
	local v22 = nil
	local v3 = nil
	local v4 = nil
	local v52 = nil
	local v62 = nil
	local v72 = nil
	local v82 = nil
	local v92 = nil
	local v10 = nil
	local v11 = nil
	local v12 = nil
	local function UpdateSlotFading() --[[ UpdateSlotFading | Line: 459 | Upvalues: VRService (ref), v22 (ref), v8 (ref), v6 (ref), v5 (ref) ]]
		local VREnabled = VRService.VREnabled
		v22.SelectionImageObject = nil
		v22.BackgroundTransparency = if v22.Draggable then 0 else v8
		v22.BackgroundColor3 = v22.Draggable and v6 or v5
	end
	function t2.Readjust(p1, p2, p3) --[[ Readjust | Line: 486 | Upvalues: v23 (ref), v2 (ref), v22 (ref) ]]
		v22.Position = UDim2.new(0, v23.Size.X.Offset / 2 - v2 / 2 + (v2 + 5) * (p2 - (p3 / 2 + 0.5)), 0, 5)
	end
	function t2.Fill(p1, p2) --[[ Fill | Line: 494 | Upvalues: v4 (ref), v52 (ref), v11 (ref), v82 (ref), v22 (ref), v10 (ref), Registry (ref), v92 (ref), v62 (ref), v42 (ref), v24 (ref), UserInputService_2 (ref), t9 (ref), v35 (ref), v37 (ref), v20 (ref), ContextActionService (ref), t6 (ref), v34 (ref), t5 (ref) ]]
		if not p2 then
			return p1:Clear()
		end
		p1.Tool = p2
		local function assignToolData() --[[ assignToolData | Line: 501 | Upvalues: p2 (copy), v4 (ref), v52 (ref), v11 (ref) ]]
			v4.Image = p2.TextureId
			v52.Visible = true
			v52.Text = p2.Name
			if not (v11 and p2:IsA("Tool")) then
				return
			end
			v11.Text = p2.ToolTip
			local v1 = v11.TextBounds.X + 24
			v11.Size = UDim2.new(0, v1, 0, 24)
			v11.Position = UDim2.new(0.5, -v1 / 2, 0, -28)
		end
		assignToolData()
		local function applyGradientOverlay() --[[ applyGradientOverlay | Line: 540 | Upvalues: v82 (ref), p2 (copy), v22 (ref) ]]
			if v82 then
				v82:Destroy()
				v82 = nil
			end
			local UIGradient = p2:FindFirstChildOfClass("UIGradient")
			local UIStroke = p2:FindFirstChildOfClass("UIStroke")
			if not (UIGradient or UIStroke) then
				return
			end
			local GradientOverlay = Instance.new("Frame")
			GradientOverlay.Name = "GradientOverlay"
			GradientOverlay.Size = UDim2.fromScale(1, 1)
			GradientOverlay.Position = UDim2.fromScale(0, 0)
			GradientOverlay.BackgroundColor3 = Color3.new(255/255, 255/255, 255/255)
			GradientOverlay.BackgroundTransparency = if UIGradient then 0.35 else 1
			GradientOverlay.BorderSizePixel = 0
			GradientOverlay.ZIndex = v22.ZIndex - 1
			local UICorner = v22:FindFirstChildOfClass("UICorner")
			if UICorner then
				UICorner:Clone().Parent = GradientOverlay
			end
			if UIGradient then
				local v2 = UIGradient:Clone()
				if v2:GetAttribute("GradientRotate") == true then
					v2:AddTag("GradientRotate")
				end
				v2.Parent = GradientOverlay
			end
			if UIStroke then
				local v3 = UIStroke:Clone()
				local UIGradient_2 = v3:FindFirstChildOfClass("UIGradient")
				if UIGradient_2 and UIGradient_2:GetAttribute("GradientRotate") == true then
					UIGradient_2:AddTag("GradientRotate")
				end
				v3.Parent = GradientOverlay
			end
			GradientOverlay.Parent = v22
			v82 = GradientOverlay
		end
		applyGradientOverlay();
		(function() --[[ applyGradientBasedOnRarity | Line: 588 | Upvalues: v10 (ref), p2 (copy), Registry (ref), v52 (ref) ]]
			if v10 then
				v10:Destroy()
				v10 = nil
			end
			local v1 = p2:GetAttribute("trueName")
			if not v1 then
				return
			end
			local v2 = Registry.Plants[v1] or Registry.Pets[v1]
			if not v2 then
				return
			end
			local v3 = Registry.Rarities[v2.Rarity]
			if not v3 then
				return
			end
			local Gradient = v3.Gradient
			if not Gradient then
				return
			end
			local v4 = Gradient:Clone()
			v4.Parent = v52
			v10 = v4
		end)()
		if v92 then
			v92:Disconnect()
			v92 = nil
		end
		v92 = p2.ChildAdded:Connect(function(p1) --[[ Line: 622 | Upvalues: applyGradientOverlay (copy) ]]
			if not (p1:IsA("UIGradient") or p1:IsA("UIStroke")) then
				return
			end
			applyGradientOverlay()
		end)
		p2.ChildRemoved:Connect(function(p1) --[[ Line: 627 | Upvalues: v82 (ref), applyGradientOverlay (copy) ]]
			if not ((p1:IsA("UIGradient") or p1:IsA("UIStroke")) and v82) then
				return
			end
			applyGradientOverlay()
		end)
		if v62 then
			v62:disconnect()
			v62 = nil
		end
		v62 = p2.Changed:connect(function(p1) --[[ Line: 638 | Upvalues: assignToolData (copy) ]]
			if p1 ~= "TextureId" and (p1 ~= "Name" and p1 ~= "ToolTip") then
				return
			end
			assignToolData()
		end)
		local v1 = p1.Index <= v42
		if (not v1 or v24.Visible) and not (UserInputService_2.VREnabled or t9[p1.Index]) then
			v22.Draggable = true
		end
		p1:UpdateEquipView()
		if v1 then
			v35 = v35 + 1
			if v37 and (v35 >= 1 and not v20) then
				v20 = true
				ContextActionService:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
			end
		end
		t6[p2] = p1
		local v2
		for i = 1, v42 do
			local v3 = t5[i]
			if not v3.Tool then
				v2 = v3
				v34 = v3
				return
			end
		end
		v2 = nil
		v34 = v2
	end
	function t2.Clear(p1) --[[ Clear | Line: 669 | Upvalues: v62 (ref), v92 (ref), v82 (ref), v10 (ref), v4 (ref), v52 (ref), v11 (ref), v22 (ref), v42 (ref), v35 (ref), v20 (ref), ContextActionService (ref), t6 (ref), v34 (ref), t5 (ref) ]]
		if not p1.Tool then
			return
		end
		if v62 then
			v62:disconnect()
			v62 = nil
		end
		if v92 then
			v92:Disconnect()
			v92 = nil
		end
		if v82 then
			v82:Destroy()
			v82 = nil
		end
		if v10 then
			v10:Destroy()
			v10 = nil
		end
		v4.Image = ""
		v52.Text = ""
		if v11 then
			v11.Text = ""
			v11.Visible = false
		end
		v22.Draggable = false
		p1:UpdateEquipView(true)
		if p1.Index <= v42 then
			v35 = v35 - 1
			if v35 < 1 then
				v20 = false
				ContextActionService:UnbindAction("RBXHotbarEquip")
			end
		end
		t6[p1.Tool] = nil
		p1.Tool = nil
		local v1
		for i = 1, v42 do
			local v2 = t5[i]
			if not v2.Tool then
				v1 = v2
				v34 = v2
				return
			end
		end
		v1 = nil
		v34 = v1
	end
	function t2.UpdateEquipView(p1, p2) --[[ UpdateEquipView | Line: 719 | Upvalues: v28 (ref), v44 (ref), t2 (copy), v72 (ref), NewGui (ref), v22 (ref), v7 (ref), UpdateSlotFading (copy) ]]
		if p2 then
			if not v72 then
				UpdateSlotFading()
				return
			end
			v72.Parent = nil
		else
			local Tool = p1.Tool
			if if Tool then Tool.Parent == v28 else Tool then
				v44 = t2
				if not v72 then
					v72 = NewGui("Frame", "Equipped")
					v72.ZIndex = v22.ZIndex
					local UICorner = Instance.new("UICorner")
					UICorner.CornerRadius = script:GetAttribute("CornerRadius")
					UICorner.Parent = v72
					local UIStroke = Instance.new("UIStroke")
					UIStroke.Color = v7
					UIStroke.Thickness = 3
					UIStroke.Parent = v72
				end
				v72.Parent = v22
			else
				if not v72 then
					UpdateSlotFading()
					return
				end
				v72.Parent = nil
			end
		end
		UpdateSlotFading()
	end
	function t2.IsEquipped(p1) --[[ IsEquipped | Line: 745 | Upvalues: v28 (ref) ]]
		local Tool = p1.Tool
		return if Tool then Tool.Parent == v28 else Tool
	end
	function t2.Delete(p1) --[[ Delete | Line: 749 | Upvalues: v22 (ref), t5 (ref), UpdateScrollingFrameCanvasSize (ref) ]]
		v22:Destroy()
		table.remove(t5, p1.Index)
		for i = p1.Index, #t5 do
			t5[i]:SlideBack()
		end
		UpdateScrollingFrameCanvasSize()
	end
	function t2.Swap(p1, p2) --[[ Swap | Line: 762 ]]
		local Tool = p1.Tool
		local Tool_2 = p2.Tool
		p1:Clear()
		if Tool_2 then
			p2:Clear()
			p1:Fill(Tool_2)
		end
		if Tool then
			p2:Fill(Tool)
		else
			p2:Clear()
		end
	end
	function t2.SlideBack(p1) --[[ SlideBack | Line: 776 | Upvalues: v22 (ref) ]]
		p1.Index = p1.Index - 1
		v22.Name = p1.Index
		v22.LayoutOrder = p1.Index
	end
	function t2.TurnNumber(p1, p2) --[[ TurnNumber | Line: 782 | Upvalues: v12 (ref) ]]
		if not v12 then
			return
		end
		v12.Visible = p2
	end
	function t2.SetClickability(p1, p2) --[[ SetClickability | Line: 788 | Upvalues: UserInputService_2 (ref), t9 (ref), v22 (ref), UpdateSlotFading (copy) ]]
		if not p1.Tool then
			return
		end
		if UserInputService_2.VREnabled or t9[p1.Index] then
			v22.Draggable = false
		else
			v22.Draggable = not p2
		end
		UpdateSlotFading()
	end
	function t2.UpdateDraggable(p1) --[[ UpdateDraggable | Line: 799 | Upvalues: v22 (ref), UpdateSlotFading (copy), UserInputService_2 (ref), t9 (ref), v42 (ref), v24 (ref) ]]
		if not p1.Tool then
			v22.Draggable = false
			UpdateSlotFading()
			return
		end
		if UserInputService_2.VREnabled or t9[p1.Index] then
			v22.Draggable = false
		else
			v22.Draggable = not (p1.Index <= v42) or v24.Visible
		end
		UpdateSlotFading()
	end
	function t2.CheckTerms(p1, p2) --[[ CheckTerms | Line: 817 | Upvalues: v52 (ref), v11 (ref) ]]
		local sum = 0
		local function checkEm(p1, p2) --[[ checkEm | Line: 819 | Upvalues: sum (ref) ]]
			local _, v1 = p1:lower():gsub(p2, "")
			sum = sum + v1
		end
		local Tool = p1.Tool
		if Tool then
			for k in pairs(p2) do
				local _, v1 = v52.Text:lower():gsub(k, "")
				sum = sum + v1
				if Tool:IsA("Tool") then
					local _2, v3 = (if v11 then v11.Text or "" else ""):lower():gsub(k, "")
					sum = sum + v3
				end
			end
		end
		return sum
	end
	function t2.Select(p1) --[[ Select | Line: 844 | Upvalues: t2 (copy), v28 (ref), EquipTool (ref), Sound_2 (ref), v15 (ref), Backpack (ref), Sound (ref), t (ref) ]]
		local Tool = t2.Tool
		if not Tool then
			return
		end
		if if Tool then if Tool.Parent == v28 then true else false else Tool then
			EquipTool:FireServer(nil)
			Sound_2:Play()
			v15 = nil
		elseif Tool.Parent == Backpack then
			Sound:Play()
			EquipTool:FireServer(Tool)
			v15 = t2
		end
		if v15 then
			t.SelectedSlotChanged:Fire({
				SlotNumber = v15.Index,
				Tool = v15.Tool,
				IsEquipped = v15:IsEquipped()
			})
			return
		end
		t.SelectedSlotChanged:Fire(nil)
	end
	v22 = NewGui("TextButton", v1)
	local UIStroke = Instance.new("UIStroke")
	UIStroke.Parent = v22
	local UICorner = Instance.new("UICorner")
	UICorner.CornerRadius = script:GetAttribute("CornerRadius")
	UICorner.Parent = v22
	UIStroke.Thickness = 0
	v22.BackgroundColor3 = v5
	UIStroke.Color = v9
	v22.Text = ""
	v22.AutoButtonColor = false
	v22.BorderSizePixel = 0
	v22.Size = UDim2.new(0, v2, 0, v2)
	v22.Active = true
	v22.Draggable = false
	v22.BackgroundTransparency = v8
	v22.MouseButton1Click:connect(function() --[[ Line: 888 | Upvalues: t2 (copy) ]]
		changeSlot(t2)
	end)
	t2.Frame = v22
	local v13 = NewGui("Frame", "SelectionObjectClipper")
	v13.Visible = false
	v13.Parent = v22
	local v14 = NewGui("ImageLabel", "Selector")
	v14.Size = UDim2.new(1, 0, 1, 0)
	v14.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
	v14.ScaleType = Enum.ScaleType.Slice
	v14.SliceCenter = Rect.new(12, 12, 52, 52)
	v14.Parent = v13
	v4 = NewGui("ImageLabel", "Icon")
	v4.Size = UDim2.new(0.8, 0, 0.8, 0)
	v4.Position = UDim2.new(0.1, 0, 0.1, 0)
	v4.Parent = v22
	v52 = NewGui("TextLabel", "ToolName")
	v52.Size = UDim2.new(1, -2, 1, -2)
	v52.Position = UDim2.new(0, 1, 0, 1)
	v52.Parent = v22
	t2.Frame.LayoutOrder = t2.Index
	if v1 <= v42 then
		v11 = NewGui("TextLabel", "ToolTip")
		v11.ZIndex = 2
		v11.FontFace = script:GetAttribute("ToolTipFont")
		v11.TextWrapped = false
		v11.TextYAlignment = Enum.TextYAlignment.Center
		v11.BackgroundColor3 = Color3.new(102/255, 102/255, 102/255)
		v11.BackgroundTransparency = 1
		v11.Visible = false
		v11.Parent = v22
		local UICorner_2 = Instance.new("UICorner")
		UICorner_2.CornerRadius = script:GetAttribute("CornerRadius")
		UICorner_2.Parent = v11
		v22.MouseEnter:connect(function() --[[ Line: 932 | Upvalues: v11 (ref) ]]
			if v11.Text == "" then
				return
			end
			v11.Visible = true
		end)
		v22.MouseLeave:connect(function() --[[ Line: 937 | Upvalues: v11 (ref) ]]
			v11.Visible = false
		end)
		function t2.MoveToInventory(p1) --[[ MoveToInventory | Line: 941 | Upvalues: t2 (copy), v42 (ref), v45 (ref), v27 (ref), v28 (ref), EquipTool (ref), v39 (ref), v24 (ref) ]]
			if not (t2.Index <= v42) then
				return
			end
			local Tool = t2.Tool
			p1:Clear()
			local v1 = v45(v27)
			v1:Fill(Tool)
			if if Tool then Tool.Parent == v28 else Tool then
				EquipTool:FireServer(nil)
			end
			if not v39 then
				return
			end
			v1.Frame.Visible = false
			v1.Parent = v24
		end
		if v1 < 10 or v1 == v42 then
			local v16 = v1 < 10 and v1 or 0
			v12 = NewGui("TextLabel", "Number")
			v12.Text = v16
			v12.Size = UDim2.new(0, 15, 0, 15)
			v12.Visible = false
			v12.Parent = v22
			t7[Zero + v16] = t2.Select
		end
	end
	local Position = v22.Position
	local v17 = 0
	local v18 = nil
	v22.DragBegin:connect(function(p1) --[[ Line: 975 | Upvalues: t9 (ref), t2 (copy), t8 (ref), v22 (ref), Position (ref), UIStroke (copy), v29 (ref), v4 (ref), v52 (ref), v12 (ref), v72 (ref), v18 (ref), v27 (ref), v24 (ref), v3 (ref), NewGui (ref) ]]
		if t9[t2.Index] then
			return
		end
		t8[v22] = true
		Position = p1
		UIStroke.Thickness = 2
		v29:lock()
		v22.ZIndex = 2
		v4.ZIndex = 2
		v52.ZIndex = 2
		v22.Parent.ZIndex = 2
		if v12 then
			v12.ZIndex = 2
		end
		if v72 then
			v72.ZIndex = 2
			for k, v in pairs(v72:GetChildren()) do
				if not (v:IsA("UICorner") or v:IsA("UIStroke")) then
					v.ZIndex = 2
				end
			end
		end
		v18 = v22.Parent
		if v18 ~= v27 then
			return
		end
		local AbsolutePosition = v22.AbsolutePosition
		local v1 = UDim2.new(0, v22.AbsolutePosition.X - v24.AbsolutePosition.X, 0, v22.AbsolutePosition.Y - v24.AbsolutePosition.Y)
		v22.Parent = v24
		v22.Position = v1
		v3 = NewGui("Frame", "FakeSlot")
		v3.LayoutOrder = v22.LayoutOrder
		v3.Size = v22.Size
		v3.BackgroundTransparency = 1
		v3.Parent = v27
	end)
	v22.DragStopped:connect(function(p1, p2) --[[ Line: 1025 | Upvalues: v3 (ref), v22 (ref), Position (ref), v18 (ref), UIStroke (copy), v29 (ref), v4 (ref), v52 (ref), v12 (ref), v72 (ref), t8 (ref), t2 (copy), v24 (ref), v42 (ref), v17 (ref), v34 (ref), v23 (ref), t5 (ref), t9 (ref), SignalBank (ref), v28 (ref), EquipTool (ref), v39 (ref) ]]
		if v3 then
			v3:Destroy()
		end
		local v1 = tick()
		v22.Position = Position
		v22.Parent = v18
		UIStroke.Thickness = 0
		v29:unlock()
		v22.ZIndex = 1
		v4.ZIndex = 1
		v52.ZIndex = 1
		v18.ZIndex = 1
		if v12 then
			v12.ZIndex = 1
		end
		if v72 then
			v72.ZIndex = 1
			for k, v in pairs(v72:GetChildren()) do
				if not (v:IsA("UICorner") or v:IsA("UIStroke")) then
					v.ZIndex = 1
				end
			end
		end
		t8[v22] = nil
		if not t2.Tool then
			return
		end
		local v2 = v24
		local AbsolutePosition = v2.AbsolutePosition
		local AbsoluteSize = v2.AbsoluteSize
		if if AbsolutePosition.X < p1 and (p1 <= AbsolutePosition.X + AbsoluteSize.X and AbsolutePosition.Y < p2) then if p2 <= AbsolutePosition.Y + AbsoluteSize.Y then true else false else false then
			if t2.Index <= v42 then
				t2:MoveToInventory()
			end
			if v42 < t2.Index and v1 - v17 < 0.5 then
				if v34 then
					t2:Clear()
					v34:Fill(t2.Tool)
					t2:Delete()
				end
				v1 = 0
			end
		else
			local v43 = v23
			local AbsolutePosition_2 = v43.AbsolutePosition
			local AbsoluteSize_2 = v43.AbsoluteSize
			if if AbsolutePosition_2.X < p1 and (p1 <= AbsolutePosition_2.X + AbsoluteSize_2.X and AbsolutePosition_2.Y < p2) then if p2 <= AbsolutePosition_2.Y + AbsoluteSize_2.Y then true else false else false then
				local t = { (1 / 0), nil }
				for i = 1, v42 do
					local v6 = t5[i]
					local Frame = v6.Frame
					local magnitude = (Frame.AbsolutePosition + Frame.AbsoluteSize / 2 - Vector2.new(p1, p2)).magnitude
					if magnitude < t[1] then
						t = { magnitude, v6 }
					end
				end
				local v8 = t[2]
				if v8 ~= t2 and t9[v8.Index] then
					SignalBank.Alert:Fire("Preset", "ERROR", t9[v8.Index] or "You can\'t do this right now")
				elseif v8 ~= t2 then
					t2:Swap(v8)
					if v42 < t2.Index then
						local Tool = t2.Tool
						if Tool then
							if if Tool then Tool.Parent == v28 else Tool then
								EquipTool:FireServer(nil)
							end
							if v39 then
								t2.Frame.Visible = false
								t2.Frame.Parent = v24
							end
						else
							t2:Delete()
						end
					end
				end
			elseif t2.Index <= v42 then
				t2:MoveToInventory()
			end
		end
		v17 = v1
	end)
	v22.Parent = p1
	t5[v1] = t2
	if not (v42 < v1) then
		return t2
	end
	UpdateScrollingFrameCanvasSize()
	if not v24.Visible or v39 then
		return t2
	end
	v26.CanvasPosition = Vector2.new(0, (math.max(0, v26.CanvasSize.Y.Offset - v26.AbsoluteSize.Y)))
	return t2
end
local function OnChildAdded(p1) --[[ OnChildAdded | Line: 1141 | Upvalues: v28 (ref), Humanoid (ref), v41 (ref), v36 (ref), t6 (copy), LocalPlayer_2 (ref), v34 (ref), v45 (copy), v27 (ref), t5 (copy), Backpack (ref), AdjustHotbarFrames (copy), v42 (ref), v24 (ref) ]]
	if p1:IsA("Tool") then
		if p1.Parent == v28 then
			v41 = tick()
		end
		if not v36 and (p1.Parent == v28 and not t6[p1]) then
			local StarterGear = LocalPlayer_2:FindFirstChild("StarterGear")
			if StarterGear and StarterGear:FindFirstChild(p1.Name) then
				v36 = true
				for i = (v34 or v45(v27)).Index, 1, -1 do
					local v2 = t5[i]
					local v3 = i - 1
					if v3 > 0 then
						t5[v3]:Swap(v2)
						continue
					end
					v2:Fill(p1)
				end
				for k, v in pairs(v28:GetChildren()) do
					if v:IsA("Tool") and v ~= p1 then
						v.Parent = Backpack
					end
				end
			end
		end
		local v4 = t6[p1]
		if v4 then
			v4:UpdateEquipView()
			return
		end
		if p1:GetAttribute("HoneyTokenTool") == true and not v34 then
			local v5 = t5[v42]
			if v5 and v5.Tool then
				v5:Clear()
				v45(v27):Fill(v5.Tool)
				v5:Fill(p1)
				if v24.Visible then
					return
				end
			end
		end
		local v6 = v34 or v45(v27)
		v6:Fill(p1)
		if not (v6.Index <= v42) or v24.Visible then
			return
		end
		AdjustHotbarFrames()
	else
		if not p1:IsA("Humanoid") or p1.Parent ~= v28 then
			return
		end
		Humanoid = p1
	end
end
local function OnChildRemoved(p1) --[[ OnChildRemoved | Line: 1213 | Upvalues: v41 (ref), v28 (ref), Backpack (ref), t6 (copy), v42 (ref), v24 (ref), AdjustHotbarFrames (copy) ]]
	if not p1:IsA("Tool") then
		return
	end
	v41 = tick()
	local v1 = p1.Parent
	if v1 == v28 or v1 == Backpack then
		return
	end
	local v2 = t6[p1]
	if not v2 then
		return
	end
	v2:Clear()
	if v42 < v2.Index then
		v2:Delete()
		return
	end
	if v24.Visible then
		return
	end
	AdjustHotbarFrames()
end
local function OnCharacterAdded(p1) --[[ OnCharacterAdded | Line: 1239 | Upvalues: t5 (copy), v42 (ref), t11 (ref), v28 (ref), OnChildRemoved (copy), OnChildAdded (copy), Backpack (ref), LocalPlayer_2 (ref), AdjustHotbarFrames (copy) ]]
	for i = #t5, 1, -1 do
		local v1 = t5[i]
		if v1.Tool then
			v1:Clear()
		end
		if v42 < i then
			v1:Delete()
		end
	end
	for k, v in pairs(t11) do
		v:Disconnect()
	end
	t11 = {}
	v28 = p1
	table.insert(t11, p1.ChildRemoved:Connect(OnChildRemoved))
	table.insert(t11, p1.ChildAdded:Connect(OnChildAdded))
	for k, v in pairs(p1:GetChildren()) do
		OnChildAdded(v)
	end
	Backpack = LocalPlayer_2:WaitForChild("Backpack")
	table.insert(t11, Backpack.ChildRemoved:Connect(OnChildRemoved))
	table.insert(t11, Backpack.ChildAdded:Connect(OnChildAdded))
	for k, v in pairs(Backpack:GetChildren()) do
		OnChildAdded(v)
	end
	AdjustHotbarFrames()
end
local function OnInputBegan(p1, p2) --[[ OnInputBegan | Line: 1277 | Upvalues: v38 (ref), v37 (ref), Backspace (copy), t7 (copy), v24 (ref), v29 (copy) ]]
	if p1.UserInputType == Enum.UserInputType.Keyboard and (not v38 and (v37 or p1.KeyCode.Value == Backspace)) then
		local v1 = t7[p1.KeyCode.Value]
		if v1 then
			v1(p2)
		end
	end
	local UserInputType = p1.UserInputType
	if p2 or UserInputType ~= Enum.UserInputType.MouseButton1 and UserInputType ~= Enum.UserInputType.Touch or not v24.Visible then
		return
	end
	v29:deselect()
end
local function OnUISChanged(p1) --[[ OnUISChanged | Line: 1300 | Upvalues: UserInputService_2 (copy), v42 (ref), t5 (copy) ]]
	if p1 ~= "KeyboardEnabled" and p1 ~= "VREnabled" then
		return
	end
	local v1 = UserInputService_2.KeyboardEnabled and not UserInputService_2.VREnabled
	for i = 1, v42 do
		t5[i]:TurnNumber(v1)
	end
end
local v46 = nil
local v47 = nil
local function f48() --[[ Line: 1312 ]] end
local v49 = Vector2.new(0, 0)
function unbindAllGamepadEquipActions() --[[ unbindAllGamepadEquipActions | Line: 1316 | Upvalues: ContextActionService (copy) ]]
	ContextActionService:UnbindAction("RBXBackpackHasGamepadFocus")
	ContextActionService:UnbindAction("RBXCloseInventory")
end
local function setHotbarVisibility(p1, p2) --[[ setHotbarVisibility | Line: 1321 | Upvalues: v42 (ref), t5 (copy) ]]
	for i = 1, v42 do
		local v1 = t5[i]
		if v1 and (v1.Frame and (p2 or v1.Tool)) then
			v1.Frame.Visible = p1
		end
	end
end
local function getInputDirection(p1) --[[ getInputDirection | Line: 1330 | Upvalues: v49 (ref) ]]
	local v1 = if p1.UserInputState == Enum.UserInputState.End then -1 else 1
	if p1.KeyCode == Enum.KeyCode.Thumbstick1 then
		local magnitude = p1.Position.magnitude
		v49 = if magnitude > 0.98 then Vector2.new(p1.Position.x / magnitude, -p1.Position.y / magnitude) else Vector2.new(0, 0)
	else
		v49 = if p1.KeyCode == Enum.KeyCode.DPadLeft then Vector2.new(v49.x - v1 * 1, v49.y) elseif p1.KeyCode == Enum.KeyCode.DPadRight then Vector2.new(v49.x + v1 * 1, v49.y) elseif p1.KeyCode == Enum.KeyCode.DPadUp then Vector2.new(v49.x, v49.y - v1 * 1) elseif p1.KeyCode == Enum.KeyCode.DPadDown then Vector2.new(v49.x, v49.y + v1 * 1) else Vector2.new(0, 0)
	end
	return v49
end
function changeToolFunc(p1, p2, p3) --[[ Line: 1390 | Upvalues: v46 (ref), v47 (ref), EquipTool (copy), v42 (ref), t5 (copy), v44 (ref) ]]
	if p2 ~= Enum.UserInputState.Begin then
		return
	end
	if v46 then
		if (v46.KeyCode ~= Enum.KeyCode.ButtonR1 or p3.KeyCode ~= Enum.KeyCode.ButtonL1) and (v46.KeyCode ~= Enum.KeyCode.ButtonL1 or p3.KeyCode ~= Enum.KeyCode.ButtonR1) then
			v46 = p3
			v47 = tick()
			delay(0.06, function() --[[ Line: 1412 | Upvalues: v46 (ref), p3 (copy), v42 (ref), t5 (ref), EquipTool (ref), v44 (ref) ]]
				if v46 ~= p3 then
					return
				end
				local v1 = if p3.KeyCode == Enum.KeyCode.ButtonL1 then -1 else 1
				for i = 1, v42 do
					if t5[i]:IsEquipped() then
						local sum_2 = v1 + i
						local v2 = false
						if v42 < sum_2 then
							sum_2 = 1
							v2 = true
						elseif sum_2 < 1 then
							sum_2 = v42
							v2 = true
						end
						local v3 = sum_2
						while not t5[sum_2].Tool do
							sum_2 = sum_2 + v1
							if sum_2 == v3 then
								return
							end
							if v42 < sum_2 then
								sum_2 = 1
								v2 = true
							elseif sum_2 < 1 then
								sum_2 = v42
								v2 = true
							else
								continue
							end
						end
						if v2 then
							EquipTool:FireServer(nil)
							v44 = nil
						else
							t5[sum_2]:Select()
						end
						return
					end
				end
				if v44 and v44.Tool then
					v44:Select()
					return
				end
				for j = if v1 == -1 then v42 or 1 else 1, if v1 == -1 then 1 else v42, v1 do
					if t5[j].Tool then
						t5[j]:Select()
						return
					end
				end
			end)
			return
		end
		if tick() - v47 <= 0.06 then
			EquipTool:FireServer(nil)
			v46 = p3
			v47 = tick()
			return
		end
	end
	v46 = p3
	v47 = tick()
	delay(0.06, function() --[[ Line: 1412 | Upvalues: v46 (ref), p3 (copy), v42 (ref), t5 (ref), EquipTool (ref), v44 (ref) ]]
		if v46 ~= p3 then
			return
		end
		local v1 = if p3.KeyCode == Enum.KeyCode.ButtonL1 then -1 else 1
		for i = 1, v42 do
			if t5[i]:IsEquipped() then
				local sum_2 = v1 + i
				local v2 = false
				if v42 < sum_2 then
					sum_2 = 1
					v2 = true
				elseif sum_2 < 1 then
					sum_2 = v42
					v2 = true
				end
				local v3 = sum_2
				while not t5[sum_2].Tool do
					sum_2 = sum_2 + v1
					if sum_2 == v3 then
						return
					end
					if v42 < sum_2 then
						sum_2 = 1
						v2 = true
					elseif sum_2 < 1 then
						sum_2 = v42
						v2 = true
					else
						continue
					end
				end
				if v2 then
					EquipTool:FireServer(nil)
					v44 = nil
				else
					t5[sum_2]:Select()
				end
				return
			end
		end
		if v44 and v44.Tool then
			v44:Select()
			return
		end
		for j = if v1 == -1 then v42 or 1 else 1, if v1 == -1 then 1 else v42, v1 do
			if t5[j].Tool then
				t5[j]:Select()
				return
			end
		end
	end)
end
function getGamepadSwapSlot() --[[ getGamepadSwapSlot | Line: 1479 | Upvalues: t5 (copy) ]]
	for i = 1, #t5 do
		if t5[i].Frame:WaitForChild("UIStroke").Thickness > 0 then
			return t5[i]
		end
	end
end
function changeSlot(p1) --[[ changeSlot | Line: 1487 | Upvalues: VRService (copy), v24 (ref), GuiService (copy), t9 (copy), SignalBank (copy), v25 (ref), v42 (ref) ]]
	if p1.Frame == GuiService.SelectedObject and (not VRService.VREnabled or v24.Visible) then
		local v2 = getGamepadSwapSlot()
		if not v2 then
			local Size = p1.Frame.Size
			local Position = p1.Frame.Position
			p1.Frame:TweenSizeAndPosition(Size + UDim2.new(0, 10, 0, 10), Position - UDim2.new(0, 5, 0, 5), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.1, true, function() --[[ Line: 1530 | Upvalues: p1 (copy), Size (copy), Position (copy) ]]
				p1.Frame:TweenSizeAndPosition(Size, Position, Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.1, true)
			end)
			p1.Frame:WaitForChild("UIStroke").Thickness = 3
			v25.SelectionImageObject.Visible = true
			return
		end
		v2.Frame:WaitForChild("UIStroke").Thickness = 0
		if v2 == p1 then
			return
		end
		local v3 = t9[p1.Index] and p1.Index or (t9[v2.Index] and v2.Index or nil)
		if v3 then
			SignalBank.Alert:Fire("Preset", "ERROR", t9[v3] or "You can\'t do this right now")
			return
		end
		p1:Swap(v2)
		v25.SelectionImageObject.Visible = false
		if v42 < p1.Index and not p1.Tool then
			if GuiService.SelectedObject == p1.Frame then
				GuiService.SelectedObject = v2.Frame
			end
			p1:Delete()
		end
		if not (v42 < v2.Index) or v2.Tool then
			return
		end
		if GuiService.SelectedObject ~= v2.Frame then
			v2:Delete()
			return
		end
		GuiService.SelectedObject = p1.Frame
		v2:Delete()
		return
	end
	p1:Select()
	v25.SelectionImageObject.Visible = false
end
function vrMoveSlotToInventory() --[[ vrMoveSlotToInventory | Line: 1543 | Upvalues: VRService (copy), v25 (ref) ]]
	if not VRService.VREnabled then
		return
	end
	local v1 = getGamepadSwapSlot()
	if not (v1 and v1.Tool) then
		return
	end
	v1:WaitForChild("UIStroke").Thickness = 0
	v1:MoveToInventory()
	v25.SelectionImageObject.Visible = false
end
function enableGamepadInventoryControl() --[[ enableGamepadInventoryControl | Line: 1556 | Upvalues: v24 (ref), v29 (copy), ContextActionService (copy), f48 (copy), UserInputService_2 (copy), GuiService (copy), v23 (ref) ]]
	local function f1(p1, p2, p3) --[[ Line: 1557 | Upvalues: v24 (ref), v29 (ref) ]]
		if p2 ~= Enum.UserInputState.Begin then
			return
		end
		if getGamepadSwapSlot() then
			local v1 = getGamepadSwapSlot()
			if v1 then
				v1:WaitForChild("UIStroke").Thickness = 0
			end
		else
			if not v24.Visible then
				return
			end
			v29:deselect()
		end
	end
	ContextActionService:BindAction("RBXBackpackHasGamepadFocus", f48, false, Enum.UserInputType.Gamepad1)
	ContextActionService:BindAction("RBXCloseInventory", f1, false, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonStart)
	if UserInputService_2.VREnabled then
		return
	end
	GuiService.SelectedObject = v23:FindFirstChild("1")
end
function disableGamepadInventoryControl() --[[ disableGamepadInventoryControl | Line: 1583 | Upvalues: v42 (ref), t5 (copy), GuiService (copy), v22 (ref) ]]
	unbindAllGamepadEquipActions()
	for i = 1, v42 do
		local v1 = t5[i]
		if v1 and v1.Frame then
			v1.Frame:WaitForChild("UIStroke").Thickness = 0
		end
	end
	if not (GuiService.SelectedObject and GuiService.SelectedObject:IsDescendantOf(v22)) then
		return
	end
	GuiService.SelectedObject = nil
end
local function bindBackpackHotbarAction() --[[ bindBackpackHotbarAction | Line: 1598 | Upvalues: v37 (ref), v20 (ref), ContextActionService (copy) ]]
	if not v37 or v20 then
		return
	end
	v20 = true
	ContextActionService:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
end
local function unbindBackpackHotbarAction() --[[ unbindBackpackHotbarAction | Line: 1605 | Upvalues: v20 (ref), ContextActionService (copy) ]]
	disableGamepadInventoryControl()
	v20 = false
	ContextActionService:UnbindAction("RBXHotbarEquip")
end
function gamepadDisconnected() --[[ gamepadDisconnected | Line: 1611 | Upvalues: v40 (ref) ]]
	v40 = false
	disableGamepadInventoryControl()
end
function gamepadConnected() --[[ gamepadConnected | Line: 1616 | Upvalues: v40 (ref), v35 (ref), v37 (ref), v20 (ref), ContextActionService (copy), v24 (ref) ]]
	v40 = true
	if v35 >= 1 and (v37 and not v20) then
		v20 = true
		ContextActionService:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
	end
	if not v24.Visible then
		return
	end
	enableGamepadInventoryControl()
end
local function OnIconChanged(p1) --[[ OnIconChanged | Line: 1628 | Upvalues: StarterGui (copy), v29 (copy), GuiService (copy), v37 (ref), v22 (ref), t10 (copy), v35 (ref), v20 (ref), ContextActionService (copy) ]]
	local v1 = if p1 then StarterGui:GetCore("TopbarEnabled") else p1
	v29:setEnabled(if v1 then not GuiService.MenuIsOpen else v1)
	v37 = v1
	v22.Visible = v1
	for k, v in pairs(t10) do

	end
	if v1 then
		if v35 >= 1 and (v1 and not v20) then
			v20 = true
			ContextActionService:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
		end
	else
		disableGamepadInventoryControl()
		v20 = false
		ContextActionService:UnbindAction("RBXHotbarEquip")
	end
end
local function MakeVRRoundButton(p1, p2) --[[ MakeVRRoundButton | Line: 1653 | Upvalues: NewGui (copy) ]]
	local v1 = NewGui("ImageButton", p1)
	v1.Size = UDim2.new(0, 40, 0, 40)
	v1.Image = "rbxasset://textures/ui/Keyboard/close_button_background.png"
	local v2 = NewGui("ImageLabel", "Icon")
	v2.Size = UDim2.new(0.5, 0, 0.5, 0)
	v2.Position = UDim2.new(0.25, 0, 0.25, 0)
	v2.Image = p2
	v2.Parent = v1
	local v3 = NewGui("ImageLabel", "Selection")
	v3.Size = UDim2.new(0.9, 0, 0.9, 0)
	v3.Position = UDim2.new(0.05, 0, 0.05, 0)
	v3.Image = "rbxasset://textures/ui/Keyboard/close_button_selection.png"
	v1.SelectionImageObject = v3
	return v1, v2, v3
end
v22 = NewGui("Frame", "Backpack")
v22.Visible = false
v22.Parent = BackpackGui
v23 = NewGui("Frame", "Hotbar")
v23.Parent = v22
for i = 1, v42 do
	local v50 = v45(v23, i)
	v50.Frame.Visible = false
	if not v34 then
		v34 = v50
	end
end
local function toggleMenu(p1) --[[ toggleMenu | Line: 1692 | Upvalues: UIController (copy) ]]
	if UIController.IsGuiOpen(p1) then
		UIController.CloseGui(p1)
	else
		UIController.OpenGui(p1)
	end
end
v32.toggled:Connect(function() --[[ Line: 1700 | Upvalues: SFXModule (copy), UIController (copy) ]]
	SFXModule.PlaySFX("ClickSound")
	if UIController.IsGuiOpen("DailyRewardsFrame") then
		UIController.CloseGui("DailyRewardsFrame")
	else
		UIController.OpenGui("DailyRewardsFrame")
	end
end)
v33.toggled:Connect(function() --[[ Line: 1705 | Upvalues: SFXModule (copy), UIController (copy) ]]
	SFXModule.PlaySFX("ClickSound")
	if UIController.IsGuiOpen("PatchNotesFrame") then
		UIController.CloseGui("PatchNotesFrame")
	else
		UIController.OpenGui("PatchNotesFrame")
	end
end)
v31.toggled:Connect(function() --[[ Line: 1710 | Upvalues: SFXModule (copy), UIController (copy) ]]
	SFXModule.PlaySFX("ClickSound")
	if UIController.IsGuiOpen("SettingsFrame") then
		UIController.CloseGui("SettingsFrame")
	else
		UIController.OpenGui("SettingsFrame")
	end
end)
v29.selected:Connect(function() --[[ Line: 1728 | Upvalues: SFXModule (copy), GuiService (copy), t (copy) ]]
	SFXModule.PlaySFX("ClickSound")
	if GuiService.MenuIsOpen then
		return
	end
	t.OpenClose()
end)
v29.deselected:Connect(function() --[[ Line: 1734 | Upvalues: SFXModule (copy), v24 (ref), t (copy) ]]
	SFXModule.PlaySFX("ClickSound")
	if not v24.Visible then
		return
	end
	t.OpenClose()
end)
LeftBumperButton = NewGui("ImageLabel", "LeftBumper")
LeftBumperButton.Size = UDim2.new(0, 40, 0, 40)
LeftBumperButton.Position = UDim2.new(0, -LeftBumperButton.Size.X.Offset, 0.5, -LeftBumperButton.Size.Y.Offset / 2)
RightBumperButton = NewGui("ImageLabel", "RightBumper")
RightBumperButton.Size = UDim2.new(0, 40, 0, 40)
RightBumperButton.Position = UDim2.new(1, 0, 0.5, -RightBumperButton.Size.Y.Offset / 2)
v24 = NewGui("Frame", "Inventory")
local UICorner = Instance.new("UICorner")
UICorner.CornerRadius = script:GetAttribute("CornerRadius")
UICorner.Parent = v24
v24.BackgroundTransparency = v4
v24.BackgroundColor3 = v5
v24.Active = true
v24.Visible = false
v24.Parent = v22
v25 = NewGui("TextButton", "VRInventorySelector")
v25.Position = UDim2.new(0, 0, 0, 0)
v25.Size = UDim2.new(1, 0, 1, 0)
v25.BackgroundTransparency = 1
v25.Text = ""
v25.Parent = v24
local v51 = NewGui("TextLabel", "GroupTitle")
v51.Size = UDim2.new(0, 100, 0, 20)
v51.Position = UDim2.new(0, 8, 0, 8)
v51.Text = "All Items"
v51.TextXAlignment = Enum.TextXAlignment.Left
v51.FontFace = script:GetAttribute("LabelFont")
v51.TextSize = 18
v51.TextColor3 = script:GetAttribute("TextColor")
v51.BackgroundTransparency = 1
v51.ZIndex = 2
v51.Parent = v24
local v52 = NewGui("ImageLabel", "Selector")
v52.Size = UDim2.new(1, 0, 1, 0)
v52.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
v52.ScaleType = Enum.ScaleType.Slice
v52.SliceCenter = Rect.new(12, 12, 52, 52)
v52.Visible = false
v25.SelectionImageObject = v52
v25.MouseButton1Click:Connect(function() --[[ Line: 1788 ]]
	vrMoveSlotToInventory()
end)
v26 = NewGui("ScrollingFrame", "ScrollingFrame")
v26.Selectable = false
v26.CanvasSize = UDim2.new(0, 0, 0, 0)
v26.Parent = v24
v27 = NewGui("Frame", "UIGridFrame")
v27.Selectable = false
v27.Size = UDim2.new(1, -10, 1, 0)
v27.Position = UDim2.new(0, 5, 0, 0)
v27.Parent = v26
local UIGridLayout = Instance.new("UIGridLayout")
UIGridLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIGridLayout.CellSize = UDim2.new(0, v2, 0, v2)
UIGridLayout.CellPadding = UDim2.new(0, 5, 0, 5)
UIGridLayout.Parent = v27
local v53 = MakeVRRoundButton("ScrollUpButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v53.Size = UDim2.new(0, 34, 0, 34)
v53.Position = UDim2.new(0.5, -v53.Size.X.Offset / 2, 0, 43)
v53.Icon.Position = v53.Icon.Position - UDim2.new(0, 0, 0, 2)
v53.MouseButton1Click:Connect(function() --[[ Line: 1814 | Upvalues: v26 (ref), v2 (ref) ]]
	v26.CanvasPosition = Vector2.new(v26.CanvasPosition.X, (math.min(v26.CanvasSize.Y.Offset - v26.AbsoluteWindowSize.Y, (math.max(0, v26.CanvasPosition.Y - (v2 + 5))))))
end)
local v54 = MakeVRRoundButton("ScrollDownButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v54.Rotation = 180
v54.Icon.Position = v54.Icon.Position - UDim2.new(0, 0, 0, 2)
v54.Size = UDim2.new(0, 34, 0, 34)
v54.Position = UDim2.new(0.5, -v54.Size.X.Offset / 2, 1, -v54.Size.Y.Offset - 3)
v54.MouseButton1Click:Connect(function() --[[ Line: 1830 | Upvalues: v26 (ref), v2 (ref) ]]
	v26.CanvasPosition = Vector2.new(v26.CanvasPosition.X, (math.min(v26.CanvasSize.Y.Offset - v26.AbsoluteWindowSize.Y, (math.max(0, v26.CanvasPosition.Y + (v2 + 5))))))
end)
v26.Changed:Connect(function(p1) --[[ Line: 1841 | Upvalues: v26 (ref), v53 (ref), v54 (ref) ]]
	if p1 ~= "AbsoluteWindowSize" and (p1 ~= "CanvasPosition" and p1 ~= "CanvasSize") then
		return
	end
	local v1 = if v26.CanvasPosition.Y < v26.CanvasSize.Y.Offset - v26.AbsoluteWindowSize.Y then true else false
	v53.Visible = v26.CanvasPosition.Y ~= 0
	v54.Visible = v1
end)
UpdateBackpackLayout()
local function RecomputeFormFactor() --[[ RecomputeFormFactor | Line: 1858 | Upvalues: v21 (ref), UserInputService_2 (copy), v42 (ref), VREnabled (copy), v11 (copy), v10 (copy), v43 (ref) ]]
	v21 = UserInputService_2.TouchEnabled and workspace.CurrentCamera.ViewportSize.X < 1024
	v42 = VREnabled and v11 or (if v21 then 5 else v10)
	v43 = if VREnabled then 3 elseif v21 then 2 else 4
end
workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(function() --[[ Line: 1864 | Upvalues: v21 (ref), UserInputService_2 (copy), v42 (ref), VREnabled (copy), v11 (copy), v10 (copy), v43 (ref), UpdateBackpackLayout (copy) ]]
	v21 = UserInputService_2.TouchEnabled and workspace.CurrentCamera.ViewportSize.X < 1024
	v42 = VREnabled and v11 or (if v21 then 5 else v10)
	v43 = if VREnabled then 3 elseif v21 then 2 else 4
	UpdateBackpackLayout()
end)
local v55 = Utility:Create("Frame")
local t12 = {
	Name = "GamepadHintsFrame",
	BackgroundTransparency = 1,
	Visible = false
}
local v56 = UDim2.new
local Offset = v23.Size.X.Offset
t12.Size = v56(0, Offset, 0, if v19 then 95 else 60)
t12.Parent = v22
local v60 = v55(t12)
local function addGamepadHint(p1, p2, p3) --[[ addGamepadHint | Line: 1879 | Upvalues: Utility (copy), v60 (copy), v19 (copy) ]]
	local v1 = Utility:Create("Frame")({
		Name = "HintFrame",
		BackgroundTransparency = 1,
		Size = UDim2.new(1, 0, 1, -5),
		Position = UDim2.new(0, 0, 0, 0),
		Parent = v60
	})
	local v2 = Utility:Create("ImageLabel")
	local t = {
		Name = "HintImage",
		BackgroundTransparency = 1
	}
	t.Size = v19 and UDim2.new(0, 90, 0, 90) or UDim2.new(0, 60, 0, 60)
	t.Image = if v19 and p2 then p2 else p1
	t.Parent = v1
	v2(t)
	local v5 = Utility:Create("TextLabel")
	local t2 = {
		Name = "HintText",
		BackgroundTransparency = 1,
		TextWrapped = true
	}
	t2.Position = UDim2.new(0, if v19 then 100 else 70, 0, 0)
	t2.Size = UDim2.new(1, -(if v19 then 100 else 70), 1, 0)
	t2.Font = Enum.Font.SourceSansBold
	t2.FontSize = v19 and Enum.FontSize.Size36 or Enum.FontSize.Size24
	t2.Text = p3
	t2.TextColor3 = Color3.new(255/255, 255/255, 255/255)
	t2.TextXAlignment = Enum.TextXAlignment.Left
	t2.Parent = v1
	local v13 = v5(t2)
	Instance.new("UITextSizeConstraint", v13).MaxTextSize = v13.TextSize
end
local function resizeGamepadHintsFrame() --[[ resizeGamepadHintsFrame | Line: 1913 | Upvalues: v60 (copy), v23 (ref), v19 (copy), v24 (ref) ]]
	v60.Size = UDim2.new(v23.Size.X.Scale, v23.Size.X.Offset, 0, if v19 then 95 else 60)
	v60.Position = UDim2.new(v23.Position.X.Scale, v23.Position.X.Offset, v24.Position.Y.Scale, v24.Position.Y.Offset - v60.Size.Y.Offset)
	local v5 = v60:GetChildren()
	local sum = 0
	for i = 1, #v5 do
		v5[i].Size = UDim2.new(1, 0, 1, -5)
		v5[i].Position = UDim2.new(0, 0, 0, 0)
		sum = sum + (v5[i].HintText.Position.X.Offset + v5[i].HintText.TextBounds.X)
	end
	local v6 = (v60.AbsoluteSize.X - sum) / (#v5 - 1)
	for j = 1, #v5 do
		v5[j].Position = j == 1 and UDim2.new(0, 0, 0, 0) or UDim2.new(0, v5[j - 1].Position.X.Offset + v5[j - 1].Size.X.Offset + v6, 0, 0)
		v5[j].Size = UDim2.new(0, v5[j].HintText.Position.X.Offset + v5[j].HintText.TextBounds.X, 1, -5)
	end
end
addGamepadHint("rbxasset://textures/ui/Settings/Help/XButtonDark.png", "rbxasset://textures/ui/Settings/Help/XButtonDark@2x.png", "Remove From Hotbar")
addGamepadHint("rbxasset://textures/ui/Settings/Help/AButtonDark.png", "rbxasset://textures/ui/Settings/Help/AButtonDark@2x.png", "Select/Swap")
addGamepadHint("rbxasset://textures/ui/Settings/Help/BButtonDark.png", "rbxasset://textures/ui/Settings/Help/BButtonDark@2x.png", "Close Backpack")
local v61 = nil
local v62 = NewGui("Frame", "Search")
local UICorner_2 = Instance.new("UICorner")
UICorner_2.CornerRadius = UDim.new(0, 4)
UICorner_2.Parent = v62
v62.BackgroundColor3 = v12
v62.BackgroundTransparency = v14
v62.Size = UDim2.new(0, 190, 0, 30)
v62.Position = UDim2.new(1, -v62.Size.X.Offset - 5, 0, 5)
v62.Parent = v24
local UIStroke = Instance.new("UIStroke")
UIStroke.Color = Color3.fromRGB(73, 77, 90)
UIStroke.Thickness = 2
UIStroke.Parent = v62
local v63 = NewGui("TextBox", "TextBox")
v63.PlaceholderText = "Search"
v63.TextColor3 = v13
v63.ClearTextOnFocus = false
v63.FontSize = Enum.FontSize.Size24
v63.TextXAlignment = Enum.TextXAlignment.Left
v63.PlaceholderColor3 = script:GetAttribute("SearchPlaceholderColor")
local ImageLabel = Instance.new("ImageLabel")
ImageLabel.Parent = v62
ImageLabel.BackgroundTransparency = 1
ImageLabel.Size = UDim2.fromScale(1, 1)
ImageLabel.SizeConstraint = Enum.SizeConstraint.RelativeYY
ImageLabel.Parent = v62
ImageLabel.Image = "rbxassetid://16884179038"
ImageLabel.ImageRectSize = Vector2.new(108, 108)
ImageLabel.ImageRectOffset = Vector2.new(798, 660)
local UIPadding = Instance.new("UIPadding")
UIPadding.Parent = v63
UIPadding.PaddingLeft = UDim.new(0, 8)
v63.Size = v62.Size - UDim2.fromOffset(34, 0)
v63.Position = UDim2.new(0, 0 + (ImageLabel.AbsoluteSize.X + 30), 0, 0)
v63.Parent = v62
local v64 = NewGui("TextButton", "X")
local UICorner_3 = Instance.new("UICorner")
UICorner_3.CornerRadius = script:GetAttribute("CornerRadius")
UICorner_3.Parent = v64
v64.Font = Enum.Font.Arial
v64.Text = "x"
v64.ZIndex = 10
v64.TextColor3 = v7
v64.FontSize = Enum.FontSize.Size24
v64.TextYAlignment = Enum.TextYAlignment.Bottom
v64.BackgroundColor3 = v12
v64.BackgroundTransparency = 0
v64.Size = UDim2.new(0, v62.Size.Y.Offset - 10, 0, v62.Size.Y.Offset - 10)
v64.Position = UDim2.new(1, -v64.Size.X.Offset - 10, 0.5, -v64.Size.Y.Offset / 2)
v64.Visible = false
v64.BorderSizePixel = 0
v64.Parent = v62
local function search() --[[ search | Line: 2009 | Upvalues: v63 (copy), v42 (ref), t5 (copy), v24 (ref), v39 (ref), v27 (ref), v26 (ref), UpdateScrollingFrameCanvasSize (copy), v64 (copy) ]]
	local t = {}
	for v1 in v63.Text:gmatch("%S+") do
		t[v1:lower()] = true
	end
	local list = {}
	for i = v42 + 1, #t5 do
		local v2 = t5[i]
		table.insert(list, { v2, (v2:CheckTerms(t)) })
		v2.Frame.Visible = false
		v2.Frame.Parent = v24
	end
	table.sort(list, function(p1, p2) --[[ Line: 2024 ]]
		return p1[2] > p2[2]
	end)
	v39 = true
	local count = 0
	for i, v in ipairs(list) do
		local v3 = v[1]
		if v[2] > 0 then
			v3.Frame.Visible = true
			v3.Frame.Parent = v27
			v3.Frame.LayoutOrder = v42 + count
			count = count + 1
		end
	end
	v26.CanvasPosition = Vector2.new(0, 0)
	UpdateScrollingFrameCanvasSize()
	v64.ZIndex = 3
end
local function clearResults() --[[ clearResults | Line: 2046 | Upvalues: v64 (copy), v39 (ref), v42 (ref), t5 (copy), v27 (ref), v61 (ref), UpdateScrollingFrameCanvasSize (copy) ]]
	if v64.ZIndex > 0 then
		v39 = false
		for i = v42 + 1, #t5 do
			local v1 = t5[i]
			v1.Frame.LayoutOrder = v1.Index
			v1.Frame.Parent = v27
			v1.Frame.Visible = true
		end
		v64.ZIndex = 0
		if v61 then
			v61()
		end
	end
	UpdateScrollingFrameCanvasSize()
end
local function reset() --[[ reset | Line: 2063 | Upvalues: clearResults (copy), v63 (copy) ]]
	clearResults()
	v63.Text = ""
end
local function onChanged(p1) --[[ onChanged | Line: 2068 | Upvalues: v63 (copy), clearResults (copy), search (copy), v64 (copy) ]]
	if p1 ~= "Text" then
		return
	end
	local Text = v63.Text
	if Text == "" then
		clearResults()
	elseif Text ~= "Search" then
		search()
	end
	v64.Visible = false
end
local function focusLost(p1) --[[ focusLost | Line: 2080 | Upvalues: search (copy) ]]
	if not p1 then
		return
	end
	search()
end
v64.MouseButton1Click:Connect(reset)
v63.Changed:Connect(onChanged)
v63.FocusLost:Connect(focusLost)
t.StateChanged.Event:Connect(function(p1) --[[ Line: 2091 | Upvalues: clearResults (copy), v63 (copy), v24 (ref), v29 (copy) ]]
	if p1 then
		return
	end
	clearResults()
	v63.Text = ""
	if v24.Visible then
		return
	end
	v29:deselect()
end)
t7[Enum.KeyCode.Escape.Value] = function(p1) --[[ Line: 2100 | Upvalues: clearResults (copy), v63 (copy), v24 (ref), v29 (copy) ]]
	if p1 then
		clearResults()
		v63.Text = ""
		return
	end
	if not v24.Visible then
		return
	end
	v29:deselect()
end
local function detectGamepad(p1) --[[ detectGamepad | Line: 2108 | Upvalues: UserInputService_2 (copy), v62 (copy) ]]
	if p1 == Enum.UserInputType.Gamepad1 and not UserInputService_2.VREnabled then
		v62.Visible = false
	else
		v62.Visible = true
	end
end
UserInputService_2.LastInputTypeChanged:Connect(detectGamepad)
GuiService.MenuOpened:Connect(function() --[[ Line: 2118 | Upvalues: v24 (ref), v29 (copy) ]]
	if not v24.Visible then
		return
	end
	v29:deselect()
end)
local function f65(p1, p2, p3) --[[ Line: 2125 | Upvalues: GuiService (copy), v42 (ref), t5 (copy) ]]
	if p2 ~= Enum.UserInputState.Begin then
		return
	end
	if not GuiService.SelectedObject then
		return
	end
	for i = 1, v42 do
		if t5[i].Frame == GuiService.SelectedObject and t5[i].Tool then
			t5[i]:MoveToInventory()
			return
		end
	end
end
local function openClose() --[[ openClose | Line: 2141 | Upvalues: t8 (copy), v24 (ref), AdjustHotbarFrames (copy), v23 (ref), v42 (ref), t5 (copy), v40 (ref), t4 (copy), UserInputService_2 (copy), resizeGamepadHintsFrame (copy), v60 (copy), ContextActionService (copy), f65 (copy), t (copy) ]]
	if not next(t8) then
		v24.Visible = not v24.Visible
		local Visible = v24.Visible
		AdjustHotbarFrames()
		v23.Active = not v23.Active
		for i = 1, v42 do
			t5[i]:SetClickability(not Visible)
		end
	end
	if v24.Visible then
		if v40 then
			if t4[UserInputService_2:GetLastInputType()] then
				resizeGamepadHintsFrame()
				v60.Visible = not UserInputService_2.VREnabled
			end
			enableGamepadInventoryControl()
		end
	else
		if v40 then
			v60.Visible = false
		end
		disableGamepadInventoryControl()
	end
	if v24.Visible then
		ContextActionService:BindAction("RBXRemoveSlot", f65, false, Enum.KeyCode.ButtonX)
	else
		ContextActionService:UnbindAction("RBXRemoveSlot")
	end
	t.IsOpen = v24.Visible
	t.StateChanged:Fire(v24.Visible)
end
StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
t.OpenClose = openClose
while not LocalPlayer_2 do
	wait()
	LocalPlayer_2 = Players.LocalPlayer
end
LocalPlayer_2.CharacterAdded:Connect(OnCharacterAdded)
if LocalPlayer_2.Character then
	OnCharacterAdded(LocalPlayer_2.Character)
end
UserInputService_2.InputBegan:Connect(OnInputBegan)
UserInputService_2.TextBoxFocused:Connect(function() --[[ Line: 2204 | Upvalues: v38 (ref) ]]
	v38 = true
end)
UserInputService_2.TextBoxFocusReleased:Connect(function() --[[ Line: 2207 | Upvalues: v38 (ref) ]]
	v38 = false
end)
t7[Backspace] = function() --[[ Line: 2212 | Upvalues: EquipTool (copy) ]]
	EquipTool:FireServer(nil)
end
UserInputService_2.Changed:Connect(OnUISChanged)
OnUISChanged("KeyboardEnabled")
local v66, v67, v68, GroupButtonBar, v69, v70, v71, CustomPackAPI, v72, v73, v74, _
if not UserInputService_2:GetGamepadConnected(Enum.UserInputType.Gamepad1) then
	UserInputService_2.GamepadConnected:Connect(function(p1_2) --[[ Line: 2224 ]]
		if p1_2 ~= Enum.UserInputType.Gamepad1 then
			return
		end
		gamepadConnected()
	end)
	UserInputService_2.GamepadDisconnected:Connect(function(p1_2) --[[ Line: 2229 ]]
		if p1_2 ~= Enum.UserInputType.Gamepad1 then
			return
		end
		gamepadDisconnected()
	end)
	function t.SetBackpackEnabled(p1_2, p2_2) --[[ SetBackpackEnabled | Line: 2236 | Upvalues: v17 (ref) ]]
		v17 = p2_2
	end
	function t.IsOpened(p1_2) --[[ IsOpened | Line: 2240 | Upvalues: t (copy) ]]
		return t.IsOpen
	end
	function t.GetBackpackEnabled(p1_2) --[[ GetBackpackEnabled | Line: 2244 | Upvalues: v17 (ref) ]]
		return v17
	end
	function t.GetStateChangedEvent(p1_2) --[[ GetStateChangedEvent | Line: 2248 | Upvalues: t (copy) ]]
		return t.StateChanged
	end
	RunService.Heartbeat:Connect(function() --[[ Line: 2252 | Upvalues: OnIconChanged (copy), v17 (ref) ]]
		OnIconChanged(v17)
	end)
	v66 = {}
	v67 = {}
	v68 = {}
	GroupButtonBar = nil
	v69 = {}
	v70 = nil
	function t.SetToolGroup(p1_2, p2_2, p3_2) --[[ SetToolGroup | Line: 2282 | Upvalues: v66 (ref), v67 (ref) ]]
		local v1 = v66[p2_2]
		if v1 then
			local v2 = v67[v1]
			if v2 then
				for v3, v4 in v2 do
					if v4 == p2_2 then
						table.remove(v2, v3)
						break
					end
				end
			end
		end
		v66[p2_2] = p3_2
		if not v67[p3_2] then
			v67[p3_2] = {}
		end
		table.insert(v67[p3_2], p2_2)
		if not RefreshGroupButtons then
			return
		end
		RefreshGroupButtons()
	end
	function t.RemoveToolGroup(p1_2, p2_2) --[[ RemoveToolGroup | Line: 2307 | Upvalues: v66 (ref), v67 (ref) ]]
		local v1 = v66[p2_2]
		if v1 then
			local v2 = v67[v1]
			if v2 then
				for v3, v4 in v2 do
					if v4 == p2_2 then
						table.remove(v2, v3)
						break
					end
				end
			end
			v66[p2_2] = nil
		end
		if not RefreshGroupButtons then
			return
		end
		RefreshGroupButtons()
	end
	function t.ClearAllGroups(p1_2) --[[ ClearAllGroups | Line: 2326 | Upvalues: v66 (ref), v67 (ref) ]]
		v66 = {}
		v67 = {}
		if not RefreshGroupButtons then
			return
		end
		RefreshGroupButtons()
	end
	function t.GetToolGroup(p1_2, p2_2) --[[ GetToolGroup | Line: 2335 | Upvalues: v66 (ref) ]]
		return v66[p2_2]
	end
	function t.GetAllGroups(p1_2) --[[ GetAllGroups | Line: 2340 | Upvalues: v67 (ref) ]]
		local t2 = {}
		for v1, v2 in v67 do
			table.insert(t2, v1)
		end
		return t2
	end
	function t.GetToolsInGroup(p1_2, p2_2) --[[ GetToolsInGroup | Line: 2349 | Upvalues: v67 (ref) ]]
		return v67[p2_2] or {}
	end
	v71 = function(p1_2) --[[ FilterInventoryByGroup | Line: 2354 | Upvalues: v70 (ref), v42 (ref), t5 (copy), t (copy), UpdateScrollingFrameCanvasSize (copy) ]]
		v70 = p1_2
		for i = v42 + 1, #t5 do
			local v1 = t5[i]
			local Tool = v1.Tool
			local v2 = false
			if p1_2 then
				if Tool and t:GetToolGroup(Tool) == p1_2 then
					v2 = true
				end
			else
				v2 = true
			end
			v1.Frame.Visible = v2
		end
		UpdateScrollingFrameCanvasSize()
	end
	function RefreshGroupButtons() --[[ RefreshGroupButtons | Line: 2371 | Upvalues: GroupButtonBar (ref), v69 (ref), t (copy), v51 (copy), v4 (copy), v5 (copy), v70 (ref), v42 (ref), t5 (copy), UpdateScrollingFrameCanvasSize (copy), v68 (copy), v71 (copy) ]]
		if not GroupButtonBar then
			return
		end
		for v1, v2 in v69 do
			v2:Destroy()
		end
		v69 = {}
		local v3 = t:GetAllGroups()
		if #v3 == 0 then
			v51.Visible = false
			return
		end
		v51.Visible = true
		table.sort(v3, function(p1_2, p2_2) --[[ Line: 2388 ]]
			return tostring(p1_2) < tostring(p2_2)
		end)
		local v43 = 0
		local AllGroups = Instance.new("ImageButton")
		AllGroups.Name = "AllGroups"
		AllGroups.Size = UDim2.new(0, 48, 0, 48)
		AllGroups.Position = UDim2.new(0, 0, 0, v43)
		AllGroups.BackgroundTransparency = v4
		AllGroups.Image = "rbxassetid://12988755627"
		AllGroups.Parent = GroupButtonBar
		AllGroups.BackgroundColor3 = v5
		AllGroups.MouseButton1Click:Connect(function() --[[ Line: 2405 | Upvalues: v70 (ref), v42 (ref), t5 (ref), UpdateScrollingFrameCanvasSize (ref), v51 (ref) ]]
			v70 = nil
			for i = v42 + 1, #t5 do
				local v1 = t5[i]
				local Tool = v1.Tool
				v1.Frame.Visible = true
			end
			UpdateScrollingFrameCanvasSize()
			v51.Text = "All Items"
		end)
		local UICorner = Instance.new("UICorner")
		UICorner.CornerRadius = script:GetAttribute("CornerRadius")
		UICorner.Parent = AllGroups
		table.insert(v69, AllGroups)
		local v6 = v43 + 48 + 8
		for v7, v8 in v3 do
			local ImageButton = Instance.new("ImageButton")
			ImageButton.Name = "Group_" .. tostring(v8)
			ImageButton.Size = UDim2.new(0, 48, 0, 48)
			ImageButton.Position = UDim2.new(0, 0, 0, v6)
			ImageButton.BackgroundTransparency = v4
			ImageButton.BackgroundColor3 = v5
			ImageButton.Image = v68[v8] or ""
			ImageButton.Parent = GroupButtonBar
			local UIPadding = Instance.new("UIPadding")
			UIPadding.PaddingLeft = UDim.new(0, 8)
			UIPadding.PaddingRight = UDim.new(0, 8)
			UIPadding.PaddingTop = UDim.new(0, 8)
			UIPadding.PaddingBottom = UDim.new(0, 8)
			UIPadding.Parent = ImageButton
			ImageButton.MouseButton1Click:Connect(function() --[[ Line: 2431 | Upvalues: v71 (ref), v8 (copy), v51 (ref) ]]
				v71(v8)
				v51.Text = v8
			end)
			local UICorner_2 = Instance.new("UICorner")
			UICorner_2.CornerRadius = script:GetAttribute("CornerRadius")
			UICorner_2.Parent = ImageButton
			if not v68[v8] then
				local TextLabel = Instance.new("TextLabel")
				TextLabel.Parent = ImageButton
				TextLabel.Size = UDim2.new(1, 0, 1, 0)
				TextLabel.BackgroundTransparency = 1
				TextLabel.Text = v8
				TextLabel.TextColor3 = script:GetAttribute("TextColor")
				TextLabel.TextSize = 18
				TextLabel.FontFace = script:GetAttribute("LabelFont")
				TextLabel.TextXAlignment = Enum.TextXAlignment.Center
				TextLabel.TextYAlignment = Enum.TextYAlignment.Center
				TextLabel.TextTruncate = Enum.TextTruncate.AtEnd
				TextLabel.TextWrapped = true
			end
			table.insert(v69, ImageButton)
			v6 = v6 + 48 + 8
		end
	end
	function t.SetGroupIcon(p1_2, p2_2, p3_2) --[[ SetGroupIcon | Line: 2458 | Upvalues: v68 (copy) ]]
		v68[p2_2] = p3_2
		if not RefreshGroupButtons then
			return
		end
		RefreshGroupButtons()
	end
	function t.GetGroupIcon(p1_2, p2_2) --[[ GetGroupIcon | Line: 2466 | Upvalues: v68 (copy) ]]
		return v68[p2_2]
	end
	GroupButtonBar = Instance.new("ScrollingFrame")
	GroupButtonBar.Name = "GroupButtonBar"
	GroupButtonBar.CanvasSize = UDim2.new(0, 0, 0, 0)
	GroupButtonBar.AutomaticSize = Enum.AutomaticSize.Y
	GroupButtonBar.Size = UDim2.new(0, 56, 1, 0)
	GroupButtonBar.Position = UDim2.new(0, -56, 0, 0)
	GroupButtonBar.BackgroundTransparency = 1
	GroupButtonBar.Parent = v24
	RefreshGroupButtons()
	CustomPackAPI = Instance.new("BindableFunction")
	CustomPackAPI.Parent = game.ReplicatedStorage
	CustomPackAPI.Name = "CustomPackAPI"
	v72 = {
		SetBackpackEnabled = function(p1_2) --[[ SetBackpackEnabled | Line: 2487 | Upvalues: t (copy) ]]
			t:SetBackpackEnabled(p1_2)
		end,
		SetInventoryOpen = function(p1_2) --[[ SetInventoryOpen | Line: 2490 | Upvalues: t (copy) ]]
			t.IsOpen = p1_2
		end,
		ToggleInventoryOpen = function() --[[ ToggleInventoryOpen | Line: 2493 | Upvalues: t (copy) ]]
			t.OpenClose()
		end,
		IsInventoryOpen = function() --[[ IsInventoryOpen | Line: 2496 | Upvalues: t (copy) ]]
			return t:IsInventoryOpen()
		end,
		GetBackpackEnabled = function() --[[ GetBackpackEnabled | Line: 2499 | Upvalues: v17 (ref) ]]
			return v17
		end,
		GetStateChangedEvent = function() --[[ GetStateChangedEvent | Line: 2502 | Upvalues: t (copy) ]]
			return t:GetStateChangedEvent()
		end,
		GetSelectedSlotChangedEvent = function() --[[ GetSelectedSlotChangedEvent | Line: 2505 | Upvalues: t (copy) ]]
			return t.SelectedSlotChanged
		end,
		GetVersion = function() --[[ GetVersion | Line: 2508 | Upvalues: t (copy) ]]
			return t.Version
		end,
		SetGroupIcon = function(p1_2, p2_2) --[[ SetGroupIcon | Line: 2511 | Upvalues: t (copy) ]]
			t:SetGroupIcon(p1_2, p2_2)
		end,
		GetEquipSound = function() --[[ GetEquipSound | Line: 2514 | Upvalues: Sound (copy) ]]
			return Sound
		end,
		GetUnequipSound = function() --[[ GetUnequipSound | Line: 2517 | Upvalues: Sound_2 (copy) ]]
			return Sound_2
		end,
		GetSlot = function(p1_2) --[[ GetSlot | Line: 2520 | Upvalues: t5 (copy) ]]
			local v1 = t5[p1_2]
			return {
				SlotNumber = v1.Index,
				Tool = v1.Tool,
				IsEquipped = v1:IsEquipped()
			}
		end,
		GetAllSlots = function() --[[ GetAllSlots | Line: 2528 | Upvalues: t5 (copy) ]]
			local t2 = {}
			for k2, v in pairs(t5) do
				table.insert(t2, {
					SlotNumber = v.Index,
					Tool = v.Tool,
					IsEquipped = v:IsEquipped()
				})
			end
			return t2
		end,
		GetEquippedSlot = function() --[[ GetEquippedSlot | Line: 2539 | Upvalues: v15 (ref) ]]
			if v15 then
				return {
					SlotNumber = v15.Index,
					Tool = v15.Tool,
					IsEquipped = v15:IsEquipped()
				}
			else
				return nil
			end
		end,
		IsSlotEquipped = function(p1_2) --[[ IsSlotEquipped | Line: 2550 | Upvalues: t5 (copy) ]]
			return t5[p1_2]:IsEquipped()
		end,
		GetGroupIcon = function(p1_2) --[[ GetGroupIcon | Line: 2553 | Upvalues: t (copy) ]]
			return t:GetGroupIcon(p1_2)
		end,
		GetToolsInGroup = function(p1_2) --[[ GetToolsInGroup | Line: 2556 | Upvalues: t (copy) ]]
			return t:GetToolsInGroup(p1_2)
		end,
		GetAllGroups = function() --[[ GetAllGroups | Line: 2559 | Upvalues: t (copy) ]]
			return t:GetAllGroups()
		end,
		GetToolGroup = function(p1_2) --[[ GetToolGroup | Line: 2562 | Upvalues: t (copy) ]]
			return t:GetToolGroup(p1_2)
		end,
		RemoveToolGroup = function(p1_2) --[[ RemoveToolGroup | Line: 2565 | Upvalues: t (copy) ]]
			t:RemoveToolGroup(p1_2)
		end,
		SetToolGroup = function(p1_2, p2_2) --[[ SetToolGroup | Line: 2568 | Upvalues: t (copy) ]]
			t:SetToolGroup(p1_2, p2_2)
		end,
		SwapSlots = function(p1_2, p2_2) --[[ SwapSlots | Line: 2571 | Upvalues: t5 (copy) ]]
			if p1_2 == p2_2 then
				return
			end
			local v1 = t5[p1_2]
			local v2 = t5[p2_2]
			if not (v1 and v2) then
				return
			end
			if not (v1.Tool or v2.Tool) then
				return
			end
			if v1.Tool then
				v1:Swap(v2)
			else
				v2:Swap(v1)
			end
		end,
		LockSlot = function(p1_2, p2_2) --[[ LockSlot | Line: 2589 | Upvalues: t9 (copy), t5 (copy) ]]
			t9[p1_2] = p2_2 or "You can\'t do this right now"
			local v1 = t5[p1_2]
			if not (v1 and v1.UpdateDraggable) then
				return
			end
			v1:UpdateDraggable()
		end,
		UnlockSlot = function(p1_2) --[[ UnlockSlot | Line: 2596 | Upvalues: t9 (copy), t5 (copy) ]]
			t9[p1_2] = nil
			local v1 = t5[p1_2]
			if not (v1 and v1.UpdateDraggable) then
				return
			end
			v1:UpdateDraggable()
		end,
		IsSlotLocked = function(p1_2) --[[ IsSlotLocked | Line: 2603 | Upvalues: t9 (copy) ]]
			return t9[p1_2] ~= nil
		end
	}
	function CustomPackAPI.OnInvoke(p1_2, p2_2) --[[ Line: 2607 | Upvalues: v72 (copy) ]]
		assert(v72[p1_2], ("API Function \"%s\" doesn\'t exist."):format((tostring(p1_2))))
		if not v72[p1_2] then
			return
		end
		return v72[p1_2](table.unpack(if p2_2 then p2_2 else {}))
	end
	v73 = require(script.InventoryTabs)
	v74 = "All"
	_ = function(p1_2) --[[ categoryFor | Line: 2625 ]]
		if not p1_2 then
			return "Gear"
		end
		local v1 = p1_2:GetAttribute("InventoryCategory")
		if typeof(v1) == "string" then
			return v1
		else
			return "Gear"
		end
	end
	v61 = function() --[[ Line: 2636 | Upvalues: v39 (ref), v42 (ref), t5 (copy), v74 (ref), UpdateScrollingFrameCanvasSize (copy) ]]
		if v39 then
			return
		end
		for i = v42 + 1, #t5 do
			local v3 = t5[i]
			if v3 and v3.Frame then
				local v1, v2
				if v3.Tool then
					if v74 == "All" then
						v1 = true
					else
						local Tool = v3.Tool
						if Tool then
							local v4 = Tool:GetAttribute("InventoryCategory")
							v2 = if typeof(v4) == "string" then v4 else "Gear"
						else
							v2 = "Gear"
						end
						v1 = if v2 == v74 then true else false
					end
					v3.Frame.Visible = v1
					continue
				end
				v3.Frame.Visible = false
			end
		end
		UpdateScrollingFrameCanvasSize()
	end
	v73.new({
		Parent = v24,
		Categories = { "All", "Seeds", "Gear", "Pets" },
		Initial = v74,
		AnchorPoint = Vector2.new(1, 0),
		Position = UDim2.new(0, -10, 0, 0),
		Size = UDim2.new(0, 80, 1, 0),
		Style = {
			Orientation = "Vertical",
			BackgroundColor = v12,
			TextColor = v13,
			TextSize = v3
		},
		OnChanged = function(p1_2) --[[ OnChanged | Line: 2667 | Upvalues: v74 (ref), v61 (ref) ]]
			v74 = p1_2
			v61()
		end
	})
	v27.ChildAdded:Connect(function(p1_2) --[[ Line: 2673 | Upvalues: v61 (ref) ]]
		if not (p1_2:IsA("Frame") or (p1_2:IsA("ImageButton") or p1_2:IsA("TextButton"))) then
			return
		end
		v61()
	end)
	t.StateChanged.Event:Connect(function(p1_2) --[[ Line: 2679 | Upvalues: v61 (ref) ]]
		if not p1_2 then
			return
		end
		v61()
	end)
	return t
end
gamepadConnected()
UserInputService_2.GamepadConnected:Connect(function(p1_2) --[[ Line: 2224 ]]
	if p1_2 ~= Enum.UserInputType.Gamepad1 then
		return
	end
	gamepadConnected()
end)
UserInputService_2.GamepadDisconnected:Connect(function(p1_2) --[[ Line: 2229 ]]
	if p1_2 ~= Enum.UserInputType.Gamepad1 then
		return
	end
	gamepadDisconnected()
end)
function t.SetBackpackEnabled(p1_2, p2_2) --[[ SetBackpackEnabled | Line: 2236 | Upvalues: v17 (ref) ]]
	v17 = p2_2
end
function t.IsOpened(p1_2) --[[ IsOpened | Line: 2240 | Upvalues: t (copy) ]]
	return t.IsOpen
end
function t.GetBackpackEnabled(p1_2) --[[ GetBackpackEnabled | Line: 2244 | Upvalues: v17 (ref) ]]
	return v17
end
function t.GetStateChangedEvent(p1_2) --[[ GetStateChangedEvent | Line: 2248 | Upvalues: t (copy) ]]
	return t.StateChanged
end
RunService.Heartbeat:Connect(function() --[[ Line: 2252 | Upvalues: OnIconChanged (copy), v17 (ref) ]]
	OnIconChanged(v17)
end)
v66 = {}
v67 = {}
v68 = {}
GroupButtonBar = nil
v69 = {}
v70 = nil
function t.SetToolGroup(p1_2, p2_2, p3_2) --[[ SetToolGroup | Line: 2282 | Upvalues: v66 (ref), v67 (ref) ]]
	local v1 = v66[p2_2]
	if v1 then
		local v2 = v67[v1]
		if v2 then
			for v3, v4 in v2 do
				if v4 == p2_2 then
					table.remove(v2, v3)
					break
				end
			end
		end
	end
	v66[p2_2] = p3_2
	if not v67[p3_2] then
		v67[p3_2] = {}
	end
	table.insert(v67[p3_2], p2_2)
	if not RefreshGroupButtons then
		return
	end
	RefreshGroupButtons()
end
function t.RemoveToolGroup(p1_2, p2_2) --[[ RemoveToolGroup | Line: 2307 | Upvalues: v66 (ref), v67 (ref) ]]
	local v1 = v66[p2_2]
	if v1 then
		local v2 = v67[v1]
		if v2 then
			for v3, v4 in v2 do
				if v4 == p2_2 then
					table.remove(v2, v3)
					break
				end
			end
		end
		v66[p2_2] = nil
	end
	if not RefreshGroupButtons then
		return
	end
	RefreshGroupButtons()
end
function t.ClearAllGroups(p1_2) --[[ ClearAllGroups | Line: 2326 | Upvalues: v66 (ref), v67 (ref) ]]
	v66 = {}
	v67 = {}
	if not RefreshGroupButtons then
		return
	end
	RefreshGroupButtons()
end
function t.GetToolGroup(p1_2, p2_2) --[[ GetToolGroup | Line: 2335 | Upvalues: v66 (ref) ]]
	return v66[p2_2]
end
function t.GetAllGroups(p1_2) --[[ GetAllGroups | Line: 2340 | Upvalues: v67 (ref) ]]
	local t2 = {}
	for v1, v2 in v67 do
		table.insert(t2, v1)
	end
	return t2
end
function t.GetToolsInGroup(p1_2, p2_2) --[[ GetToolsInGroup | Line: 2349 | Upvalues: v67 (ref) ]]
	return v67[p2_2] or {}
end
v71 = function(p1_2) --[[ FilterInventoryByGroup | Line: 2354 | Upvalues: v70 (ref), v42 (ref), t5 (copy), t (copy), UpdateScrollingFrameCanvasSize (copy) ]]
	v70 = p1_2
	for i = v42 + 1, #t5 do
		local v1 = t5[i]
		local Tool = v1.Tool
		local v2 = false
		if p1_2 then
			if Tool and t:GetToolGroup(Tool) == p1_2 then
				v2 = true
			end
		else
			v2 = true
		end
		v1.Frame.Visible = v2
	end
	UpdateScrollingFrameCanvasSize()
end
function RefreshGroupButtons() --[[ RefreshGroupButtons | Line: 2371 | Upvalues: GroupButtonBar (ref), v69 (ref), t (copy), v51 (copy), v4 (copy), v5 (copy), v70 (ref), v42 (ref), t5 (copy), UpdateScrollingFrameCanvasSize (copy), v68 (copy), v71 (copy) ]]
	if not GroupButtonBar then
		return
	end
	for v1, v2 in v69 do
		v2:Destroy()
	end
	v69 = {}
	local v3 = t:GetAllGroups()
	if #v3 == 0 then
		v51.Visible = false
		return
	end
	v51.Visible = true
	table.sort(v3, function(p1_2, p2_2) --[[ Line: 2388 ]]
		return tostring(p1_2) < tostring(p2_2)
	end)
	local v43 = 0
	local AllGroups = Instance.new("ImageButton")
	AllGroups.Name = "AllGroups"
	AllGroups.Size = UDim2.new(0, 48, 0, 48)
	AllGroups.Position = UDim2.new(0, 0, 0, v43)
	AllGroups.BackgroundTransparency = v4
	AllGroups.Image = "rbxassetid://12988755627"
	AllGroups.Parent = GroupButtonBar
	AllGroups.BackgroundColor3 = v5
	AllGroups.MouseButton1Click:Connect(function() --[[ Line: 2405 | Upvalues: v70 (ref), v42 (ref), t5 (ref), UpdateScrollingFrameCanvasSize (ref), v51 (ref) ]]
		v70 = nil
		for i = v42 + 1, #t5 do
			local v1 = t5[i]
			local Tool = v1.Tool
			v1.Frame.Visible = true
		end
		UpdateScrollingFrameCanvasSize()
		v51.Text = "All Items"
	end)
	local UICorner = Instance.new("UICorner")
	UICorner.CornerRadius = script:GetAttribute("CornerRadius")
	UICorner.Parent = AllGroups
	table.insert(v69, AllGroups)
	local v6 = v43 + 48 + 8
	for v7, v8 in v3 do
		local ImageButton = Instance.new("ImageButton")
		ImageButton.Name = "Group_" .. tostring(v8)
		ImageButton.Size = UDim2.new(0, 48, 0, 48)
		ImageButton.Position = UDim2.new(0, 0, 0, v6)
		ImageButton.BackgroundTransparency = v4
		ImageButton.BackgroundColor3 = v5
		ImageButton.Image = v68[v8] or ""
		ImageButton.Parent = GroupButtonBar
		local UIPadding = Instance.new("UIPadding")
		UIPadding.PaddingLeft = UDim.new(0, 8)
		UIPadding.PaddingRight = UDim.new(0, 8)
		UIPadding.PaddingTop = UDim.new(0, 8)
		UIPadding.PaddingBottom = UDim.new(0, 8)
		UIPadding.Parent = ImageButton
		ImageButton.MouseButton1Click:Connect(function() --[[ Line: 2431 | Upvalues: v71 (ref), v8 (copy), v51 (ref) ]]
			v71(v8)
			v51.Text = v8
		end)
		local UICorner_2 = Instance.new("UICorner")
		UICorner_2.CornerRadius = script:GetAttribute("CornerRadius")
		UICorner_2.Parent = ImageButton
		if not v68[v8] then
			local TextLabel = Instance.new("TextLabel")
			TextLabel.Parent = ImageButton
			TextLabel.Size = UDim2.new(1, 0, 1, 0)
			TextLabel.BackgroundTransparency = 1
			TextLabel.Text = v8
			TextLabel.TextColor3 = script:GetAttribute("TextColor")
			TextLabel.TextSize = 18
			TextLabel.FontFace = script:GetAttribute("LabelFont")
			TextLabel.TextXAlignment = Enum.TextXAlignment.Center
			TextLabel.TextYAlignment = Enum.TextYAlignment.Center
			TextLabel.TextTruncate = Enum.TextTruncate.AtEnd
			TextLabel.TextWrapped = true
		end
		table.insert(v69, ImageButton)
		v6 = v6 + 48 + 8
	end
end
function t.SetGroupIcon(p1_2, p2_2, p3_2) --[[ SetGroupIcon | Line: 2458 | Upvalues: v68 (copy) ]]
	v68[p2_2] = p3_2
	if not RefreshGroupButtons then
		return
	end
	RefreshGroupButtons()
end
function t.GetGroupIcon(p1_2, p2_2) --[[ GetGroupIcon | Line: 2466 | Upvalues: v68 (copy) ]]
	return v68[p2_2]
end
GroupButtonBar = Instance.new("ScrollingFrame")
GroupButtonBar.Name = "GroupButtonBar"
GroupButtonBar.CanvasSize = UDim2.new(0, 0, 0, 0)
GroupButtonBar.AutomaticSize = Enum.AutomaticSize.Y
GroupButtonBar.Size = UDim2.new(0, 56, 1, 0)
GroupButtonBar.Position = UDim2.new(0, -56, 0, 0)
GroupButtonBar.BackgroundTransparency = 1
GroupButtonBar.Parent = v24
RefreshGroupButtons()
CustomPackAPI = Instance.new("BindableFunction")
CustomPackAPI.Parent = game.ReplicatedStorage
CustomPackAPI.Name = "CustomPackAPI"
v72 = {
	SetBackpackEnabled = function(p1_2) --[[ SetBackpackEnabled | Line: 2487 | Upvalues: t (copy) ]]
		t:SetBackpackEnabled(p1_2)
	end,
	SetInventoryOpen = function(p1_2) --[[ SetInventoryOpen | Line: 2490 | Upvalues: t (copy) ]]
		t.IsOpen = p1_2
	end,
	ToggleInventoryOpen = function() --[[ ToggleInventoryOpen | Line: 2493 | Upvalues: t (copy) ]]
		t.OpenClose()
	end,
	IsInventoryOpen = function() --[[ IsInventoryOpen | Line: 2496 | Upvalues: t (copy) ]]
		return t:IsInventoryOpen()
	end,
	GetBackpackEnabled = function() --[[ GetBackpackEnabled | Line: 2499 | Upvalues: v17 (ref) ]]
		return v17
	end,
	GetStateChangedEvent = function() --[[ GetStateChangedEvent | Line: 2502 | Upvalues: t (copy) ]]
		return t:GetStateChangedEvent()
	end,
	GetSelectedSlotChangedEvent = function() --[[ GetSelectedSlotChangedEvent | Line: 2505 | Upvalues: t (copy) ]]
		return t.SelectedSlotChanged
	end,
	GetVersion = function() --[[ GetVersion | Line: 2508 | Upvalues: t (copy) ]]
		return t.Version
	end,
	SetGroupIcon = function(p1_2, p2_2) --[[ SetGroupIcon | Line: 2511 | Upvalues: t (copy) ]]
		t:SetGroupIcon(p1_2, p2_2)
	end,
	GetEquipSound = function() --[[ GetEquipSound | Line: 2514 | Upvalues: Sound (copy) ]]
		return Sound
	end,
	GetUnequipSound = function() --[[ GetUnequipSound | Line: 2517 | Upvalues: Sound_2 (copy) ]]
		return Sound_2
	end,
	GetSlot = function(p1_2) --[[ GetSlot | Line: 2520 | Upvalues: t5 (copy) ]]
		local v1 = t5[p1_2]
		return {
			SlotNumber = v1.Index,
			Tool = v1.Tool,
			IsEquipped = v1:IsEquipped()
		}
	end,
	GetAllSlots = function() --[[ GetAllSlots | Line: 2528 | Upvalues: t5 (copy) ]]
		local t2 = {}
		for k2, v in pairs(t5) do
			table.insert(t2, {
				SlotNumber = v.Index,
				Tool = v.Tool,
				IsEquipped = v:IsEquipped()
			})
		end
		return t2
	end,
	GetEquippedSlot = function() --[[ GetEquippedSlot | Line: 2539 | Upvalues: v15 (ref) ]]
		if v15 then
			return {
				SlotNumber = v15.Index,
				Tool = v15.Tool,
				IsEquipped = v15:IsEquipped()
			}
		else
			return nil
		end
	end,
	IsSlotEquipped = function(p1_2) --[[ IsSlotEquipped | Line: 2550 | Upvalues: t5 (copy) ]]
		return t5[p1_2]:IsEquipped()
	end,
	GetGroupIcon = function(p1_2) --[[ GetGroupIcon | Line: 2553 | Upvalues: t (copy) ]]
		return t:GetGroupIcon(p1_2)
	end,
	GetToolsInGroup = function(p1_2) --[[ GetToolsInGroup | Line: 2556 | Upvalues: t (copy) ]]
		return t:GetToolsInGroup(p1_2)
	end,
	GetAllGroups = function() --[[ GetAllGroups | Line: 2559 | Upvalues: t (copy) ]]
		return t:GetAllGroups()
	end,
	GetToolGroup = function(p1_2) --[[ GetToolGroup | Line: 2562 | Upvalues: t (copy) ]]
		return t:GetToolGroup(p1_2)
	end,
	RemoveToolGroup = function(p1_2) --[[ RemoveToolGroup | Line: 2565 | Upvalues: t (copy) ]]
		t:RemoveToolGroup(p1_2)
	end,
	SetToolGroup = function(p1_2, p2_2) --[[ SetToolGroup | Line: 2568 | Upvalues: t (copy) ]]
		t:SetToolGroup(p1_2, p2_2)
	end,
	SwapSlots = function(p1_2, p2_2) --[[ SwapSlots | Line: 2571 | Upvalues: t5 (copy) ]]
		if p1_2 == p2_2 then
			return
		end
		local v1 = t5[p1_2]
		local v2 = t5[p2_2]
		if not (v1 and v2) then
			return
		end
		if not (v1.Tool or v2.Tool) then
			return
		end
		if v1.Tool then
			v1:Swap(v2)
		else
			v2:Swap(v1)
		end
	end,
	LockSlot = function(p1_2, p2_2) --[[ LockSlot | Line: 2589 | Upvalues: t9 (copy), t5 (copy) ]]
		t9[p1_2] = p2_2 or "You can\'t do this right now"
		local v1 = t5[p1_2]
		if not (v1 and v1.UpdateDraggable) then
			return
		end
		v1:UpdateDraggable()
	end,
	UnlockSlot = function(p1_2) --[[ UnlockSlot | Line: 2596 | Upvalues: t9 (copy), t5 (copy) ]]
		t9[p1_2] = nil
		local v1 = t5[p1_2]
		if not (v1 and v1.UpdateDraggable) then
			return
		end
		v1:UpdateDraggable()
	end,
	IsSlotLocked = function(p1_2) --[[ IsSlotLocked | Line: 2603 | Upvalues: t9 (copy) ]]
		return t9[p1_2] ~= nil
	end
}
function CustomPackAPI.OnInvoke(p1_2, p2_2) --[[ Line: 2607 | Upvalues: v72 (copy) ]]
	assert(v72[p1_2], ("API Function \"%s\" doesn\'t exist."):format((tostring(p1_2))))
	if not v72[p1_2] then
		return
	end
	return v72[p1_2](table.unpack(if p2_2 then p2_2 else {}))
end
v73 = require(script.InventoryTabs)
v74 = "All"
_ = function(p1_2) --[[ categoryFor | Line: 2625 ]]
	if not p1_2 then
		return "Gear"
	end
	local v1 = p1_2:GetAttribute("InventoryCategory")
	if typeof(v1) == "string" then
		return v1
	else
		return "Gear"
	end
end
v61 = function() --[[ Line: 2636 | Upvalues: v39 (ref), v42 (ref), t5 (copy), v74 (ref), UpdateScrollingFrameCanvasSize (copy) ]]
	if v39 then
		return
	end
	for i = v42 + 1, #t5 do
		local v3 = t5[i]
		if v3 and v3.Frame then
			local v1, v2
			if v3.Tool then
				if v74 == "All" then
					v1 = true
				else
					local Tool = v3.Tool
					if Tool then
						local v4 = Tool:GetAttribute("InventoryCategory")
						v2 = if typeof(v4) == "string" then v4 else "Gear"
					else
						v2 = "Gear"
					end
					v1 = if v2 == v74 then true else false
				end
				v3.Frame.Visible = v1
				continue
			end
			v3.Frame.Visible = false
		end
	end
	UpdateScrollingFrameCanvasSize()
end
v73.new({
	Parent = v24,
	Categories = { "All", "Seeds", "Gear", "Pets" },
	Initial = v74,
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(0, -10, 0, 0),
	Size = UDim2.new(0, 80, 1, 0),
	Style = {
		Orientation = "Vertical",
		BackgroundColor = v12,
		TextColor = v13,
		TextSize = v3
	},
	OnChanged = function(p1_2) --[[ OnChanged | Line: 2667 | Upvalues: v74 (ref), v61 (ref) ]]
		v74 = p1_2
		v61()
	end
})
v27.ChildAdded:Connect(function(p1_2) --[[ Line: 2673 | Upvalues: v61 (ref) ]]
	if not (p1_2:IsA("Frame") or (p1_2:IsA("ImageButton") or p1_2:IsA("TextButton"))) then
		return
	end
	v61()
end)
t.StateChanged.Event:Connect(function(p1_2) --[[ Line: 2679 | Upvalues: v61 (ref) ]]
	if not p1_2 then
		return
	end
	v61()
end)
return t