-- Path: Players.Asuneteric.PlayerScripts.ClientLoader.Handlers.FriendOTronClient
-- Class: ModuleScript

-- https://lua.expert/
print("[FriendOTron] CLIENT MODULE REQUIRED")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")
local CollectionService = game:GetService("CollectionService")
local FriendOTronConfig = require(ReplicatedStorage.Shared.FriendOTronConfig)
local Registry = require(ReplicatedStorage.Shared.Registry)
local SharedUtils = require(ReplicatedStorage.Shared.SharedUtils)
local SFXModule = require(ReplicatedStorage.Shared.SFXModule)
local ConfettiHandler = require(ReplicatedStorage.Shared.VFX.ConfettiHandler)
local DataAggregation = require(script.Parent.Parent.Modules.DataAggregation)
local FriendOTron = ReplicatedStorage.Remotes:WaitForChild("FriendOTron")
local InsertSeed = FriendOTron:WaitForChild("InsertSeed")
local PullLever = FriendOTron:WaitForChild("PullLever")
local ChamberSync = FriendOTron:WaitForChild("ChamberSync")
local PactComplete = FriendOTron:WaitForChild("PactComplete")
local RemoveSeed = FriendOTron:WaitForChild("RemoveSeed")
local CooldownSync = FriendOTron:WaitForChild("CooldownSync")
local LocalPlayer = Players.LocalPlayer
local t = {}
local t2 = {}
local t3 = {}
local t4 = {}
local t5 = {
	Blue = {},
	Purple = {}
}
local v1 = false
local function chosenDeposit(p1) --[[ chosenDeposit | Line: 45 | Upvalues: t4 (copy), t5 (copy) ]]
	local v1 = t4[p1]
	if v1 then
		return v1
	end
	for k, v in pairs(t5[p1]) do
		return v
	end
	return nil
end
local function setChamberPromptMode(p1) --[[ setChamberPromptMode | Line: 54 | Upvalues: t2 (copy), t4 (copy), t3 (copy) ]]
	local v1 = t2[p1]
	if not v1 then
		return
	end
	if t4[p1] then
		v1.ActionText = "Remove Seed"
		return
	end
	v1.ActionText = t3[p1] or v1.ActionText
end
local function safePlaySfx(p1, p2) --[[ safePlaySfx | Line: 65 | Upvalues: SFXModule (copy) ]]
	pcall(function() --[[ Line: 66 | Upvalues: p2 (copy), SFXModule (ref), p1 (copy) ]]
		if p2 then
			SFXModule.PlaySFX(p1, false, p2, 1)
		else
			SFXModule.PlaySFX(p1)
		end
	end)
end
local function findMachine() --[[ findMachine | Line: 72 | Upvalues: Workspace (copy), FriendOTronConfig (copy) ]]
	local v1 = Workspace
	for i, v in ipairs(FriendOTronConfig.MachinePath) do
		local v2 = if v1 then v1:FindFirstChild(v) else v1
		if not v2 then
			return nil
		end
		v1 = v2
	end
	if v1 and v1:IsA("Model") then
		return v1
	else
		return nil
	end
end
local function getChamberPart(p1, p2) --[[ getChamberPart | Line: 82 | Upvalues: FriendOTronConfig (copy) ]]
	local v2 = p1:FindFirstChild(p2 == "Blue" and FriendOTronConfig.BlueChamberPart or FriendOTronConfig.PurpleChamberPart)
	if v2 and v2:IsA("BasePart") then
		return v2
	else
		return nil
	end
end
local function getSeedAnchorPos(p1) --[[ getSeedAnchorPos | Line: 89 | Upvalues: FriendOTronConfig (copy) ]]
	local v1 = p1:FindFirstChild(FriendOTronConfig.SeedAnchorName)
	if v1 and v1:IsA("Attachment") then
		return v1.WorldPosition
	else
		return p1.Position
	end
end
local function getRollAnchorPos(p1) --[[ getRollAnchorPos | Line: 96 | Upvalues: FriendOTronConfig (copy) ]]
	local v1 = p1:FindFirstChild(FriendOTronConfig.RollGlassPart)
	if not (v1 and v1:IsA("BasePart")) then
		return Vector3.new(0, 0, 0), nil
	end
	local v2 = v1:FindFirstChild(FriendOTronConfig.RollAnchorName)
	if v2 and v2:IsA("Attachment") then
		return v2.WorldPosition, v1
	else
		return v1.Position, v1
	end
end
local function getRollAnchorAttachment(p1) --[[ getRollAnchorAttachment | Line: 104 | Upvalues: FriendOTronConfig (copy) ]]
	local v1 = p1:FindFirstChild(FriendOTronConfig.RollGlassPart)
	if not (v1 and v1:IsA("BasePart")) then
		return nil
	end
	local v2 = v1:FindFirstChild(FriendOTronConfig.RollAnchorName)
	if v2 and v2:IsA("Attachment") then
		return v2
	else
		return v1
	end
end
local function clearChamberVisual(p1) --[[ clearChamberVisual | Line: 112 | Upvalues: t (copy) ]]
	local v1 = t[p1]
	if not (v1 and v1.Parent) then
		t[p1] = nil
		return
	end
	v1:Destroy()
	t[p1] = nil
end
local function setChamberVisual(p1, p2) --[[ setChamberVisual | Line: 118 | Upvalues: t (copy), findMachine (copy), FriendOTronConfig (copy), ReplicatedStorage (copy) ]]
	local v1 = t[p1]
	if v1 and v1.Parent then
		v1:Destroy()
	end
	t[p1] = nil
	local v2 = findMachine()
	if not v2 then
		return
	end
	local v4 = v2:FindFirstChild(p1 == "Blue" and FriendOTronConfig.BlueChamberPart or FriendOTronConfig.PurpleChamberPart)
	local v5 = if v4 and v4:IsA("BasePart") then v4 else nil
	if not v5 then
		return
	end
	local Assets = ReplicatedStorage:FindFirstChild("Assets")
	local v6 = (if Assets then Assets:FindFirstChild("Seeds") else Assets) and v6:FindFirstChild(p2)
	if not v6 then
		return
	end
	local Model = Instance.new("Model")
	Model.Name = "FriendOTronSeedVisual_" .. p1
	local v7 = v6:Clone()
	if v7:IsA("Tool") then
		for i, v in ipairs(v7:GetChildren()) do
			v.Parent = Model
		end
		v7:Destroy()
	elseif v7:IsA("Model") then
		for i, v in ipairs(v7:GetChildren()) do
			v.Parent = Model
		end
		v7:Destroy()
	else
		v7.Parent = Model
	end
	local v8 = nil
	for i, v in ipairs(Model:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Anchored = true
			v.CanCollide = false
			v.CanQuery = false
			v.CanTouch = false
			if not v8 or v.Name == "Handle" then
				v8 = v
			end
		end
	end
	if not v8 then
		Model:Destroy()
		return
	end
	Model.PrimaryPart = v8
	local v9 = CFrame.new
	local v10 = v5:FindFirstChild(FriendOTronConfig.SeedAnchorName)
	Model:PivotTo(v9(if v10 and v10:IsA("Attachment") then v10.WorldPosition else v5.Position))
	Model:ScaleTo(2)
	Model.Parent = v5.Parent
	t[p1] = Model
end
local function refreshChamberVisual(p1) --[[ refreshChamberVisual | Line: 174 | Upvalues: t4 (copy), t5 (copy), setChamberVisual (copy), t (copy), t2 (copy), t3 (copy) ]]
	local v1 = t4[p1]
	local v2
	if v1 then
		v2 = v1
	else
		v2 = nil
		for k, v in pairs(t5[p1]) do
			v2 = v
			break
		end
	end
	if v2 then
		setChamberVisual(p1, v2)
	else
		local v3 = t[p1]
		if v3 and v3.Parent then
			v3:Destroy()
		end
		t[p1] = nil
	end
	local v4 = t2[p1]
	if not v4 then
		return
	end
	if t4[p1] then
		v4.ActionText = "Remove Seed"
		return
	end
	v4.ActionText = t3[p1] or v4.ActionText
end
ChamberSync.OnClientEvent:Connect(function(p1, p2) --[[ Line: 184 | Upvalues: t4 (copy), t5 (copy), setChamberVisual (copy), t (copy), t2 (copy), t3 (copy), LocalPlayer (copy) ]]
	if p2 then
		if type(p2) ~= "table" then
			return
		end
		local v1 = if p2.DepositorUserId == LocalPlayer.UserId then true else false
		if p2.Cleared then
			if v1 then
				t4[p1] = nil
			elseif p2.DepositorUserId then
				t5[p1][p2.DepositorUserId] = nil
			end
		else
			if not p2.SeedName then
				return
			end
			if v1 then
				t4[p1] = p2.SeedName
			elseif p2.DepositorUserId then
				t5[p1][p2.DepositorUserId] = p2.SeedName
			end
		end
		local v2 = t4[p1]
		local v3
		if v2 then
			v3 = v2
		else
			v3 = nil
			for k, v in pairs(t5[p1]) do
				v3 = v
				break
			end
		end
		if v3 then
			setChamberVisual(p1, v3)
		else
			local v4 = t[p1]
			if v4 and v4.Parent then
				v4:Destroy()
			end
			t[p1] = nil
		end
		local v5 = t2[p1]
		if not v5 then
			return
		end
		if t4[p1] then
			v5.ActionText = "Remove Seed"
			return
		end
		v5.ActionText = t3[p1] or v5.ActionText
	else
		t4[p1] = nil
		t5[p1] = {}
		local v7 = t4[p1]
		local v8
		if v7 then
			v8 = v7
		else
			v8 = nil
			for k, v in pairs(t5[p1]) do
				v8 = v
				break
			end
		end
		if v8 then
			setChamberVisual(p1, v8)
		else
			local v9 = t[p1]
			if v9 and v9.Parent then
				v9:Destroy()
			end
			t[p1] = nil
		end
		local v10 = t2[p1]
		if not v10 then
			return
		end
		if t4[p1] then
			v10.ActionText = "Remove Seed"
			return
		end
		v10.ActionText = t3[p1] or v10.ActionText
	end
end)
PactComplete.OnClientEvent:Connect(function() --[[ Line: 215 | Upvalues: t4 (copy), t5 (copy), setChamberVisual (copy), t (copy), t2 (copy), t3 (copy) ]]
	t4.Blue = nil
	t4.Purple = nil
	t5.Blue = {}
	t5.Purple = {}
	local Blue = t4.Blue
	local v1
	if Blue then
		v1 = Blue
	else
		v1 = nil
		for k, v in pairs(t5.Blue) do
			v1 = v
			break
		end
	end
	if v1 then
		setChamberVisual("Blue", v1)
	else
		local Blue_2 = t.Blue
		if Blue_2 and Blue_2.Parent then
			Blue_2:Destroy()
		end
		t.Blue = nil
	end
	local Blue_2 = t2.Blue
	if Blue_2 and t4.Blue then
		Blue_2.ActionText = "Remove Seed"
	elseif Blue_2 then
		Blue_2.ActionText = t3.Blue or Blue_2.ActionText
	end
	local Purple = t4.Purple
	local v3
	if Purple then
		v3 = Purple
	else
		v3 = nil
		for k, v in pairs(t5.Purple) do
			v3 = v
			break
		end
	end
	if v3 then
		setChamberVisual("Purple", v3)
	else
		local Purple_2 = t.Purple
		if Purple_2 and Purple_2.Parent then
			Purple_2:Destroy()
		end
		t.Purple = nil
	end
	local Purple_2 = t2.Purple
	if not Purple_2 then
		return
	end
	if t4.Purple then
		Purple_2.ActionText = "Remove Seed"
		return
	end
	Purple_2.ActionText = t3.Purple or Purple_2.ActionText
end)
local Seeds = ReplicatedStorage.Assets.Seeds
local SeedGuiFriendOTron = ReplicatedStorage.Assets.UI.Billboard.SeedGuiFriendOTron
local RollCycleDuration = FriendOTronConfig.RollCycleDuration
local RollCycleStartInterval = FriendOTronConfig.RollCycleStartInterval
local RollCycleEndInterval = FriendOTronConfig.RollCycleEndInterval
local RollRevealScale = FriendOTronConfig.RollRevealScale
local RollHoldDuration = FriendOTronConfig.RollHoldDuration
local v2 = nil
local v3 = nil
local v4 = 0
local function CreateSeedDisplay(p1) --[[ CreateSeedDisplay | Line: 243 | Upvalues: Seeds (copy) ]]
	local v1 = Seeds:FindFirstChild(p1)
	if not v1 then
		return nil
	end
	local v2 = v1:Clone()
	for i, v in ipairs(v2:GetDescendants()) do
		if v:IsA("BaseScript") then
			v:Destroy()
		end
	end
	for i, v in ipairs(v2:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Anchored = true
			v.CanCollide = false
			v.CanQuery = false
			v.CanTouch = false
		end
	end
	if v2:IsA("Model") and not v2.PrimaryPart then
		v2.PrimaryPart = v2:FindFirstChildWhichIsA("BasePart")
	end
	return v2
end
local function ApplyBlackHighlight(p1) --[[ ApplyBlackHighlight | Line: 271 ]]
	local v1 = p1:FindFirstChildWhichIsA("Highlight")
	local v2
	if not v1 then
		v2 = Instance.new("Highlight")
		v2.FillColor = Color3.new(0/255, 0/255, 0/255)
		v2.FillTransparency = 0
		v2.OutlineColor = Color3.new(255/255, 255/255, 255/255)
		v2.OutlineTransparency = 0
		v2.DepthMode = Enum.HighlightDepthMode.Occluded
		v2.Parent = p1
		return v2
	end
	v1:Destroy()
	v2 = Instance.new("Highlight")
	v2.FillColor = Color3.new(0/255, 0/255, 0/255)
	v2.FillTransparency = 0
	v2.OutlineColor = Color3.new(255/255, 255/255, 255/255)
	v2.OutlineTransparency = 0
	v2.DepthMode = Enum.HighlightDepthMode.Occluded
	v2.Parent = p1
	return v2
end
local function RemoveHighlight(p1) --[[ RemoveHighlight | Line: 285 | Upvalues: TweenService (copy) ]]
	local v1 = p1:FindFirstChildWhichIsA("Highlight")
	if not v1 then
		return
	end
	local v2 = TweenService:Create(v1, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		FillTransparency = 1,
		OutlineTransparency = 1
	})
	v2:Play()
	v2.Completed:Connect(function() --[[ Line: 293 | Upvalues: v1 (copy) ]]
		v1:Destroy()
	end)
end
local function PlayScaleReveal(p1, p2) --[[ PlayScaleReveal | Line: 299 | Upvalues: RollRevealScale (copy), TweenService (copy), SFXModule (copy) ]]
	local v1 = CFrame.new(p2)
	local list = {}
	for i, v in ipairs(p1:GetDescendants()) do
		if v:IsA("BasePart") then
			table.insert(list, {
				Part = v,
				OrigSize = v.Size,
				OrigCFrame = v.CFrame
			})
		end
	end
	for i, v in ipairs(list) do
		local v2 = v1:ToObjectSpace(v.OrigCFrame)
		v.Part.Size = v.OrigSize * RollRevealScale
		v.Part.CFrame = v1 * (CFrame.new(v2.Position * RollRevealScale) * v2.Rotation)
	end
	for i, v in ipairs(list) do
		TweenService:Create(v.Part, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			Size = v.OrigSize,
			CFrame = v.OrigCFrame
		}):Play()
	end
	local v4 = "PopReveal"
	pcall(function() --[[ Line: 66 | Upvalues: p2 (copy), SFXModule (ref), v4 (copy) ]]
		if p2 then
			SFXModule.PlaySFX(v4, false, p2, 1)
		else
			SFXModule.PlaySFX(v4)
		end
	end)
end
local function CalculateFriendOTronOneInX(p1) --[[ CalculateFriendOTronOneInX | Line: 330 | Upvalues: FriendOTronConfig (copy) ]]
	local v1 = FriendOTronConfig.FindPlant(p1)
	if not v1 or (not v1.Weight or v1.Weight <= 0) then
		return 1
	end
	local sum = 0
	for i, v in ipairs(FriendOTronConfig.Plants) do
		sum = sum + v.Weight
	end
	if sum <= 0 then
		return 1
	else
		return math.max(1, (math.floor(sum / v1.Weight + 0.5)))
	end
end
local function ClearLastRoll() --[[ ClearLastRoll | Line: 345 | Upvalues: v2 (ref), v3 (ref) ]]
	if v2 and v2.Parent then
		v2:Destroy()
	end
	v2 = nil
	if not (v3 and v3.Parent) then
		v3 = nil
		return
	end
	v3:Destroy()
	v3 = nil
end
local function AttachFriendOTronUI(p1, p2) --[[ AttachFriendOTronUI | Line: 356 | Upvalues: FriendOTronConfig (copy), SeedGuiFriendOTron (copy), CalculateFriendOTronOneInX (copy), SharedUtils (copy), Registry (copy), findMachine (copy), v3 (ref) ]]
	local v1 = FriendOTronConfig.FindPlant(p2)
	if not v1 then
		return
	end
	local v2 = nil
	if p1:IsA("Model") and p1.PrimaryPart then
		v2 = p1.PrimaryPart
	else
		for i, v in ipairs(p1:GetDescendants()) do
			if v:IsA("BasePart") then
				v2 = v
				break
			end
		end
	end
	if not v2 then
		return
	end
	local v32 = SeedGuiFriendOTron:Clone()
	local Frame = v32:FindFirstChild("Frame")
	if Frame then
		local NameLabel = Frame:FindFirstChild("NameLabel")
		if NameLabel then
			NameLabel.Text = p2 .. " Seed"
		end
		local InfoFrame = Frame:FindFirstChild("InfoFrame")
		if InfoFrame then
			local Chance = InfoFrame:FindFirstChild("Chance")
			if Chance then
				local v4 = CalculateFriendOTronOneInX(p2)
				Chance.Text = "[ 1 in " .. tostring(SharedUtils.ToNumber(v4)) .. " ]"
			end
			local Rarity = InfoFrame:FindFirstChild("Rarity")
			if Rarity then
				Rarity.Text = v1.Rarity
				local v5 = Registry.Rarities[v1.Rarity]
				if v5 then
					local v6 = v5.Gradient:Clone()
					v6.Parent = Rarity
					Rarity.UIStroke.Color = v5.AccentColor
					v6:AddTag("GradientRotate")
				end
			end
		end
	end
	local v7 = findMachine()
	if not v7 then
		return
	end
	local v8 = v7:FindFirstChild(FriendOTronConfig.RollGlassPart)
	local v9
	if v8 and v8:IsA("BasePart") then
		local v10 = v8:FindFirstChild(FriendOTronConfig.RollAnchorName)
		v9 = if v10 then if v10:IsA("Attachment") then v10 else v8 else v8
	else
		v9 = nil
	end
	v32.Adornee = v9
	v32.Parent = v2
	v3 = v32
end
local function playRoll(p1) --[[ playRoll | Line: 413 | Upvalues: findMachine (copy), getRollAnchorPos (copy), v2 (ref), v3 (ref), v4 (ref), FriendOTronConfig (copy), Workspace (copy), TweenService (copy), RollCycleDuration (copy), RollCycleStartInterval (copy), RollCycleEndInterval (copy), CreateSeedDisplay (copy), ApplyBlackHighlight (copy), SFXModule (copy), CollectionService (copy), RemoveHighlight (copy), PlayScaleReveal (copy), ConfettiHandler (copy), AttachFriendOTronUI (copy) ]]
	local v1 = findMachine()
	if not v1 then
		return
	end
	local v22, v32 = getRollAnchorPos(v1)
	local v42 = v32 or v1
	if v2 and v2.Parent then
		v2:Destroy()
	end
	v2 = nil
	if v3 and v3.Parent then
		v3:Destroy()
	end
	v3 = nil
	v4 = v4 + 1
	local t = {}
	for i, v in ipairs(FriendOTronConfig.Plants) do
		table.insert(t, v.Name)
	end
	local CurrentCamera = Workspace.CurrentCamera
	TweenService:Create(CurrentCamera, TweenInfo.new(RollCycleDuration, Enum.EasingStyle.Linear, Enum.EasingDirection.In), {
		FieldOfView = 60
	}):Play()
	local sum = 0
	local v6 = nil
	while sum < RollCycleDuration do
		local v7 = RollCycleStartInterval + (RollCycleEndInterval - RollCycleStartInterval) * (sum / RollCycleDuration) ^ 2
		if v6 and v6.Parent then
			v6:Destroy()
			v6 = nil
		end
		local v8 = CreateSeedDisplay(t[math.random(1, #t)])
		if v8 then
			v8:PivotTo(CFrame.new(v22))
			ApplyBlackHighlight(v8)
			local v9 = v8:GetScale()
			v8:ScaleTo(v9 * 0.01)
			v8.Parent = v42
			local v10 = Instance.new("NumberValue")
			v10.Value = v9 * 0.01
			v10:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 459 | Upvalues: v8 (copy), v10 (copy) ]]
				if not (v8 and v8.Parent) then
					return
				end
				v8:ScaleTo(v10.Value)
			end)
			TweenService:Create(v10, TweenInfo.new(0.08, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				Value = v9
			}):Play()
			task.delay(0.15, function() --[[ Line: 471 | Upvalues: v10 (copy) ]]
				if not v10 then
					return
				end
				v10:Destroy()
			end)
			v6 = v8
		end
		local v11 = "Pop"
		pcall(function() --[[ Line: 66 | Upvalues: v22 (copy), SFXModule (ref), v11 (copy) ]]
			if v22 then
				SFXModule.PlaySFX(v11, false, v22, 1)
			else
				SFXModule.PlaySFX(v11)
			end
		end)
		task.wait(v7)
		sum = sum + v7
	end
	if v6 and v6.Parent then
		v6:Destroy()
	end
	TweenService:Create(CurrentCamera, TweenInfo.new(0.1, Enum.EasingStyle.Bounce, Enum.EasingDirection.In), {
		FieldOfView = 70
	}):Play()
	local v12 = CreateSeedDisplay(p1)
	if not v12 then
		return
	end
	v12:PivotTo(CFrame.new(v22))
	ApplyBlackHighlight(v12)
	CollectionService:AddTag(v12, "FloatSeed")
	local v13 = v12:GetScale()
	v12:ScaleTo(v13 * 0.01)
	v12.Parent = v42
	local v14 = Instance.new("NumberValue")
	v14.Value = v13 * 0.01
	v14:GetPropertyChangedSignal("Value"):Connect(function() --[[ Line: 504 | Upvalues: v12 (copy), v14 (copy) ]]
		if not (v12 and v12.Parent) then
			return
		end
		v12:ScaleTo(v14.Value)
	end)
	TweenService:Create(v14, TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Value = v13
	}):Play()
	task.delay(0.2, function() --[[ Line: 516 | Upvalues: v14 (copy) ]]
		if not v14 then
			return
		end
		v14:Destroy()
	end)
	task.wait(0.05)
	RemoveHighlight(v12)
	PlayScaleReveal(v12, v22)
	local v15 = FriendOTronConfig.FindPlant(p1)
	if v15 then
		local Rarity = v15.Rarity
		if Rarity == "Legendary" or (Rarity == "Secret" or (Rarity == "Prismatic" or (Rarity == "Exotic" or (Rarity == "Transcended" or Rarity == "Divine")))) then
			local v16 = nil
			local v17 = "Reward"
			pcall(function() --[[ Line: 66 | Upvalues: v16 (copy), SFXModule (ref), v17 (copy) ]]
				if v16 then
					SFXModule.PlaySFX(v17, false, v16, 1)
				else
					SFXModule.PlaySFX(v17)
				end
			end)
		end
	end
	pcall(function() --[[ Line: 532 | Upvalues: ConfettiHandler (ref) ]]
		task.spawn(function() --[[ Line: 532 | Upvalues: ConfettiHandler (ref) ]]
			ConfettiHandler.SpawnConfetti(30)
		end)
	end)
	v2 = v12
	local v18 = v4
	if v12 and v12.Parent then
		AttachFriendOTronUI(v12, p1)
	end
	task.delay(15, function() --[[ Line: 542 | Upvalues: v4 (ref), v18 (copy), v2 (ref), v3 (ref) ]]
		if v4 ~= v18 then
			return
		end
		if v2 and v2.Parent then
			v2:Destroy()
		end
		v2 = nil
		if v3 and v3.Parent then
			v3:Destroy()
		end
		v3 = nil
	end)
end
local function bindPrompts() --[[ bindPrompts | Line: 554 | Upvalues: findMachine (copy), FriendOTronConfig (copy), t2 (copy), t3 (copy), t4 (copy), RemoveSeed (copy), SFXModule (copy), InsertSeed (copy), v1 (ref), PullLever (copy), playRoll (copy) ]]
	local friendotronbindpromptsmachine = findMachine()
	print("[FriendOTron] bindPrompts machine=", friendotronbindpromptsmachine)
	if not friendotronbindpromptsmachine then
		warn("[FriendOTron] findMachine returned nil; prompts NOT bound")
		return
	end
	local v12 = friendotronbindpromptsmachine:FindFirstChild(FriendOTronConfig.BlueChamberPart)
	local v2 = friendotronbindpromptsmachine:FindFirstChild(FriendOTronConfig.PurpleChamberPart)
	local v3 = friendotronbindpromptsmachine
	for i, v in ipairs(FriendOTronConfig.LeverPath) do
		local v4 = if v3 then v3:FindFirstChild(v) else v3
		v3 = v4
		if not v4 then
			break
		end
	end
	local friendotronpromptsfoundblue = if v12 then v12:FindFirstChildWhichIsA("ProximityPrompt") else v12
	local v5 = if v2 then v2:FindFirstChildWhichIsA("ProximityPrompt") else v2
	local v6 = if v3 then v3:FindFirstChildWhichIsA("ProximityPrompt", true) else v3
	print("[FriendOTron] prompts found: blue=", friendotronpromptsfoundblue, "purple=", v5, "lever=", v6)
	local function bindChamberPrompt(p1, p2) --[[ bindChamberPrompt | Line: 576 | Upvalues: t2 (ref), t3 (ref), t4 (ref), RemoveSeed (ref), SFXModule (ref), InsertSeed (ref) ]]
		if not p2 then
			return
		end
		t2[p1] = p2
		t3[p1] = p2.ActionText
		local v1 = t2[p1]
		if v1 and t4[p1] then
			v1.ActionText = "Remove Seed"
		elseif v1 then
			v1.ActionText = t3[p1] or v1.ActionText
		end
		p2.Triggered:Connect(function() --[[ Line: 583 | Upvalues: t4 (ref), p1 (copy), RemoveSeed (ref), SFXModule (ref), InsertSeed (ref) ]]
			if t4[p1] then
				local v1, v2 = pcall(function() --[[ Line: 585 | Upvalues: RemoveSeed (ref), p1 (ref) ]]
					return RemoveSeed:InvokeServer(p1)
				end)
				local v3 = print
				local v5 = p1
				local v8_2 = if type(v2) == "table" then v2.Success else false
				local v10_2 = if type(v2) == "table" then v2.Error else false
				v3("[FriendOTron] RemoveSeed", v5, "ok=", v1, "Success=", v8_2, "Error=", v10_2)
				if v1 then
					SFXModule.PlaySFX("HarvestLoud")
				end
			else
				local v11, v12 = pcall(function() --[[ Line: 591 | Upvalues: InsertSeed (ref), p1 (ref) ]]
					return InsertSeed:InvokeServer(p1)
				end)
				local v15 = p1
				print("[FriendOTron] InsertSeed", v15, "ok=", v11, "Success=", if type(v12) == "table" then v12.Success else false, "Error=", if type(v12) == "table" then v12.Error else false)
				if not v11 then
					return
				end
				SFXModule.PlaySFX("HarvestLoud")
			end
		end)
	end
	if friendotronpromptsfoundblue then
		t2.Blue = friendotronpromptsfoundblue
		t3.Blue = friendotronpromptsfoundblue.ActionText
		local Blue = t2.Blue
		if Blue and t4.Blue then
			Blue.ActionText = "Remove Seed"
		elseif Blue then
			Blue.ActionText = t3.Blue or Blue.ActionText
		end
		local v8 = "Blue"
		friendotronpromptsfoundblue.Triggered:Connect(function() --[[ Line: 583 | Upvalues: t4 (ref), v8 (copy), RemoveSeed (ref), SFXModule (ref), InsertSeed (ref) ]]
			if t4[v8] then
				local v1, v2 = pcall(function() --[[ Line: 585 | Upvalues: RemoveSeed (ref), v8 (ref) ]]
					return RemoveSeed:InvokeServer(p1)
				end)
				local v3 = print
				local v5 = v8
				local v8_2 = if type(v2) == "table" then v2.Success else false
				local v10_2 = if type(v2) == "table" then v2.Error else false
				v3("[FriendOTron] RemoveSeed", v5, "ok=", v1, "Success=", v8_2, "Error=", v10_2)
				if v1 then
					SFXModule.PlaySFX("HarvestLoud")
				end
			else
				local v11, v12 = pcall(function() --[[ Line: 591 | Upvalues: InsertSeed (ref), v8 (ref) ]]
					return InsertSeed:InvokeServer(p1)
				end)
				local v15 = v8
				print("[FriendOTron] InsertSeed", v15, "ok=", v11, "Success=", if type(v12) == "table" then v12.Success else false, "Error=", if type(v12) == "table" then v12.Error else false)
				if not v11 then
					return
				end
				SFXModule.PlaySFX("HarvestLoud")
			end
		end)
	end
	if v5 then
		t2.Purple = v5
		t3.Purple = v5.ActionText
		local Purple = t2.Purple
		if Purple and t4.Purple then
			Purple.ActionText = "Remove Seed"
		elseif Purple then
			Purple.ActionText = t3.Purple or Purple.ActionText
		end
		local v10 = "Purple"
		v5.Triggered:Connect(function() --[[ Line: 583 | Upvalues: t4 (ref), v10 (copy), RemoveSeed (ref), SFXModule (ref), InsertSeed (ref) ]]
			if t4[v10] then
				local v1, v2 = pcall(function() --[[ Line: 585 | Upvalues: RemoveSeed (ref), v10 (ref) ]]
					return RemoveSeed:InvokeServer(p1)
				end)
				local v3 = print
				local v5 = v10
				local v8_2 = if type(v2) == "table" then v2.Success else false
				local v10_2 = if type(v2) == "table" then v2.Error else false
				v3("[FriendOTron] RemoveSeed", v5, "ok=", v1, "Success=", v8_2, "Error=", v10_2)
				if v1 then
					SFXModule.PlaySFX("HarvestLoud")
				end
			else
				local v11, v12 = pcall(function() --[[ Line: 591 | Upvalues: InsertSeed (ref), v10 (ref) ]]
					return InsertSeed:InvokeServer(p1)
				end)
				local v15 = v10
				print("[FriendOTron] InsertSeed", v15, "ok=", v11, "Success=", if type(v12) == "table" then v12.Success else false, "Error=", if type(v12) == "table" then v12.Error else false)
				if not v11 then
					return
				end
				SFXModule.PlaySFX("HarvestLoud")
			end
		end)
	end
	if not v6 then
		return
	end
	v6.Triggered:Connect(function() --[[ Line: 605 | Upvalues: v1 (ref), PullLever (ref), playRoll (ref) ]]
		print("[FriendOTron] LEVER Triggered")
		if v1 then
			return
		end
		v1 = true
		local v12, v2 = pcall(function() --[[ Line: 609 | Upvalues: PullLever (ref) ]]
			return PullLever:InvokeServer()
		end)
		print("[FriendOTron] PullLever ok=", v12, "Success=", if type(v2) == "table" then v2.Success else false, "Plant=", if type(v2) == "table" then v2.Plant else false, "Error=", if type(v2) == "table" then v2.Error else false)
		if v12 and (type(v2) == "table" and (v2.Success and v2.Plant)) then
			playRoll(v2.Plant)
		end
		v1 = false
	end)
end
task.spawn(function() --[[ Line: 620 | Upvalues: findMachine (copy), FriendOTronConfig (copy), bindPrompts (copy) ]]
	repeat
		local v1 = findMachine()
		if v1 then
			local v2 = v1:FindFirstChild(FriendOTronConfig.BlueChamberPart)
			local v3 = v1:FindFirstChild(FriendOTronConfig.PurpleChamberPart)
			local v4 = if v2 then v2:FindFirstChildWhichIsA("ProximityPrompt") else v2
			if v4 and (if v3 then v3:FindFirstChildWhichIsA("ProximityPrompt") else v3) then
				break
			end
		end
		task.wait(0.5)
	until not v1
	bindPrompts()
end)
task.spawn(function() --[[ Line: 642 | Upvalues: DataAggregation (copy), SharedUtils (copy), FriendOTronConfig (copy), CollectionService (copy) ]]
	local v1 = DataAggregation.WaitForReplica()
	if not v1 then
		return
	end
	local function currentSpins() --[[ currentSpins | Line: 646 | Upvalues: SharedUtils (ref), v1 (copy), FriendOTronConfig (ref) ]]
		return SharedUtils.ReadNested(v1.Data, FriendOTronConfig.SpinsPath) or 0
	end
	local function findSpinsLabel(p1) --[[ findSpinsLabel | Line: 650 | Upvalues: FriendOTronConfig (ref) ]]
		local v1 = p1
		for i, v in ipairs(FriendOTronConfig.SpinsBillboardPath) do
			local v2 = if v1 then v1:FindFirstChild(v) else v1
			if not v2 then
				return nil
			end
			v1 = v2
		end
		local v3 = if v1 then v1:FindFirstChild(FriendOTronConfig.SpinsLabelName) else v1
		if v3 and v3:IsA("TextLabel") then
			return v3
		else
			return nil
		end
	end
	local function paintMachine(p1) --[[ paintMachine | Line: 661 | Upvalues: findSpinsLabel (copy), FriendOTronConfig (ref), SharedUtils (ref), v1 (copy) ]]
		local v12 = findSpinsLabel(p1)
		if v12 then
			v12.Text = FriendOTronConfig.SpinsTextPrefix .. tostring(SharedUtils.ReadNested(v1.Data, FriendOTronConfig.SpinsPath) or 0)
		end
	end
	local function paintAll() --[[ paintAll | Line: 667 | Upvalues: CollectionService (ref), FriendOTronConfig (ref), findSpinsLabel (copy), SharedUtils (ref), v1 (copy) ]]
		for i, v in ipairs(CollectionService:GetTagged(FriendOTronConfig.MachineTag)) do
			local v12 = findSpinsLabel(v)
			if v12 then
				v12.Text = FriendOTronConfig.SpinsTextPrefix .. tostring(SharedUtils.ReadNested(v1.Data, FriendOTronConfig.SpinsPath) or 0)
			end
		end
	end
	local function watchMachine(p1) --[[ watchMachine | Line: 673 | Upvalues: FriendOTronConfig (ref), findSpinsLabel (copy), SharedUtils (ref), v1 (copy) ]]
		task.spawn(function() --[[ Line: 674 | Upvalues: p1 (copy), FriendOTronConfig (ref), findSpinsLabel (ref), SharedUtils (ref), v1 (ref) ]]
			local v12 = p1
			for i2, v_2 in ipairs(FriendOTronConfig.SpinsBillboardPath) do
				local v2 = v12:WaitForChild(v_2)
				if not v2.Parent then
					return
				end
				v12 = v2
			end
			local v3 = v12:WaitForChild(FriendOTronConfig.SpinsLabelName)
			if not (v3 and v3.Parent) then
				return
			end
			local v4 = findSpinsLabel(p1)
			if v4 then
				v4.Text = FriendOTronConfig.SpinsTextPrefix .. tostring(SharedUtils.ReadNested(v1.Data, FriendOTronConfig.SpinsPath) or 0)
			end
		end)
	end
	for i, v in ipairs(CollectionService:GetTagged(FriendOTronConfig.MachineTag)) do
		task.spawn(function() --[[ Line: 674 | Upvalues: v (copy), FriendOTronConfig (ref), findSpinsLabel (copy), SharedUtils (ref), v1 (copy) ]]
			local v12 = v
			for i2, v_2 in ipairs(FriendOTronConfig.SpinsBillboardPath) do
				local v2 = v12:WaitForChild(v_2)
				if not v2.Parent then
					return
				end
				v12 = v2
			end
			local v3 = v12:WaitForChild(FriendOTronConfig.SpinsLabelName)
			if not (v3 and v3.Parent) then
				return
			end
			local v4 = findSpinsLabel(v)
			if v4 then
				v4.Text = FriendOTronConfig.SpinsTextPrefix .. tostring(SharedUtils.ReadNested(v1.Data, FriendOTronConfig.SpinsPath) or 0)
			end
		end)
	end
	CollectionService:GetInstanceAddedSignal(FriendOTronConfig.MachineTag):Connect(watchMachine)
	v1:OnSet(FriendOTronConfig.SpinsPath, paintAll)
end)
local v5 = 0
local v6 = false
local function getCooldownNodes() --[[ getCooldownNodes | Line: 701 | Upvalues: findMachine (copy), FriendOTronConfig (copy) ]]
	local v1 = findMachine()
	if not v1 then
		return nil, nil
	end
	local v2 = v1
	for i, v in ipairs(FriendOTronConfig.CooldownBillboardPath) do
		local v3 = if v2 then v2:FindFirstChild(v) else v2
		if not v3 then
			return nil, nil
		end
		v2 = v3
	end
	if not (v2 and v2:IsA("BillboardGui")) then
		return nil, nil
	end
	local v4 = v2:FindFirstChild(FriendOTronConfig.CooldownTimeLabelName)
	if v4 and not v4:IsA("TextLabel") then
		v4 = nil
	end
	return v2, v4
end
local function applyCooldownUI() --[[ applyCooldownUI | Line: 715 | Upvalues: getCooldownNodes (copy), v5 (ref) ]]
	local v1, v2 = getCooldownNodes()
	if not v1 then
		return
	end
	local v3 = v5 - os.time()
	if v3 <= 0 then
		v1.Enabled = false
		return
	end
	v1.Enabled = true
	if not v2 then
		return
	end
	v2.Text = string.format("%02d:%02d", math.floor(v3 / 60), v3 % 60)
end
local function startCooldownLoop() --[[ startCooldownLoop | Line: 731 | Upvalues: v6 (ref), v5 (ref), applyCooldownUI (copy) ]]
	if not v6 then
		v6 = true
		task.spawn(function() --[[ Line: 734 | Upvalues: v5 (ref), applyCooldownUI (ref), v6 (ref) ]]
			while os.time() < v5 do
				applyCooldownUI()
				task.wait(1)
			end
			applyCooldownUI()
			v6 = false
		end)
	end
end
CooldownSync.OnClientEvent:Connect(function(p1) --[[ Line: 744 | Upvalues: v5 (ref), applyCooldownUI (copy), v6 (ref) ]]
	v5 = tonumber(p1) or 0
	applyCooldownUI()
	if not (v5 > os.time()) then
		return
	end
	if v6 then
		return
	end
	v6 = true
	task.spawn(function() --[[ Line: 734 | Upvalues: v5 (ref), applyCooldownUI (ref), v6 (ref) ]]
		while os.time() < v5 do
			applyCooldownUI()
			task.wait(1)
		end
		applyCooldownUI()
		v6 = false
	end)
end)
return {}