-- Path: Players.Asuneteric.PlayerGui.MainUI.Menus.SpinWheelFrame.Buttons.Action.Shimmer.Shimmer.BitohiShimmerBest
-- Class: LocalScript

-- https://lua.expert/
local v1 = script.Parent
local TweenService = game:GetService("TweenService")
local v2 = TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local function v3() --[[ playShimmer | Line: 14 | Upvalues: v1 (copy), TweenService (copy), v2 (copy), v3 (copy) ]]
	v1.Offset = Vector2.new(-1, 0)
	local v12 = TweenService:Create(v1, v2, {
		Offset = Vector2.new(1, 0)
	})
	v12:Play()
	v12.Completed:Once(function() --[[ Line: 26 | Upvalues: v3 (ref) ]]
		task.delay(1, v3)
	end)
end
v3()